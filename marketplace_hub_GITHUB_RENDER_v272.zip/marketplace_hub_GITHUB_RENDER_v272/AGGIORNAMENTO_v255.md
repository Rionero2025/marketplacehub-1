# Marketplace Hub v255 — Packlink ordini persistenti e sincronizzazione veloce

## Obiettivo
La pagina **Packlink PRO** non deve trattare ogni apertura o modifica dell'interfaccia come una nuova lettura dei marketplace. Gli ordini già scaricati restano nel database e vengono riutilizzati immediatamente; la rete viene usata solo quando l'utente richiede un aggiornamento.

## Correzioni v255

### 1. Memoria ordini persistente
- Gli ordini continuano a essere salvati in `cecotec_order_cache` su SQLite/PostgreSQL.
- Aprire Packlink, cambiare filtri, scegliere tariffe o modificare un pacco non richiama Kaufland/Worten.
- La pagina mostra quante righe sono già memorizzate e la data/ora dell'ultimo aggiornamento.
- La lettura e il raggruppamento della cache sono memorizzati anche nel processo Streamlit e invalidati automaticamente quando cambiano numero righe o timestamp di sincronizzazione.

### 2. Aggiornamento incrementale
Il pulsante normale diventa **Aggiorna nuovi / da spedire**.

- Se esiste già una cache, la sincronizzazione riparte dall'ultimo ordine memorizzato con 2 giorni di sovrapposizione.
- Lo storico già presente non viene cancellato.
- Per Kaufland la modalità rapida interroga solo gli stati `open` e `need_to_be_sent`, che sono quelli utili al flusso di spedizione Packlink.
- In modalità rapida Kaufland viene evitata la scansione completa del manifest e degli stati storici `sent`, `received`, `returned`, ecc.
- Worten continua a usare i filtri data lato API, ma in modalità normale lavora solo sulla parte incrementale.

### 3. Refresh completo disponibile ma volontario
È presente l'opzione **Forza riscaricamento completo dell'intervallo (più lento)**.

Solo quando questa opzione è attiva Marketplace Hub:
- usa il comportamento storico completo;
- rilegge tutto l'intervallo selezionato;
- sostituisce nel database esclusivamente quell'intervallo.

La modalità normale non cancella mai la cache storica.

### 4. Scrittura database più veloce
`upsert_order_cache()` ora usa una singola operazione `executemany`/transazione per il lotto invece di aprire una transazione per ogni riga ordine.

Sono stati aggiunti indici per:
- Seller/account/marketplace/data ordine;
- Seller/account/marketplace/data ultima sincronizzazione.

### 5. Rendering Packlink più leggero
- Le memorie dei pacchi vengono lette in blocco invece di eseguire una query SQL per ogni ordine.
- Le righe contabili necessarie al valore dichiarato vengono lette solo per l'intervallo visualizzato.
- La cache ordini raggruppata viene riutilizzata sui rerun Streamlit.

## Compatibilità preservata
Restano invariati:
- generazione CSV Packlink e fallback telefono mittente della v253;
- creazione massiva delle spedizioni dopo scelta manuale della tariffa;
- memoria pacchi e tariffe;
- recupero diretto di un ordine tramite numero ordine;
- database, `data`, Seller, ordini, storico, configurazioni e credenziali;
- `.streamlit/secrets.toml` e `.venv`;
- avvio automatico e protezione anti-downgrade.

## Test
Suite completa: **603 test superati + 6 subtest**.
