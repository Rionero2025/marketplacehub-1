# Marketplace Hub v132

## Correzione Dashboard bloccata su RUNNING

- La sincronizzazione API non viene più eseguita dentro il rendering Streamlit.
- La Dashboard mostra immediatamente i dati già presenti nel database.
- Il polling di Kaufland e Worten viene avviato in un thread daemon separato.
- Il refresh grafico ogni 30 secondi rilegge soltanto SQLite e non attende la rete.
- Il pulsante **Aggiorna adesso** avvia il controllo in background e ritorna subito.
- Il blocco database impedisce sincronizzazioni duplicate tra più schede o sessioni.
- I vecchi lock rimasti dalla v131 vengono considerati scaduti dopo 20 minuti.
- La sincronizzazione automatica usa un controllo leggero: ultimi 7 giorni e massimo
  100 righe recenti per account.
- Timeout ridotti per il polling Dashboard: Worten 20 secondi; Kaufland 12 secondi
  con massimo 2 tentativi per richiesta.
- Per Kaufland il polling leggero non scarica i dettagli di tracking di ogni ordine;
  il recupero completo resta disponibile nella pagina Contabilità.

## Comportamento

Un eventuale rallentamento o errore delle API non blocca più la pagina. Durante il
controllo viene mostrato lo stato **Sincronizzazione API in background in corso**;
i riquadri, i filtri e il menu rimangono utilizzabili.
