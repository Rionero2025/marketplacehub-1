@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - PostgreSQL opzionale
echo ================================================================
echo PostgreSQL e' OPZIONALE: Marketplace Hub funziona anche con SQLite.
echo ================================================================
echo.
echo Questo assistente prova a installare PostgreSQL tramite WinGet e poi apre
ECHO la configurazione/migrazione gia' inclusa nel progetto.
echo.
where winget >nul 2>&1
if errorlevel 1 (
  echo WinGet non disponibile. Scarica PostgreSQL dal sito ufficiale e poi
  echo esegui MIGRA_A_POSTGRESQL_WINDOWS.bat.
  pause
  exit /b 1
)
winget search PostgreSQL.PostgreSQL.18
if errorlevel 1 (
  echo Impossibile interrogare WinGet.
  pause
  exit /b 1
)
echo.
echo Se PostgreSQL 18 non e' gia' installato, verra' aperta l'installazione.
winget install --exact --id PostgreSQL.PostgreSQL.18 --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
  echo Installazione PostgreSQL non completata automaticamente.
  echo Puoi installarlo manualmente e poi usare MIGRA_A_POSTGRESQL_WINDOWS.bat.
  pause
  exit /b 1
)
call "%~dp0MIGRA_A_POSTGRESQL_WINDOWS.bat"
