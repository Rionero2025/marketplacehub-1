# Marketplace Hub v266 — struttura e garanzie

Release: **266**

## File principali aggiornati
- `services/product_stats.py` — margine parziale sempre numerico e nuova coda degli ordini con margine incompleto;
- `pages/3_Prodotti_Piu_Venduti.py` — KPI margine sempre visibile, avviso con conteggio ordini e apertura diretta della Contabilità;
- `pages/4_Contabilita.py` — ricezione della coda, preselezione Seller/marketplace/account, editor rapido e navigazione tra account;
- `pages/0_Dashboard.py` — Top 10 con indicazione del margine parziale;
- `tests/test_product_stats_review_v266.py` — test del margine parziale e conteggio ordini unici;
- `tests/test_product_stats_review_ui_v266.py` — test dei contratti di navigazione e modifica rapida;
- `services/catalog_intelligence/__init__.py` — allineamento versione release;
- `VERSION.txt` — release 266.

## Contratto margine v266
- `margin_eur` è sempre la somma dei margini conosciuti delle righe vendute;
- `margin_missing_rows` continua a contare le righe non determinabili;
- `margin_pct` rimane `None` finché esiste almeno una riga mancante nello stesso aggregato;
- il totale pagina somma tutti i margini attualmente conoscibili, anche se il periodo contiene righe da completare;
- un prodotto interamente incompleto mostra 0,00 € come margine attualmente determinabile insieme all'avviso esplicito di incompletezza, evitando di nascondere il KPI.

## Contratto coda di verifica
- il conteggio principale è per ordine univoco Seller + account + marketplace + numero ordine;
- più righe mancanti dello stesso ordine valgono un solo ordine da verificare;
- la coda conserva le righe mancanti, ma in Contabilità vengono mostrate tutte le righe dell'ordine interessato per permettere una correzione coerente;
- la coda può attraversare più Seller e account;
- l'editor rapido usa esclusivamente i campi già modificabili nella tabella contabile e lo stesso salvataggio persistente;
- la tabella principale della Contabilità viene focalizzata sugli ordini della coda mentre la modalità verifica è attiva;
- **Chiudi verifica** ripristina il normale comportamento della pagina.

## Regole preservate
- nessuna API aggiuntiva per statistiche o coda di verifica;
- compatibilità con Contabilità v259 e override manuali;
- compatibilità con Dashboard/Top 10 v265;
- database, Seller, credenziali, ordini, storico, backup e configurazioni non vengono cancellati;
- avvio standard dopo estrazione tramite `AVVIA_WINDOWS.bat`.
