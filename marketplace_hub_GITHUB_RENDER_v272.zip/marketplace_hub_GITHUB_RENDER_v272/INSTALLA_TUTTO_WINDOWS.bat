@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - Installazione completa v232
color 0B
cls
echo ================================================================
echo       MARKETPLACE HUB v232 - INSTALLAZIONE COMPLETA WINDOWS
echo ================================================================
echo.
echo Questo programma controlla e installa automaticamente:
echo   - Python 3.13 quando non e' presente
echo   - ambiente virtuale .venv isolato
echo   - tutte le librerie Python del progetto
echo   - Microsoft Visual C++ Runtime quando disponibile via WinGet
echo   - Tesseract OCR e language pack ENG/ITA/POR
echo   - verifica database, permessi e compilazione del progetto
echo   - collegamento sul Desktop
echo.
echo E' necessaria una connessione Internet per i componenti mancanti.
echo Chiudi Marketplace Hub prima di continuare.
echo.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA_MARKETPLACE_HUB.ps1" -FullTests
if errorlevel 1 (
  echo.
  echo INSTALLAZIONE FALLITA. Consulta la cartella logs.
  pause
  exit /b 1
)
exit /b 0
