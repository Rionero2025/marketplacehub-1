# Aggiornamento v202 — Compatibilità OF01 Worten

- Corretto l’errore `Value '"NORMAL"' is not valid for parameter 'import_mode'`.
- Il tenant Worten interpreta le virgolette come parte del valore; `import_mode` viene quindi inviato come valore non quotato nella query: `import_mode=NORMAL`.
- Il corpo `multipart/form-data` contiene soltanto il file CSV.
- Restano ammessi esclusivamente i modi Mirakl `NORMAL` e `REPLACE`.
- La colonna CSV `update-delete` continua a usare `update` per gli aggiornamenti selettivi.
