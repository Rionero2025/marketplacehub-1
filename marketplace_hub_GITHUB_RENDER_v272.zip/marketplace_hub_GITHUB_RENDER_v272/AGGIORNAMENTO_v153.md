# Marketplace Hub v153

## Invio tracking Worten conforme a OR23, OR24 e SH21

La versione corregge l'errore Mirakl/Worten:

`Invalid value for field 'carrierCode'. No carrier with code 'MRW' found.`

Il programma non usa più il nome del corriere come se fosse automaticamente il
suo codice API. Prima dell'invio legge l'elenco dei corrieri configurati sul
tenant Worten tramite SH21 (`GET /api/shipping/carriers`).

- Se il corriere è registrato, OR23/ST23 ricevono esclusivamente il codice esatto
  restituito da SH21.
- Se il corriere non è registrato, viene inviato `carrier_name` senza inventare
  `carrier_code`, come previsto dalla documentazione Mirakl.
- Se un codice ottenuto da SH21 viene comunque rifiutato perché la configurazione
  è cambiata o non è coerente, il programma ripete una sola volta la richiesta
  come corriere non registrato, senza codice.
- Un generico campo `id` eventualmente presente nella risposta non viene più
  interpretato come codice corriere.

Dopo l'aggiornamento del tracking, l'ordine in stato `SHIPPING` viene confermato
come spedito tramite OR24 (`PUT /api/orders/{order_id}/ship`). Per le spedizioni
multiple resta attivo l'equivalente flusso ST23/ST24.

## Sincronizzazione incrementale completa degli ordini

Gli ordini vengono letti normalmente dal database locale. Il programma conserva
permanentemente tutti quelli già scaricati e distingue lo stato della
sincronizzazione per Seller, marketplace, account e ambiente.

### Primo scaricamento

Il primo aggiornamento scarica l'intero intervallo selezionato, salva ordini e
righe prodotto tramite upsert e registra:

- ultimo tentativo;
- ultimo aggiornamento riuscito;
- data e numero dell'ultimo ordine;
- totale ordini e righe presenti nel database.

### Aggiornamenti successivi

Il pulsante **Aggiorna ordini mancanti e modificati**:

- richiede solo gli ordini nuovi o aggiornati;
- aggiunge gli ordini mancanti;
- aggiorna quelli esistenti senza duplicarli;
- conserva ordini, tracking, costi e modifiche manuali già salvati;
- mostra separatamente ordini nuovi, modificati, ricontrollati senza variazioni
  e totale già presente.

Per Worten viene utilizzato il filtro ufficiale Mirakl
`start_update_date`/`end_update_date`. Per Kaufland viene letto il manifesto
leggero degli ordini e vengono scaricati i dettagli soltanto degli ordini la cui
data di creazione o aggiornamento delle unità rientra nella finestra richiesta.

### Risincronizzazione completa

Il pulsante **Risincronizzazione completa** non parte immediatamente: mostra una
conferma esplicita. Anche durante una risincronizzazione completa lo storico
locale non viene cancellato.

Se un tentativo API fallisce, la pagina mostra l'errore ma mantiene l'ultima
sincronizzazione riuscita e tutti gli ordini già memorizzati.
