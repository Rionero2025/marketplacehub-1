# Marketplace Hub v269 — Packlink: modifica email/telefono e valori predefiniti

## Novità

Nella pagina **Packlink PRO**, prima dell'esportazione CSV e della creazione della bozza, è stata aggiunta una sezione dedicata ai contatti del destinatario.

Dalla v269 è possibile:

- modificare direttamente **email** e **telefono** per i singoli ordini che hanno almeno un contatto mancante;
- impostare una **email predefinita** per il Seller;
- impostare un **telefono predefinito** per il Seller;
- attivare separatamente **Usa l'email predefinita per tutti quelli senza email**;
- attivare separatamente **Usa il telefono predefinito per tutti quelli senza telefono**;
- salvare email, telefono e relative opzioni nelle impostazioni Packlink del Seller, così vengono riproposti nei successivi utilizzi.

## Priorità dei contatti

Per ciascun ordine Marketplace Hub usa questa priorità:

1. valore inserito manualmente per il singolo ordine;
2. contatto originale del cliente ricevuto dal marketplace;
3. valore predefinito del Seller, se la relativa opzione è attiva;
4. solo per il telefono, se resta ancora mancante, rimane il precedente fallback sul numero del mittente per il CSV/Packlink.

I valori predefiniti non sostituiscono i contatti già presenti negli ordini.

## CSV e bozza Packlink

Le correzioni effettuate nella nuova sezione vengono applicate sia:

- al **CSV ufficiale Packlink PRO**;
- al payload usato per creare la **bozza Packlink**.

La copia dell'ordine usata immediatamente prima del POST viene aggiornata con i contatti correnti, evitando che una snapshot precedente di Streamlit annulli la modifica.

## Compatibilità

- nessuna migrazione database;
- nessuna modifica agli ordini marketplace memorizzati;
- i valori predefiniti vengono salvati in `settings_json` dell'integrazione Packlink del Seller;
- resta compatibile il fallback telefono mittente già presente;
- release e Catalog Intelligence allineati a v269.
