# Marketplace Hub v244 — struttura del pacchetto completo

La v244 parte dalla pietra miliare v243 e aggiunge la prima fondazione operativa di **Catalog Intelligence / Creazione Prodotti**.

## Struttura Python

- `pages/`: 24 file
- `services/`: 60 file
- `services/catalog_intelligence/`: 14 file
- `tests/`: 80 file
- `tools/`: 14 file
- `_release_payload/`: 100 file Python auto-riparanti

## Nuova pagina

- `pages/3_Creazione_Prodotti.py`

## Nuovi servizi Catalog Intelligence

- `services/catalog_intelligence/schema.py`
- `services/catalog_intelligence/models.py`
- `services/catalog_intelligence/utils.py`
- `services/catalog_intelligence/accounts.py`
- `services/catalog_intelligence/capabilities.py`
- `services/catalog_intelligence/taxonomy.py`
- `services/catalog_intelligence/normalization.py`
- `services/catalog_intelligence/mapping.py`
- `services/catalog_intelligence/validation.py`
- `services/catalog_intelligence/repository.py`
- `services/catalog_intelligence/marketplaces/kaufland.py`
- `services/catalog_intelligence/marketplaces/mirakl.py`

## Funzioni della tranche v244

1. scelta Seller e account Kaufland/Worten;
2. verifica capacità API in sola lettura;
3. sincronizzazione tassonomie ufficiali;
4. snapshot immutabili e cache persistente;
5. normalizzazione dei prodotti dalle viste salvate;
6. provenienza dei valori;
7. mapping deterministico;
8. validazione categoria/attributi;
9. readiness score;
10. job persistenti e idempotenti senza scrittura remota.

## Compatibilità e preservazione

- SQLite: sì;
- PostgreSQL: DDL tradotta dal layer di compatibilità e coperta da test;
- tabelle precedenti: non eliminate;
- `data`, database, Seller, account, ordini, storico, credenziali e configurazioni: preservati;
- avvio: soltanto `AVVIA_WINDOWS.bat`;
- anti-downgrade e auto-riparazione codice: mantenuti.

## Gate della release

La distribuzione viene bloccata se manca:

- la pagina Creazione Prodotti nel menu;
- un servizio o simbolo obbligatorio Catalog Intelligence;
- l'allineamento tra versione Catalog Intelligence e `VERSION.txt`;
- la copia identica del codice in `_release_payload`;
- la coerenza degli import locali.
