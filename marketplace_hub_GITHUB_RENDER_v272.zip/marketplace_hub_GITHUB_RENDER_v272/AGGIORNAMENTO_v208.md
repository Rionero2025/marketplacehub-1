# Marketplace Hub v208 — Hotfix creazione bozza Packlink PRO

## Correzione
Nella v207 il pulsante **Crea bozza spedizione Packlink** veniva disabilitato usando direttamente il valore della checkbox di conferma che si trovava nello stesso `st.form`.

Con i form Streamlit i valori dei widget vengono inviati al server solo al submit. Di conseguenza la checkbox poteva apparire selezionata nel browser, ma il server continuava a conoscere il precedente valore `False` e manteneva il pulsante disabilitato.

La v208 corregge il flusso:

- il pulsante è attivo quando esiste almeno una tariffa Packlink valida;
- radio button, valore dichiarato e checkbox vengono trasmessi insieme premendo il pulsante;
- se la conferma non è selezionata, nessuna chiamata API viene effettuata e viene mostrato un messaggio esplicito;
- se la conferma è selezionata, viene creata la bozza con il servizio scelto;
- il database e gli ordini non vengono modificati in caso di mancata conferma.
