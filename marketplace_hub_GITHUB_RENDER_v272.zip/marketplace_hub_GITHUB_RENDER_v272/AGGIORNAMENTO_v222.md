# Marketplace Hub v222 — pacchetto completo autonomo

Questa release ricostruisce Marketplace Hub come pacchetto completo, non come hotfix.

## Base e contenuto
- base applicativa completa v220;
- correzioni Packlink v221 integrate nel codice definitivo;
- `services/packlink.py` e `pages/4_Packlink_PRO.py` allineati;
- `PACKLINK_SERVICE_VERSION = 221` mantenuto come versione del servizio Packlink;
- funzione `last_order_draft_configuration` inclusa;
- memoria delle impostazioni per la rigenerazione massiva mantenuta;
- test v218/v220/v221 inclusi;
- installer Windows completo ripristinato;
- script di diagnostica, riparazione, verifica e aggiornamento librerie inclusi;
- nessuna cache `__pycache__`/`.pyc` distribuita.

## Comportamento rigenerazione
Quando si usa la selezione massiva degli ordini da rigenerare, ogni ordine recupera le impostazioni già salvate in precedenza. Le modifiche manuali effettuate sul singolo ordine restano specifiche di quell'ordine e diventano la nuova configurazione ricordata per le rigenerazioni successive.

## Installazione
Per una nuova installazione estrarre la cartella `marketplace_hub` e avviare `INSTALLA_TUTTO_WINDOWS.bat`.

Per un'installazione esistente, conservare sempre `data/` e `.streamlit/secrets.toml` prima di sostituire il codice. Il pacchetto non contiene credenziali personali né database dell'utente.
