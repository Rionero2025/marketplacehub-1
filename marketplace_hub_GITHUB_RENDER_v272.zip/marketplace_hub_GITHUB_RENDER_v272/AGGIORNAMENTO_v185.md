# Aggiornamento v185

- Corretto il download del catalogo Kaufland nella pagina Cancellazione offerte.
- `GET /units/` usa ora il valore ufficiale `embedded=products`; il vecchio alias singolare `product` viene convertito automaticamente.
- Supportati i prodotti incorporati restituiti a livello di risposta (`embedded.products`) in forma di lista, raccolta `data` o mappa per ID prodotto.
- EAN, titolo e produttore vengono associati correttamente alle unità prima dell'applicazione dei filtri.
- La pagina usa nuove chiavi Streamlit v185 per evitare dati di sessione incompatibili con la versione precedente.
