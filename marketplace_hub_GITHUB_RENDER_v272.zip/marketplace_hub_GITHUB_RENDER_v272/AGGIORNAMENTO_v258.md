# Marketplace Hub v258 — Catalog Intelligence AI vincolata

## Obiettivo
La fase **Creazione Prodotti** integra ora un livello di intelligenza artificiale realmente operativo senza rendere l'AI autorità sulle regole del marketplace. Tassonomia ufficiale, attributi ufficiali e validatore deterministico restano la fonte di verità; l'AI serve a interpretare il prodotto quando il mapping tradizionale non è sufficiente.

## 1. Provider IA per Seller
- La pagina **Provider IA** è ora raggiungibile dalla navigazione principale.
- Ogni Seller può configurare uno o più provider/modelli già supportati da Marketplace Hub.
- Le chiavi continuano a essere salvate cifrate mediante il sistema credenziali esistente.
- I profili possono essere testati, attivati/disattivati e riutilizzati sia dai Ticket sia da Catalog Intelligence.
- Il controllo schema dei provider è memorizzato per processo/database per evitare DDL ripetuti a ogni rerun Streamlit.

## 2. Risoluzione AI delle categorie in REVIEW
Dopo la classificazione deterministica, la pagina **Creazione Prodotti → Determina categorie** espone un'azione opzionale per i prodotti rimasti in REVIEW.

Regole di sicurezza:
- l'AI riceve soltanto le categorie candidate già ottenute dalla tassonomia ufficiale;
- non può introdurre un category ID arbitrario;
- un ID fuori allow-list viene scartato e il prodotto resta in REVIEW;
- la risposta deve citare almeno un percorso realmente presente nei dati sorgente del prodotto;
- la soglia di auto-approvazione è configurabile dal Seller;
- sotto soglia la categoria proposta resta in REVIEW;
- una scelta AI non crea automaticamente una regola permanente di Knowledge Base: la promozione a regola riutilizzabile rimane una decisione umana.

## 3. Mapping AI degli attributi obbligatori mancanti
Durante **Prepara feed prodotti completi**, il motore esegue prima il mapping deterministico esistente.

L'AI viene chiamata solo se restano attributi ufficiali obbligatori non compilati e solo quando il Seller ha selezionato un profilo IA.

Per ogni proposta:
- l'attributo deve appartenere allo schema ufficiale della categoria;
- il valore deve derivare da un percorso reale del feed fornitore;
- il percorso di prova viene memorizzato;
- la confidence deve superare la soglia configurata;
- allowed values, tipo dato, unità e vincoli restano soggetti al validatore deterministico;
- una proposta non valida non rende pubblicabile il prodotto.

## 4. Memoria persistente e risparmio token
I mapping AI accettati vengono memorizzati nel database con provenienza **AI_EVIDENCE**. Alle aperture e preparazioni successive vengono riutilizzati prima di effettuare nuove chiamate al provider.

Sono state aggiunte le tabelle:
- `catalog_ai_runs`
- `catalog_ai_product_results`
- `product_ai_attribute_mappings`

Vengono conservati run, stato, provider/modello, risultati, motivazioni di rifiuto, evidence path, confidence e mapping accettati.

## 5. Storico AI in Creazione Prodotti
La scheda **Storico** mostra le esecuzioni Catalog Intelligence AI con:
- scopo;
- stato;
- prodotti elaborati;
- accettati/revisione/errori;
- profilo IA;
- data inizio/fine ed eventuale errore.

## 6. Validatore e pubblicazione
La pubblicazione continua a usare il flusso già protetto:

**feed fornitore → tassonomia ufficiale → mapping deterministico → AI opzionale vincolata → validatore deterministico → preparazione → pubblicazione**.

L'AI non bypassa `validate_canonical_product`, non può rendere READY una scheda che viola gli attributi ufficiali e non pubblica direttamente sui marketplace.

## 7. Compatibilità
Restano preservati:
- Kaufland e Worten/Mirakl;
- normalizzazione cataloghi v249-v252;
- Knowledge Base categorie;
- pubblicazione controllata prodotto + offerta;
- Packlink v255;
- Contabilità v257;
- database, `data`, Seller, ordini, storico, configurazioni e credenziali;
- auto-riparazione `_release_payload` e protezione anti-downgrade;
- avvio `estrai → AVVIA_WINDOWS.bat`.
