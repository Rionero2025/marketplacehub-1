# Marketplace Hub v148 — tracciabilità completa integrata

Questa versione integra direttamente nel pacchetto completo la funzione **Tracciabilità ordini** per Kaufland e Worten.

## Correzione principale Worten

L'ordine Worten nello stato `SHIPPING` può essere contrassegnato come spedito quando il file del fornitore riporta `SENT TO WAREHOUSE` e sono presenti tracking e corriere.

Caso verificato:

- ordine: `1106522536-A`;
- Customer Name: `Otilia Ferreira` / `Ferreira Otilia`;
- stato Worten: `SHIPPING`;
- stato Cecotec: `SENT TO WAREHOUSE`;
- tracking: `04308I811234`;
- corriere: `MRW`.

La sequenza API è:

1. Worten/Mirakl OR23: inserimento tracking e corriere;
2. Worten/Mirakl OR24: conferma della spedizione.

## Funzioni incluse

- nuova pagina `Tracciabilità ordini` nella navigazione principale;
- sincronizzazione ordini Kaufland e Worten;
- caricamento XLSX, XLS, CSV, TSV, TXT e PDF testuali;
- riconoscimento automatico del formato Cecotec Expedition;
- scelta manuale o riconoscimento automatico del fornitore;
- confronto per Customer Name, EAN, SKU, prodotto, email, telefono, indirizzo e data;
- gestione separata di `WAITING LABEL`, `CREATED`, `SENT TO WAREHOUSE`, stati in transito e annullamenti;
- tabella dettagliata degli abbinamenti modificabile;
- tabella aggregata con una riga per ordine;
- selezione singola o multipla degli ordini;
- invio reale di tracking, corriere e stato spedito;
- aggiornamento locale della Contabilità dopo la risposta API positiva;
- storico persistente delle importazioni e degli esiti API;
- nessuna colonna Streamlit riservata `_index`.

## Sicurezza

L'invio richiede la conferma testuale `SPEDISCI`. Ordini già spediti, rimborsati, annullati, senza tracking/corriere o con più tracking differenti vengono bloccati.
