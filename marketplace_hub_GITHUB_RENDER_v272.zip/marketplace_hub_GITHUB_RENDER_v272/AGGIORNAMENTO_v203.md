# Marketplace Hub v203 — Buy Box Kaufland da catalogo API completo

## Novità principali

- La Buy Box Kaufland non richiede più la scelta di un singolo listino.
- Le offerte vengono scaricate direttamente dall'account Kaufland con inventario paginato `GET /units` per tutti i Paesi selezionati.
- La sincronizzazione è persistente, riprendibile e può essere ricostruita integralmente.
- Ogni offerta reale viene confrontata con tutti i listini attivi accessibili al Seller.
- Il match utilizza, in ordine di affidabilità, storico di pubblicazione, prefisso fornitore, EAN e SKU/codice.
- La tabella mostra fornitore, listino abbinato, origine del costo e numero di corrispondenze trovate.

## Commissioni

- Per ogni EAN e storefront viene richiesta la tariffa corrente Kaufland in blocchi da 50 prodotti.
- Sono considerate sia la percentuale variabile sia l'eventuale quota fissa.
- Il programma calcola la commissione in euro e la percentuale effettiva sul totale corrente e sul prezzo necessario per la Buy Box.
- Se disponibile, viene mostrata separatamente l'ultima commissione realmente addebitata in un ordine dello stesso SKU/EAN.
- Se la tariffa corrente non è disponibile, il fallback segue questo ordine: ultimo ordine reale, regola commerciale del listino abbinato, ultima regola Kaufland del Seller.

## Gestione operativa

- Filtri per Paese, fornitore, listino e ricerca libera.
- Selezione totale, deselezione e intervallo Da/A.
- Visions salvate a livello account, senza listino artificiale di appoggio.
- Aggiornamenti prezzo registrati a livello account con il listino realmente abbinato, quando presente.
- Le azioni prezzo continuano a modificare soltanto il `minimum_price`; il prezzo principale resta invariato.
- Storico prezzi unificato per l'intero account Kaufland.

## Compatibilità dati

Le nuove tabelle sono aggiuntive e non cancellano né trasformano lo storico Buy Box delle versioni precedenti:

- `kaufland_buybox_account_checks`
- `kaufland_buybox_account_views`
- `kaufland_buybox_account_price_updates`
