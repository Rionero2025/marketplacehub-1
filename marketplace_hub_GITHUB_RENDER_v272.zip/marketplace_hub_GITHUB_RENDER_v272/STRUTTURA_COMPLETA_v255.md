# Marketplace Hub v255 — struttura e garanzie

Release: **255**

## Correzione principale
Packlink PRO usa gli ordini già presenti nella cache persistente e non li riscarica durante i normali rerun Streamlit. L'aggiornamento standard è incrementale; il refresh completo resta una scelta esplicita.

## File applicativi modificati
- `pages/4_Packlink_PRO.py`
- `services/cecotec_orders.py`
- `services/packlink.py`
- `services/accounting.py`
- `services/catalog_intelligence/__init__.py` (allineamento versione release)

## Contratti preservati
- distribuzione: `marketplace_hub.zip`
- avvio: estrai → `AVVIA_WINDOWS.bat`
- auto-riparazione dal `_release_payload`
- protezione anti-downgrade
- preservazione `data`, database, Seller, ordini, storico e configurazioni
- preservazione credenziali e `.streamlit/secrets.toml`
- riuso `.venv`/Python esistenti quando disponibili

## Verifica
- compilazione Python: OK
- release consistency gate: OK
- suite completa: **603 test + 6 subtest**
