# Marketplace Hub v211 — Packlink PRO: peso reale dai listini

## Obiettivo

La quotazione Packlink non deve usare il peso generico del pacco quando il peso reale del prodotto è disponibile nei listini associati al Seller.

## Nuova logica

- Marketplace Hub indicizza il campo normalizzato `weight_kg` di tutti i listini attivi accessibili al Seller.
- Viene letto anche l'ultimo snapshot salvato di ogni listino come fallback.
- Il prodotto viene riconosciuto prima per EAN/GTIN esatto e, quando necessario, per SKU/codice prodotto esatto, privilegiando il fornitore indicato nello SKU composito dell'ordine.
- Per ogni riga ordine il peso utilizzato è `peso unitario da listino × quantità`.
- Se tutte le righe dell'ordine hanno un peso reale, il peso Packlink è la somma esatta delle righe e il peso generico non viene usato.
- Se soltanto alcune righe hanno il peso, viene usata la somma dei pesi reali più il peso generico una sola volta come fallback prudenziale per la parte non riconosciuta.
- Se nessuna riga ha un peso disponibile, resta il peso generico configurato nel pacco Packlink.

## Interfaccia

La tabella ordini Packlink mostra ora:

- `Peso Packlink kg`
- `Origine peso`

Per ogni ordine selezionato viene inoltre mostrato il dettaglio prodotto per prodotto con quantità, peso unitario, peso totale della riga e listino utilizzato.

## Tariffe e bozza

Il peso specifico dell'ordine viene usato sia nella richiesta delle tariffe `GET /v1/services` sia nella creazione della bozza `POST /v1/shipments`. Le dimensioni del pacco restano quelle del pacco predefinito Packlink.

La cache delle tariffe include la firma dei pesi degli ordini: se cambia un listino o cambia il peso risolto, le vecchie tariffe non vengono riutilizzate per errore.

## Compatibilità

La modifica non altera ordini, database, API key, mittenti o listini. Il peso generico continua a essere disponibile esclusivamente come fallback per prodotti senza peso.
