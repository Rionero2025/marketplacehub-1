# Aggiornamento v196

## Buy Box Kaufland: classificazione corretta delle righe escluse

- Le righe con prezzo obiettivo Buy Box superiore al prezzo principale non sono più conteggiate come dati mancanti o non validi.
- Aggiunta la categoria separata «Obiettivo superiore al prezzo principale».
- «Dati realmente mancanti/non validi» comprende soltanto prezzo obiettivo assente/non positivo o dati economici insufficienti.
- Aggiunto un riepilogo esplicativo e una tabella con prezzo principale, obiettivo Buy Box e motivo dell'esclusione.
- La protezione operativa rimane invariata: il prezzo minimo Smart Pricing non viene impostato sopra il prezzo principale, che in questa sezione resta invariato.
