# Marketplace Hub v131

## Dashboard grafica e dinamica

- Nuova impaginazione moderna e responsive per tutti i seller.
- Numero di ordini evidenziato per oggi, settimana, mese e totale.
- Ogni ordine viene contato una sola volta anche se contiene più righe prodotto.
- Riepilogo generale di ordini, vendite e guadagno di tutti i seller.
- Aggiornamento visuale automatico ogni 30 secondi tramite fragment Streamlit.
- Polling facoltativo delle API ogni 5 minuti per nuovi ordini e stati degli ultimi 7 giorni.
- Blocco database per evitare richieste API duplicate da più schede aperte.
- Pulsante “Aggiorna adesso” per forzare la sincronizzazione.
- Ultimo orario di sincronizzazione e segnalazione di eventuali account non aggiornati.

## Nota sul tempo reale

Kaufland e Worten vengono controllati periodicamente: non è un webhook istantaneo. Un nuovo ordine appare normalmente entro il successivo controllo automatico (massimo circa 5 minuti), mentre i dati già presenti nel database vengono riletti ogni 30 secondi.
