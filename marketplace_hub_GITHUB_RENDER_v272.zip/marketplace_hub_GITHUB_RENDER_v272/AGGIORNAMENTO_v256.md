# Marketplace Hub v256 — Contabilità Innpro: costo solo da listino LIGHT

## Obiettivo
Per gli ordini del fornitore **Innpro / Innpro Fintrade**, la Contabilità deve usare come costo di acquisto esclusivamente il **prezzo all'ingrosso del listino LIGHT**. Il prezzo presente nel listino FULL non è più considerato un costo contabile valido.

## Correzioni v256

### 1. Priorità rigida al LIGHT Innpro
- Quando il fornitore dell'ordine è Innpro, il motore costi cerca l'EAN/GTIN esclusivamente nei cataloghi Innpro identificati come **LIGHT**.
- Il listino FULL può continuare a essere usato per anagrafica, descrizioni, immagini, parametri e altri contenuti prodotto, ma **non per il costo di acquisto in Contabilità**.
- Se FULL e LIGHT contengono lo stesso EAN con prezzi diversi, viene sempre preso il prezzo del LIGHT.

### 2. Riconoscimento del listino LIGHT
Il listino LIGHT viene riconosciuto in modo robusto tramite:
- nome listino (es. `Listino Light`);
- URL del feed contenente `light`;
- parametri URL come `type=light`, `feed=light`, `mode=light`, `variant=light` o `catalog=light`;
- percorso locale che identifica esplicitamente il feed LIGHT.

### 3. Nessun fallback al FULL
Se non esiste un listino LIGHT Innpro accessibile, oppure l'EAN non è presente nel LIGHT, il programma mostra il costo come non calcolabile invece di usare il prezzo del FULL.

I costi inseriti manualmente dall'utente restano autorevoli e persistenti.

### 4. Tracciabilità della fonte costo
La colonna **Fonte costo** indica esplicitamente `prezzo all'ingrosso LIGHT Innpro`, così è immediatamente verificabile da quale listino è stato preso il valore.

### 5. Compatibilità
Restano invariati:
- calcolo costi degli altri fornitori;
- ricerca EAN/GTIN esatta;
- modifiche manuali persistenti;
- ordini e storico contabile;
- Packlink v255 e correzioni v253/v254;
- database, Seller, credenziali, `data`, `.streamlit/secrets.toml` e `.venv`;
- auto-riparazione e protezione anti-downgrade.
