# Marketplace Hub v242 — Buy Box Kaufland persistente e controllo rapido

## Obiettivo

La pagina Buy Box Kaufland non riparte più dal download completo dell'account ad ogni utilizzo.
Le offerte già scaricate restano nel database `kaufland_live_units` e vengono caricate immediatamente all'apertura della pagina.

## Nuovo flusso quotidiano

1. Il catalogo offerte viene scaricato una prima volta e resta persistente nel database.
2. All'apertura successiva la pagina usa subito le offerte memorizzate.
3. Lo stato Buy Box già salvato viene mostrato nella griglia (`Ultimo stato Buy Box`, posizione e data/ora).
4. Il pulsante **Controlla solo se siamo ancora in Buy Box** esegue un solo `GET /buybox` per offerta selezionata.
5. Costi, commissioni, listino, logistica e altri dati statici vengono riutilizzati dall'ultimo controllo salvato.
6. Gli errori temporanei del check rapido non cancellano lo stato precedente valido.

## Controllo completo

Il vecchio controllo rimane disponibile come **Controllo completo (costi, commissioni e logistica)**.
Serve per la prima inizializzazione di offerte prive di `id_product` o quando si desidera ricalcolare costi, commissioni, logistica e abbinamenti ai listini.

## Inventario offerte

Il download `GET /units` è stato spostato nella sezione espandibile **Aggiorna inventario offerte via API (solo quando serve)**.
Una volta che le offerte sono in cache non è necessario eseguirlo per un normale controllo Buy Box.

## Prestazioni

- nessun `GET /units` nel percorso rapido;
- nessun lookup commissioni nel percorso rapido;
- nessuna ricerca prodotto/EAN nel percorso rapido;
- nessuna reindicizzazione listini quando tutte le offerte hanno già dati persistiti;
- una sola chiamata Buy Box live per offerta.

## Coerenza release

La copia `_release_payload` ora contiene tutto il codice Python di `app.py`, `launcher.py`, `pages/`, `services/` e `tools/`.
L'auto-riparazione all'avvio non usa più una lista manuale di pochi moduli: qualunque pagina o service disallineato viene ripristinato prima dell'avvio.

## Dati preservati

La release non elimina o ricrea database, `data`, Seller, account marketplace, storico, viste Buy Box o configurazioni.
