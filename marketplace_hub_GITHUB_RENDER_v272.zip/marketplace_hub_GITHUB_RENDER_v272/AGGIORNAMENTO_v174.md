# Marketplace Hub v174

## Correzione editor WYSIWYG con Streamlit moderno

La dipendenza risultava installata, ma streamlit-quill2 eseguiva durante
l'inizializzazione una chiamata vuota a `st.html`. Streamlit 1.59 e versioni
successive rifiutano esplicitamente un corpo HTML vuoto, provocando:

`StreamlitAPIException: st.html body cannot be empty`

La v174 applica una compatibilità locale e circoscritta: ignora soltanto la
chiamata HTML vuota del componente, senza alterare le chiamate HTML reali e
senza disattivare i controlli di Streamlit nel resto del programma.

Il file RIPARA_DIPENDENZE_WINDOWS.bat verifica inoltre che `streamlit_quill`
sia installato nello stesso interprete Python utilizzato dall'applicazione.
