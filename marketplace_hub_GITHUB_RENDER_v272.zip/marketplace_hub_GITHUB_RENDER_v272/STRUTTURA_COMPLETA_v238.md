# Marketplace Hub v238 — struttura completa

- `pages/`: 23 file
- `services/`: 45 file
- `tests/`: 74 file
- `tools/`: 12 file
- `_release_payload/`: 6 file

Release completa con avvio unico `AVVIA_WINDOWS.bat`.
La v238 riutilizza il Python/Streamlit già presenti sul PC e non crea una nuova `.venv` solo perché il pacchetto è stato estratto nuovamente.
Restano incluse l'auto-riparazione Packlink v237 e la correzione Paese + Città/codice postale v235.
