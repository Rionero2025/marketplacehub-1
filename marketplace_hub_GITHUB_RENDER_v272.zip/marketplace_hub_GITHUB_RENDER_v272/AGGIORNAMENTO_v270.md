# Marketplace Hub v270 — Packlink: combinazione automatica e CSV completo

## Nuovo comando automatico

Nella pagina **Packlink PRO**, nella sezione di esportazione CSV, è stato aggiunto il pulsante:

**Genera automaticamente migliore combinazione + CSV completo**

Il comando lavora su tutti gli ordini selezionati in un'unica operazione.

Per ogni ordine Marketplace Hub:

1. considera soltanto configurazioni pacco sicure e pertinenti a quello specifico ordine:
   - pacco automatico dell'ordine;
   - valori correnti eventualmente modificati dall'utente;
   - ultimo pacco realmente usato per quello stesso ordine, se disponibile;
2. interroga Packlink per le tariffe disponibili per ciascuna configurazione;
3. seleziona la combinazione **pacco + servizio con prezzo totale più basso**;
4. applica automaticamente peso e dimensioni scelti all'ordine;
5. preseleziona la tariffa scelta anche nelle schede Packlink di Marketplace Hub;
6. prepara il CSV ufficiale Packlink con i dati correnti di tutti gli ordini selezionati.

## Sicurezza sulle dimensioni

La ricerca automatica non prova pacchi generici appartenenti ad altri prodotti soltanto per ottenere un prezzo più basso. Questo evita di scegliere automaticamente dimensioni non compatibili con la merce.

## CSV completo

Il download speciale **CSV completo generato automaticamente** viene reso disponibile soltanto quando tutti gli ordini selezionati hanno i dati obbligatori richiesti da Packlink.

Se un ordine è incompleto, Marketplace Hub indica quanti ordini devono ancora essere corretti; email e telefono possono essere completati con gli strumenti introdotti nella v269.

Il file mantiene il tracciato ufficiale Packlink PRO a 30 colonne.

> Nota: il modello CSV ufficiale Packlink non contiene colonne per corriere o servizio. La tariffa più conveniente viene quindi mostrata nel riepilogo e resta preselezionata in Marketplace Hub, mentre il CSV contiene peso e dimensioni della combinazione scelta.

## Protezione da CSV obsoleto

Il CSV automatico viene marcato con la configurazione corrente di ordini, contatti, pacchi, valore dichiarato, mittente e assicurazione. Se uno di questi dati cambia dopo la generazione, il vecchio download viene nascosto e viene richiesto di rigenerare il file.

## Compatibilità

- nessuna migrazione database;
- nessuna modifica al formato CSV ufficiale Packlink;
- resta disponibile il download CSV manuale/corrente già esistente;
- resta disponibile la creazione massiva via API;
- release e Catalog Intelligence allineati a v270.
