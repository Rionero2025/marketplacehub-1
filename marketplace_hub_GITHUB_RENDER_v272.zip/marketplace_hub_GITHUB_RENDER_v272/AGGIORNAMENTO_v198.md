# Aggiornamento v198 — parità operativa Buy Box Worten / Kaufland

## Obiettivo

La pagina **Buy Box Worten** adotta la stessa struttura operativa e le stesse
protezioni economiche della pagina **Buy Box Kaufland**, mantenendo le differenze
tecniche imposte dalle rispettive API.

## Selezione e controllo offerte

- selezione totale e deselezione totale;
- selezione per intervallo libero **Da posizione / A posizione**, con estremi inclusi;
- ricerca per EAN, SKU, prodotto e categoria;
- controllo in blocchi automatici compatibili con il limite Mirakl P11;
- memoria delle selezioni durante i rerun Streamlit.

## Visioni, filtri e statistiche

- salvataggio di fotografie nominate con data e ora;
- scelta dell'ultima versione o di una visione storica in sola lettura;
- filtri Buy Box per vinte, perse e non trovate;
- filtri economici per guadagno, perdita, margine sotto il 10% e righe non calcolabili;
- filtro margine per intervallo, soglia minima ed esclusione sotto soglia;
- ricerca nei risultati per EAN, SKU, categoria e vincitore;
- metriche Buy Box ed economiche complete;
- esportazione CSV della visione attiva.

## Tabella operativa

- selezione di una o più righe e selezione dell'intero blocco filtrato;
- colori coerenti con Kaufland: verde per risultato positivo, rosso per perdita,
  giallo per margine inferiore al 10%;
- modifica manuale del prezzo da inviare;
- allineamento multiplo al totale vincente;
- ripristino dei prezzi correnti;
- riepilogo delle righe sicure, a basso margine, in perdita e non calcolabili.

## Protezioni e invio prezzi

- conferma separata per includere righe con margine inferiore al 10%;
- conferma esplicita e nominativa per includere righe in perdita;
- esclusione delle righe con dati economici mancanti o prezzo non valido;
- anteprima e download del CSV OF01;
- invio prezzi in modalità `UPDATE` senza ricreare o cancellare l'offerta;
- verifica dello stato dell'ultimo import e storico delle modifiche effettuate.

## Differenze tecniche mantenute

Kaufland aggiorna il `minimum_price` Smart Pricing e può modificare i giorni di
gestione della singola unità. Worten aggiorna il prezzo principale dell'offerta
tramite import Mirakl OF01. L'interfaccia e le verifiche economiche sono state
allineate senza simulare funzioni non esposte dall'API Worten utilizzata.

## Verifiche

- compilazione sintattica di tutti i moduli Python del progetto;
- test automatici del progetto;
- verifica della presenza nel pacchetto di pagine, servizi, test, template e
  file di avvio Windows.
