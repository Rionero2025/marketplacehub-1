# Aggiornamento v114 — compatibilità installazioni miste

## Errori corretti

- `ImportError: cannot import name 'apply_offer_editor_changes'`
- `KeyError: 'sku_ean_note'`

Questi errori possono comparire quando le nuove pagine vengono copiate mentre
Streamlit è ancora in esecuzione e Python conserva in memoria una versione
precedente dei moduli interni.

## Correzione Worten

Le funzioni operative della Buy Box sono ora contenute in un modulo dedicato
nuovo. La pagina non dipende più dalla presenza delle nuove funzioni nella
vecchia copia di `services/worten.py`.

Restano incluse:

- selezione singola, multipla e di tutte le Buy Box filtrate;
- filtri Vinte, Perse e Non trovate;
- filtro del margine potenziale;
- prezzo allineato o modificabile nella cella;
- controlli di perdita e margine;
- invio prezzi esclusivamente su `WRT_PT_ONLINE`.

## Correzione ordini Kaufland

La tabella ricostruisce automaticamente `sku_ean_note` e tutte le altre colonne
facoltative quando proviene da dati o servizi caricati con una versione
precedente. L'assenza di una colonna informativa non blocca più l'intera pagina.

## Installazione

1. Chiudere il browser.
2. Chiudere completamente la finestra nera di `AVVIA_WINDOWS.bat`.
3. Verificare nel Task Manager che non siano rimasti processi `python.exe` o
   `streamlit.exe` relativi a Marketplace Hub.
4. Sovrascrivere tutti i file con la v114.
5. Conservare la cartella `data`.
6. Riavviare con `AVVIA_WINDOWS.bat`.

## Verifica

Compilazione completata e 156 test automatici superati.
