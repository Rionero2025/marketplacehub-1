# Marketplace Hub v233 — struttura completa

Pacchetto autonomo Windows con avvio unico tramite `AVVIA_WINDOWS.bat`.

## Contenuto

- Pagine Streamlit: **23**
- Servizi Python: **44**
- Test automatici: **70**
- Strumenti Python: **12**
- File complessivi prima del manifesto: **358**

## Packlink v233

La release mantiene la ricostruzione fresca del destinatario immediatamente prima del POST e aggiunge il flusso di registrazione dell'integrazione previsto dal core Packlink corrente: `POST /v1/integrations`, memorizzazione dell'`integration_id` e inclusione dell'ID nel draft. Se la registrazione viene rifiutata, la creazione delle bozze viene bloccata prima di `POST /v1/shipments`.

L'avvio normale sincronizza automaticamente il codice dell'applicazione senza richiedere un aggiornamento manuale separato e preserva `data`, database, `.streamlit/secrets.toml` e `.venv`.
