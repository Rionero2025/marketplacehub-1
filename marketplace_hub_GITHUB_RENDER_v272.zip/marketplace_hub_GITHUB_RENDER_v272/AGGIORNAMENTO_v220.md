# Marketplace Hub v220 — Packlink: rigenerazione con memoria esatta

## Novità
- Tasto **Seleziona tutti da rigenerare** per tutti gli ordini già organizzati su Packlink.
- Tasto **Deseleziona tutti**.
- Quando un ordine viene rigenerato, Marketplace Hub ripropone per primo **l'ultimo pacco esatto usato per quello stesso ordine**.
- Peso, lunghezza, larghezza e altezza vengono letti dal `request_json` realmente inviato a Packlink nella spedizione precedente.
- Vengono mantenuti e mostrati anche **servizio, corriere e costo storico** della precedente spedizione.
- Dopo il ricalcolo tariffe, il servizio usato in precedenza viene marcato con **USATO PRIMA**, ma il prezzo mostrato resta quello corrente restituito da Packlink.
- La creazione forzata continua a conservare tutte le versioni nello storico `packlink_order_draft_history`.

## Regola prezzi
Il costo storico viene conservato come informazione della spedizione precedente. Per una nuova spedizione Marketplace Hub non forza un vecchio prezzo: il costo effettivo della nuova bozza resta quello corrente restituito da Packlink.
