# Marketplace Hub v241 — gate di coerenza release

Questa release introduce una regola strutturale per impedire pacchetti o installazioni miste.

- A parità di VERSION.txt, `AVVIA_WINDOWS.bat` non confronta più un elenco manuale di pochi file: confronta tutto il codice sotto `pages/`, `services/`, `tools/` più `app.py`, `launcher.py` e gli script di avvio.
- Se anche un singolo file applicativo è diverso, l'avvio sincronizza automaticamente il codice prima di aprire Streamlit.
- La verifica post-sincronizzazione controlla tutti gli stessi file e interrompe l'avvio se uno non è stato copiato correttamente.
- `services/packlink_csv.py` rientra quindi sempre nel controllo e non può più restare vecchio mentre `pages/4_Packlink_PRO.py` è nuovo.
- Prima della distribuzione viene eseguito `tools/verify_release_consistency.py`, che verifica import locali, simboli richiesti e copie `_release_payload`.

I dati persistenti (`data`, database, Seller, ordini, configurazioni, secrets) restano esclusi dalla sincronizzazione del codice.
