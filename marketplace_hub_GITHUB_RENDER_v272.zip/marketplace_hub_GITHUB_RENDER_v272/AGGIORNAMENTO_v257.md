# Marketplace Hub v257 — Contabilità: selezione persistente dei listini costo

## Obiettivo
La Contabilità non deve più decidere in modo implicito quali listini possono determinare il costo di acquisto. Il Seller può scegliere e deselezionare in modo esplicito i listini autorizzati al calcolo della colonna **Acquisto €**.

## Correzioni v257

### 1. Selettore listini in Contabilità
- Nella pagina **Contabilità** compare la sezione **Listini da usare per il costo di acquisto**.
- Ogni listino accessibile è mostrato come `Fornitore · Nome listino`.
- È possibile selezionare/deselezionare singoli listini, selezionarli tutti o deselezionarli tutti.
- La scelta è persistente per Seller e resta valida dopo chiusura/riavvio del programma.

### 2. Whitelist autorevole
- Dopo la prima modifica dell'utente, la selezione diventa una whitelist esplicita.
- Un listino deselezionato non viene caricato dal motore costi della Contabilità.
- Le viste salvate ereditano l'abilitazione del relativo listino padre.
- Nuovi listini aggiunti successivamente non entrano automaticamente nella whitelist già configurata: devono essere abilitati dall'utente.

### 3. Ricalcolo coerente
- Il pulsante diventa **Ricalcola costi con i listini selezionati**.
- Se un vecchio costo automatico proveniva da un listino poi deselezionato, il ricalcolo non conserva più quel costo come fallback.
- Se nessuno dei listini selezionati contiene l'EAN, il costo automatico viene lasciato non calcolabile invece di mantenere un valore proveniente da una fonte esclusa.
- I costi inseriti manualmente restano persistenti e autorevoli.

### 4. Innpro
- È quindi possibile lasciare selezionato **Innpro Fintrade · Listino Light** e deselezionare **Innpro Fintrade · Listino Full**.
- Resta anche la protezione v256: per Innpro il prezzo FULL non viene usato come costo automatico.

### 5. Compatibilità
Restano invariati:
- ordini e storico Contabilità;
- sincronizzazione incrementale;
- dati, Seller, credenziali e configurazioni;
- Packlink v255 e correzioni precedenti;
- auto-riparazione dal `_release_payload`;
- protezione anti-downgrade;
- avvio `estrai → AVVIA_WINDOWS.bat`.
