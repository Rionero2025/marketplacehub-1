# Marketplace Hub v230 — destinatario Packlink ricostruito al momento del POST

## Problema corretto
In alcune rigenerazioni massive il riepilogo dell'ordine mostrava correttamente, ad esempio, `04011 Kosice Lorincik · SK`, mentre una candidatura Streamlit precedente poteva mantenere uno snapshot dell'ordine e il draft Packlink risultava con Paese/codice postale non coerenti o incompleti.

## Correzione
- nuova chiave batch `packlink_batch_candidate_v230_*`, così nessuna candidatura legacy viene riutilizzata;
- ogni candidato massivo viene aggiornato con l'ordine corrente prima dell'invio;
- immediatamente prima di `POST /v1/shipments`, l'ordine viene risolto nuovamente per `order_key`;
- il blocco `to` viene ricostruito dai campi normalizzati correnti dell'ordine (`country_code`, `postal_code`, `city`, `address`, cliente, telefono, email);
- `raw_json` resta solo fallback per campi mancanti e non può sostituire un Paese/CAP/città già presenti nella riga corrente;
- controllo pre-POST: se `to.country`, `to.zip_code` o `to.city` non coincidono con l'ordine corrente, la bozza non viene inviata;
- ogni scheda mostra `Destinazione che verrà inviata a Packlink` prima della creazione.

## Compatibilità con il core Packlink ufficiale
Il payload continua a seguire il DTO ufficiale `Draft\Address`: `country`, `zip_code`, `city`, oltre agli altri campi di indirizzo. `platform_country` resta il Paese dell'account/mittente e non viene usato come destinazione. Il mittente continua a usare il vero `selectedWarehouseId` Packlink.

## Rigenerazione
Restano invariati pacco, peso/dimensioni, tariffa storica, corriere, servizio, service_id, costo e valore dichiarato già memorizzati.

## Test
- caso regressione esplicito: mittente IT + destinatario `Marek Kandra / 04011 Kosice Lorincik / SK`;
- blocco automatico di un payload che tenti di inviare `IT` al posto di `SK`;
- suite completa: 471 test + 6 subtest.
