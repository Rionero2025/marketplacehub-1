# Marketplace Hub v166

## Creazione ordini Cecotec: selezione realmente trasferita

- Corretto il caso in cui le righe risultavano visivamente spuntate in AgGrid, ma la sezione **Controllo e generazione file Cecotec** mostrava ancora “Seleziona almeno una riga ordine dalla tabella”.
- La risposta vuota emessa da AgGrid al primo rendering in modalità manuale non cancella più la selezione persistente salvata in `st.session_state`.
- I pulsanti **Seleziona tutti filtrati**, **Deseleziona tutti filtrati** e **Azzera selezione** continuano a operare immediatamente.
- Le selezioni manuali multiple vengono trasferite premendo **Applica** nel componente AgGrid.
- Aggiunto un fallback di riconoscimento tramite coppia `Ordine + Riga` per le versioni di streamlit-aggrid che non restituiscono la colonna nascosta `row_key`.
