# Marketplace Hub v221 — correzione allineamento Packlink

Questa release corregge l'ImportError su `last_order_draft_configuration` assicurando che pagina Packlink e servizio Packlink siano distribuiti e installati insieme.

- `services/packlink.py` espone `PACKLINK_SERVICE_VERSION = 221` e `last_order_draft_configuration`.
- `pages/4_Packlink_PRO.py` verifica il simbolo e la versione del servizio prima dell'import diretto.
- resta invariata la memoria v220: la rigenerazione massiva ripristina per ogni ordine l'ultima configurazione Packlink realmente usata, salvo modifica manuale del singolo ordine.
- l'installer v221 copia pagina e servizio insieme, cancella le cache `__pycache__` e verifica l'import prima di terminare.
