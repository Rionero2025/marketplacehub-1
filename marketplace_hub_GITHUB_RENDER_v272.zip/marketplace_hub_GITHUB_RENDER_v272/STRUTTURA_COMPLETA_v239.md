# Marketplace Hub v239 — struttura completa

Release completa con export CSV ufficiale Packlink PRO.

- Pagine Python: **23**
- Servizi Python: **45**
- File test: **75**
- Template: **2**

## Novità Packlink CSV
- `services/packlink_csv.py`: generatore CSV ufficiale a 30 colonne.
- `templates/csv_pro.csv`: template italiano ufficiale allegato dall’utente.
- `pages/4_Packlink_PRO.py`: download `packlink_pro_import.csv` dagli ordini selezionati.
- CAP mantenuti come testo, assicurazione `yes/no`, decimali con punto.

## Pagine
- `pages/0_Dashboard.py`
- `pages/1_Gestione_Seller.py`
- `pages/2_Fornitori_e_Listini.py`
- `pages/2_Provider_IA.py`
- `pages/3_Assistenza_Kaufland.py`
- `pages/3_Assistenza_Marketplace.py`
- `pages/3_Cancellazione_Kaufland.py`
- `pages/3_Cancellazione_Marketplace.py`
- `pages/3_Cancellazione_Worten.py`
- `pages/3_Controllo_BuyBox.py`
- `pages/3_Controllo_BuyBox_Worten.py`
- `pages/3_Lavora_sui_Listini.py`
- `pages/3_Ordini_Kaufland.py`
- `pages/3_Ordini_Marketplace.py`
- `pages/3_Pubblicazione_Kaufland.py`
- `pages/3_Pubblicazione_Marketplace.py`
- `pages/3_Pubblicazione_Worten.py`
- `pages/4_Contabilita.py`
- `pages/4_Ordini_Cecotec.py`
- `pages/4_Packlink_PRO.py`
- `pages/4_Storico.py`
- `pages/4_Tracciabilita_Ordini.py`
- `pages/5_Database.py`

## Servizi
- `services/abonline.py`
- `services/accounting.py`
- `services/accounting_pdf.py`
- `services/activeshop.py`
- `services/ai_providers.py`
- `services/batch_memory.py`
- `services/cecotec_orders.py`
- `services/dashboard.py`
- `services/database_config.py`
- `services/db.py`
- `services/deletion_scope.py`
- `services/fx.py`
- `services/kaufland.py`
- `services/kaufland_bulk_deletion.py`
- `services/kaufland_buybox.py`
- `services/kaufland_buybox_account.py`
- `services/kaufland_history.py`
- `services/kaufland_inventory_deletion.py`
- `services/kaufland_live_inventory.py`
- `services/kaufland_offer.py`
- `services/kaufland_order_costs.py`
- `services/kaufland_orders.py`
- `services/kaufland_profit.py`
- `services/kaufland_support.py`
- `services/lists.py`
- `services/marketplace_order_states.py`
- `services/order_selection.py`
- `services/order_tracking.py`
- `services/packlink.py`
- `services/packlink_csv.py`
- `services/packlink_order_import.py`
- `services/postgresql_backend.py`
- `services/profit_sharing.py`
- `services/security.py`
- `services/session.py`
- `services/shipping_deadlines.py`
- `services/supplier_documents.py`
- `services/support_connectors.py`
- `services/support_hub.py`
- `services/tracking_shipping_rules.py`
- `services/worten.py`
- `services/worten_buybox_actions.py`
- `services/worten_support.py`
- `services/worten_tracking_api.py`
- `services/wysiwyg.py`
