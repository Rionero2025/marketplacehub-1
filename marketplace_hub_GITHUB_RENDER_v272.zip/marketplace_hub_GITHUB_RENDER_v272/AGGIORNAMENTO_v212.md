# Marketplace Hub v212 — Packlink PRO: selezione ordini da documenti e pacco per singolo ordine

## Obiettivo

Velocizzare la preparazione delle spedizioni Packlink partendo dagli ordini marketplace e gestire peso/volumetria in modo corretto per ogni singolo collo.

## Selezione automatica ordini da file

Nella pagina Packlink PRO è disponibile **Selezione automatica da file**.

Formati supportati:

- TXT / CSV / TSV / RTF
- Excel XLSX / XLS
- Word DOCX e compatibilità best-effort DOC
- PDF testuali e PDF scansiti
- screenshot/immagini PNG, JPG, JPEG, WEBP, BMP, TIF/TIFF

Il programma legge i numeri ordine presenti nei file, li confronta con gli ordini già presenti per i marketplace/account selezionati e aggiunge i match alla selezione persistente della tabella. Gli ordini selezionati manualmente non vengono persi.

Il riepilogo mostra file letti, ordini trovati, candidati non abbinati ed eventuali errori. Per screenshot e PDF scansiti viene usato Tesseract OCR quando installato sul PC.

## Peso e volumetria per singolo ordine

Peso, lunghezza, larghezza e altezza non sono più configurati globalmente nella parte alta della pagina.

Ogni ordine selezionato ha i propri campi:

- Peso (kg)
- Lunghezza (cm)
- Larghezza (cm)
- Altezza (cm)

Il peso reale ricavato dai listini del Seller continua a essere proposto automaticamente. Le dimensioni vengono proposte dalla memoria dell'ultimo pacco usato per la stessa composizione prodotti oppure, quando non esiste una memoria, dal template Packlink disponibile come inizializzazione.

## Memoria pacchi

Quando una bozza Packlink viene creata con successo, Marketplace Hub salva automaticamente il pacco usato:

- peso
- lunghezza
- larghezza
- altezza
- numero di utilizzi
- data ultimo utilizzo
- composizione prodotti/quantità dell'ordine

I pacchi salvati restano persistenti nel database per il Seller e vengono riproposti tramite radio button negli ordini futuri. Per la stessa composizione prodotti viene proposta automaticamente l'ultima volumetria utilizzata, mantenendo come prima scelta il peso attuale ricavato dai listini.

## Tariffe Packlink

Le tariffe sono legate alla firma del pacco del singolo ordine. Se peso o dimensioni cambiano, le tariffe precedenti diventano obsolete e il programma richiede il ricalcolo.

È possibile:

- calcolare le tariffe per tutti gli ordini selezionati;
- ricalcolare le tariffe per un solo ordine;
- scegliere manualmente il servizio per ogni ordine con radio button.

Nessun servizio viene preselezionato automaticamente: prima della bozza è richiesta una scelta esplicita.

## Database

Sono aggiunte automaticamente le tabelle:

- `packlink_package_profiles`
- `packlink_product_package_memory`

Compatibili con SQLite e PostgreSQL. Nessuna tabella esistente viene cancellata.
