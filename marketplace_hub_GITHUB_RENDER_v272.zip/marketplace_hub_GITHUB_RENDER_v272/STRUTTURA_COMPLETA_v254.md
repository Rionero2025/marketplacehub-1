# Marketplace Hub v254 — struttura e garanzie

Release completa costruita sulla baseline stabile v243 e su tutte le evoluzioni fino alla v253.

## Componenti
- pagine Streamlit: 24
- servizi Python: 65
- strumenti Python: 24 (incluso verificatore v254)
- file Python applicativi principali: 115
- test automatici: 92

## Correzione v254
- L'avvio riconosce e rimuove automaticamente file Python applicativi obsoleti rimasti da estrazioni sopra release precedenti.
- `_release_payload` è la fonte autorevole del codice Python della release corrente.
- La pulizia riguarda esclusivamente `app.py`, `launcher.py` e i `.py` sotto `pages`, `services`, `tools`.
- `data`, database, Seller, ordini, storico, configurazioni, credenziali, `.streamlit/secrets.toml`, `.venv` e runtime non vengono toccati.
- Dopo la pulizia viene eseguito il normale riallineamento hash e il release consistency gate.
- Gli errori relativi a vecchi `services/accounting_costs.py` e `services/marketplace_deletion.py` vengono quindi risolti automaticamente.

## Funzioni Packlink preservate
- invio massivo con tariffe selezionate manualmente;
- fallback del telefono destinatario sul telefono mittente quando il cliente non lo fornisce;
- CSV Packlink indipendente dall'esito della creazione API.

## Auto-riparazione
Tutto il codice Python applicativo distribuito è duplicato in `_release_payload` e verificato prima dell'avvio.

## Distribuzione
Il file distribuito si chiama sempre `marketplace_hub.zip`.
Flusso utente: estrai -> `AVVIA_WINDOWS.bat`.
Nessun aggiornamento manuale separato.
