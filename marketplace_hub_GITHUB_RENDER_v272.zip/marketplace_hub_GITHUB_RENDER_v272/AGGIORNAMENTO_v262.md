# Marketplace Hub v262 — Creazione Ordini INNPRO

## Nuova sezione
Aggiunta nel menu principale la pagina **Creazione Ordini INNPRO**.

La pagina permette di:
- scegliere Seller, marketplace e account;
- lavorare con ordini Kaufland e Worten già supportati dall'archivio ordini condiviso;
- sincronizzare/aggiornare gli ordini per intervallo date;
- filtrare per stato, cercare ordini/prodotti e mostrare solo le righe INNPRO;
- selezionare una o più righe ordine tramite checkbox;
- riconoscere gli SKU composti il cui fornitore contiene `INNPRO` senza distinzione maiuscole/minuscole;
- estrarre l'EAN dal secondo valore dello SKU composto `fornitore_codice_costo_prezzominimo`;
- validare realmente l'EAN-13, incluso il check digit;
- escludere e spiegare le righe non INNPRO o con EAN non valido;
- accorpare gli EAN duplicati sommando le quantità;
- generare il file INNPRO esattamente nel formato dell'esempio fornito: nessuna intestazione, separatore `;`, righe `EAN;quantità`.

## Sicurezza operativa
La selezione parte vuota. Il file considera soltanto le righe scelte dall'utente e le righe non valide non vengono mai inserite silenziosamente nell'export.

## Compatibilità preservata
Restano invariati Contabilità v259, backup compatto v261, Catalog Intelligence, Packlink v255, database, Seller, credenziali e avvio `estrai → AVVIA_WINDOWS.bat`.
