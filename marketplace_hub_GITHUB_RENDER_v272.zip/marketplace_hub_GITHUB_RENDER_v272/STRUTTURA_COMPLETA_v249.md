# Marketplace Hub v249 — struttura del pacchetto completo

La v249 parte dalla pietra miliare v243 e preserva integralmente Catalog Intelligence v244-v248. La release accelera la normalizzazione dei cataloghi, rende misurabile l'avanzamento e completa la lettura dei feed Innpro/IdoSell senza perdere marchio, descrizioni, immagini, documenti o parametri tecnici.

## Struttura Python

- `pages/`: 24 file Python
- `services/`: 65 file Python
- `services/catalog_intelligence/`: 19 file Python
- `tests/`: 87 file Python
- `tools/`: 19 file Python
- `_release_payload/`: 110 file Python auto-riparanti
- codice applicativo verificato e auto-riparabile: 110 file Python

## File applicativi principali modificati

- `pages/3_Creazione_Prodotti.py`
- `services/lists.py`
- `services/catalog_intelligence/__init__.py`
- `services/catalog_intelligence/normalization.py`
- `services/catalog_intelligence/mapping.py`
- `services/catalog_intelligence/feed.py`
- `services/catalog_intelligence/repository.py`
- `tools/verify_release_consistency.py`
- `tools/verify_package_v249.py`

## Test v249

- `tests/test_catalog_normalization_v249.py`
- `tests/test_innpro_full_feed_v249.py`
- `tests/test_catalog_feed_completeness_v249.py`
- compatibilità preservata in `tests/test_innpro_accounting.py`

## Documentazione e verifica

- `AGGIORNAMENTO_v249.md`
- `VALIDAZIONE_v249.txt`
- `STRUTTURA_COMPLETA_v249.md`
- `tools/verify_package_v249.py`
- `VERIFICA_PACCHETTO_v249_WINDOWS.bat`
- `MANIFESTO_SHA256_v249.txt`

## Flusso di normalizzazione ad alta velocità

```text
Vista salvata completa
→ lettura e hash dello snapshot
→ riutilizzo immediato se già completato con motore v249
→ piano colonne compilato una volta
→ lettura veloce tramite itertuples
→ upsert prodotti a batch in una sola transazione
→ salvataggio valori e provenienza tramite executemany
→ snapshot marcato COMPLETED soltanto a catalogo integro
```

La UI mostra percentuale, fase, prodotti letti, normalizzati e memorizzati, velocità, tempo trascorso e tempo residuo stimato.

## Marchio e feed completo Innpro/IdoSell

Il parser streaming preserva:

- `producer` come marchio commerciale, con priorità inferiore soltanto a un vero campo `brand`/`marca` valorizzato;
- nome prodotto e traduzioni disponibili;
- descrizione breve e descrizione lunga;
- tutte le immagini prodotto, mantenendo l'ordine/priorità del feed;
- icone separate dalle immagini utilizzate dai marketplace;
- documenti, manuali e allegati;
- parametri tecnici annidati;
- categoria, unità, serie, garanzia e URL della scheda prodotto;
- prezzi, stock, peso, EAN, SKU e varianti;
- tutti i campi originali in `source_attributes` per mapping, audit e sviluppi futuri.

Il mapping deterministico consulta anche `source_attributes.parameters`, quindi una caratteristica tecnica annidata può alimentare l'attributo ufficiale del marketplace quando nome/codice coincidono. Nessun dato viene inventato.

## Feed marketplace

- **Kaufland:** EAN, titolo, descrizione completa, descrizione breve, manufacturer/brand, MPN, categoria, tutte le immagini e attributi tecnici ufficiali mappati.
- **Worten/Mirakl:** identificativi, categoria, titolo, descrizione, brand, MPN, `image-1`…`image-N` e attributi del tenant.
- Documenti e URL scheda vengono inseriti quando lo schema ufficiale della categoria espone un attributo compatibile; in caso contrario restano conservati nel prodotto canonico e non vengono inviati come campi sconosciuti.

## Prestazioni misurate nell'ambiente di verifica

Benchmark sintetico completo da 7.056 righe:

- prima elaborazione: circa **4,10 secondi**;
- velocità osservata: circa **1.720 prodotti/secondo**;
- seconda apertura dello stesso snapshot tramite cache persistente: circa **0,15 secondi**.

Le prestazioni reali dipendono da PC, database e complessità del listino. Il test automatico impedisce il ritorno al percorso legacy riga-per-riga e verifica che 500 prodotti completino ampiamente sotto il limite previsto.

## Funzioni preservate

Restano incluse tutte le funzioni della pietra miliare v243 e delle release v244-v248: Seller, account, fornitori, listini, tassonomie cached-first, categorie Kaufland ufficiali, feed prodotto, pubblicazione controllata, Buy Box, cancellazione, Packlink PRO e CSV, ordini, tracking, contabilità, storico, SQLite/PostgreSQL, avvio unico e auto-riparazione del codice.
