# Marketplace Hub — aggiornamento v200

## Correzione Buy Box Worten

- Risolto l'errore `ImportError: cannot import name build_worten_price_update_plan`.
- Allineati `pages/3_Controllo_BuyBox_Worten.py` e `services/worten_buybox_actions.py`.
- Aggiunta compatibilità difensiva per installazioni aggiornate solo in parte: la pagina continua ad avviarsi anche quando il file di servizio precedente è ancora presente.
- Confermata la modalità automatica che prepara il prezzo consigliato per le Buy Box Worten perse.

## Installazione

Chiudere Marketplace Hub e sostituire l'intera cartella del programma, mantenendo la propria cartella `data` e il file `.streamlit/secrets.toml`.
