# Aggiornamento v191 — Memoria permanente e ripresa incrementale offerte Kaufland

## Obiettivo

Le offerte reali scaricate da Kaufland restano memorizzate per Seller, account, ambiente e Paese/storefront. La pagina usa subito la memoria locale e non ricostruisce il catalogo dai vecchi listini o dalle operazioni storiche.

## Primo scaricamento

- Scarica tutte le pagine di `GET /units/` per i Paesi selezionati.
- Salva ogni offerta usando la chiave autorevole `storefront + id_unit`.
- Memorizza dati prodotto, prezzo, quantità, stato, condizione e `date_lastchange_iso`.
- Registra l'ultima offerta scaricata, il relativo `id_unit` e la data dell'ultima modifica.

## Aggiornamenti successivi

Il pulsante diventa **Aggiorna offerte nuove e modificate**.

- Legge il manifest leggero delle unità senza riscaricare sempre i prodotti incorporati.
- Inserisce le offerte nuove.
- Aggiorna soltanto le offerte cambiate.
- Mantiene inalterate le righe identiche.
- Recupera il dettaglio prodotto soltanto per offerte nuove o con dati incompleti.
- Marca come non più presenti le offerte assenti soltanto al termine di un controllo completo e riuscito.

## Ripresa dopo interruzione

Per ogni storefront viene memorizzato un cursore con:

- posizione/offset dell'ultima pagina completata;
- ultima offerta letta;
- ultimo `id_unit`;
- ultima `date_lastchange_iso`;
- conteggi parziali;
- stato e messaggio dell'ultimo tentativo.

Se rete, API o programma interrompono il download, il successivo aggiornamento riparte dall'offset salvato senza ricominciare dalla prima pagina.

## Controllo di coerenza

L'API Kaufland documenta la paginazione tramite `limit` e `offset`, ma non un filtro `updated_since` per l'elenco delle unità. Per rilevare anche modifiche o cancellazioni eseguite fuori da Marketplace Hub, dopo una sincronizzazione completata viene quindi eseguito un controllo leggero delle pagine. Il database e i dettagli prodotto non vengono riscritti se l'offerta è invariata.

## Interfaccia

La tabella riepilogativa per Paese mostra:

- offerte reali presenti;
- ultima offerta scaricata;
- ID ultima unità;
- data ultima modifica offerta;
- ultimo aggiornamento riuscito;
- stato dell'ultimo controllo;
- eventuale posizione salvata per la ripresa.

È disponibile anche **Risincronizzazione completa**, protetta da conferma, per ricostruire la memoria locale e i dati prodotto.
