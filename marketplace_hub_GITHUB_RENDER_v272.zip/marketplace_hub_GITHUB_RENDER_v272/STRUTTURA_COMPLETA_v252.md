# Marketplace Hub v252 — struttura e garanzie

Release completa costruita sulla baseline v243 e sulle funzioni Catalog Intelligence v244-v251.

## Componenti
- pagine Streamlit: 24
- servizi Python: 65
- strumenti Python: 22
- file Python applicativi principali: 113
- test automatici: 90

## Correzioni v252
- Recupero automatico del full feed sorgente quando una vecchia vista salvata contiene soltanto EAN/SKU/prezzo/stock.
- `producer` Innpro valorizza realmente `brand/Marca`.
- Descrizione lunga/breve, URL immagini, documenti e parametri del full feed vengono riportati nel prodotto canonico.
- Griglia Catalogo sorgente mostra Marca, Descrizione, URL immagine principale, URL immagini e numero immagini.
- Persistenza Catalog Intelligence a basso numero di scritture: raw supplier record una sola volta, JSON canonico compatto, provenance compatta e marker cache leggero.
- Batch di salvataggio da 1200 prodotti, con commit e contatori progressivi.
- Provenienza ricostruibile on-demand dal raw feed e dalla mappa `_provenance`.
- Conservate le protezioni WAL/busy-timeout/schema process-scoped della v251.

## Auto-riparazione
Tutto il codice Python applicativo è duplicato in `_release_payload` e verificato prima della distribuzione.

## Distribuzione
Il file distribuito si chiama sempre `marketplace_hub.zip`.
Flusso utente: estrai -> `AVVIA_WINDOWS.bat`.
Nessuna installazione o aggiornamento manuale separato.
