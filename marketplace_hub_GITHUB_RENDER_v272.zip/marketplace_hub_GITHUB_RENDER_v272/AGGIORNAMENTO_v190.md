# Aggiornamento v190 — Offerte Kaufland reali per Paese

La pagina **Cancellazione dai Marketplace → Kaufland** non ricostruisce più il catalogo da operazioni storiche o snapshot locali.

## Funzioni

- Pulsante **Scarica offerte presenti sul marketplace**.
- Lettura delle unità reali tramite API Kaufland, con paginazione completa per storefront.
- Conteggio separato per Paese/storefront.
- Selezione di un solo Paese o di tutti i Paesi con checkbox in form, senza rerun a ogni spunta.
- Primo scaricamento completo con dati prodotto.
- Aggiornamenti successivi più leggeri: confronto degli ID unità e dei campi modificati; recupero dettagli solo per offerte nuove o incomplete.
- Memoria permanente separata per Seller, account, ambiente e storefront.
- Le offerte non più restituite da una sincronizzazione completata vengono marcate come non presenti e non sono conteggiate.
- Duplicati eliminati usando la chiave autorevole `storefront + id_unit`.
- Filtri per Paese, fornitore, listino, prezzo, quantità, stato, condizione, SKU, EAN, prodotto e produttore.
- Selezione multipla AgGrid senza rerun continuo.
- Cancellazione di tutte le offerte dei Paesi selezionati oppure soltanto delle righe scelte.
- Verifica API obbligatoria immediatamente prima della cancellazione.
- Verifica finale delle offerte residue.
- Storico compatto: vengono conservati riepilogo ed errori, non migliaia di payload completi.

## Sicurezza

Le cancellazioni sono eseguite esclusivamente sugli `id_unit` restituiti dalla sincronizzazione live. Se un Paese non può essere aggiornato, l'operazione globale viene bloccata prima di cancellare qualsiasi offerta.
