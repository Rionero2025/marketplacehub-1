# Marketplace Hub v231 — correzione NameError rigenerazione massiva Packlink

## Problema corretto
La pagina Packlink v230 poteva interrompersi nella sezione **Pacco e tariffe Packlink per gli ordini selezionati** con:

`NameError: name 'current_order' is not defined`

Il difetto era nella funzione `_existing_shipping(order)`: il controllo delle spedizioni già organizzate veniva eseguito durante il rendering dei controlli massivi, ma la funzione costruiva la chiave usando `current_order`, variabile locale definita soltanto più avanti dentro `_create_draft_for_order()`.

## Correzione
- `_existing_shipping(order)` usa esclusivamente il parametro `order` ricevuto;
- la chiave di confronto resta `marketplace_account_id + marketplace + order_id`;
- nessuna modifica alla memoria tariffa/pacco, alla rigenerazione massiva o alla ricostruzione fresca del destinatario v230;
- release applicativa v231; il contratto del servizio Packlink resta compatibile v230 perché `services/packlink.py` non cambia funzionalmente.

## Regressione coperta
Un test AST controlla che `_existing_shipping` non possa più caricare il nome `current_order` e che il bulk continui a chiamare `_existing_shipping(item)` per ciascun ordine selezionato.
