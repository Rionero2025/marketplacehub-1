# Marketplace Hub v234 — ripristino Packlink PRO diretto

## Correzione
La v233 aveva reso obbligatoria la registrazione del negozio con `POST /v1/integrations` prima di usare Packlink.
Per Marketplace Hub questa registrazione custom può essere rifiutata da Packlink e bloccava una API key che nelle versioni precedenti creava già correttamente le bozze.

La v234 ripristina la modalità diretta Packlink PRO:
- autenticazione con la API key già configurata;
- nessuna registrazione negozio obbligatoria all'apertura della pagina;
- creazione bozza direttamente con `POST /v1/shipments`;
- `source=PRO`, come nelle release precedenti alla v233;
- nessun `integration_id` viene creato artificialmente;
- restano tutte le correzioni su memoria tariffa/pacco, rigenerazione massiva, warehouse mittente e ricostruzione destinatario.

## Avvio
Estrarre il pacchetto e usare soltanto `AVVIA_WINDOWS.bat`.
