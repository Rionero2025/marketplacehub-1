# Aggiornamento v116 — costo di acquisto ordini Kaufland

## SKU composto

Il costo di acquisto viene letto partendo da destra nel formato:

`fornitore_codice_costoacquisto_prezzominimo`

Il secondo elemento non deve essere necessariamente un EAN di 13 cifre: può
essere uno SKU fornitore o qualsiasi altro codice prodotto. Restano fissi
soltanto gli ultimi due valori numerici.

Esempi:

- `in_C01030002_199_273` → costo di acquisto `199,00 €`;
- `ceco_A01_EU01_110320_249_340` → costo di acquisto `249,00 €`;
- `Innpro_6974662350503_335.07_452.34` → costo di acquisto `335,07 €`.

## Recupero dai listini pubblicati

Quando uno SKU vecchio non contiene costo e prezzo minimo:

1. il programma identifica le viste e i listini realmente pubblicati
   dall’account Kaufland selezionato, comprese le pubblicazioni storiche;
2. dà priorità alla vista usata per pubblicare proprio quello SKU;
3. cerca il prodotto prima tramite EAN;
4. se l’EAN non produce una corrispondenza, cerca tramite SKU originale o
   codice prodotto;
5. usa il costo specifico del Paese quando il listino lo prevede.

La tabella indica `Listino pubblicato`, il nome di fornitore/listino/vista e il
tipo di corrispondenza utilizzato.

Se non esiste una fonte verificabile, la riga mostra esattamente:

`Costo non calcolabile`

Non vengono inventati costi e gli ordini non calcolabili sono esclusi dai
totali di costo e guadagno.

## Verifica

Compilazione completata e 168 test automatici superati.
