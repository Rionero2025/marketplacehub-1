# Marketplace Hub v271 — Packlink auto-riparante e compatibile con servizi CSV precedenti

## Correzione del blocco Packlink

Risolto il caso in cui la pagina Packlink aggiornata veniva caricata insieme a una copia precedente di `services/packlink_csv.py` e mostrava:

`Funzioni mancanti: choose_best_packlink_service`

La funzione introdotta nella v270 serve soltanto a scegliere la tariffa positiva più economica. Il generatore CSV Packlink già presente dalla v253 è compatibile con il tracciato ufficiale usato dalla generazione automatica.

## Nuovo comportamento v271

- la pagina continua a tentare l'auto-riparazione da `_release_payload`;
- se il file servizio rimasto sul PC è ancora v253/v269 e manca soltanto `choose_best_packlink_service`, Packlink **non viene più bloccato**;
- viene usato automaticamente un selettore tariffa compatibile incorporato nella pagina;
- il pulsante **Genera automaticamente migliore combinazione + CSV completo** continua a funzionare;
- il launcher continua comunque a riallineare il file servizio alla v271 al successivo avvio da `AVVIA_WINDOWS.bat`;
- restano invariati CSV ufficiale a 30 colonne, edit email/telefono, default Seller e generazione massiva.

## Compatibilità

Nessuna migrazione database e nessuna modifica ai dati esistenti.
