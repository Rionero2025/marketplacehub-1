# Marketplace Hub v249 — normalizzazione cataloghi ad alta velocità e marchio Innpro

## Obiettivo

La v249 preserva integralmente la pietra miliare v243 e tutte le funzioni Catalog Intelligence v244-v248. La release interviene sulla fase **Creazione Prodotti → Catalogo sorgente → Normalizza e memorizza i prodotti**, che con listini di migliaia di righe risultava lenta e non mostrava un avanzamento misurabile.

## Avanzamento visibile

Durante la normalizzazione la pagina mostra in tempo reale:

- percentuale complessiva;
- fase in corso;
- prodotti letti sul totale;
- prodotti normalizzati;
- prodotti memorizzati;
- prodotti elaborati al secondo;
- tempo trascorso;
- tempo residuo stimato.

Il semplice spinner senza conteggio non viene più utilizzato per questa operazione.

## Prestazioni

Prima della v249 il salvataggio apriva numerose connessioni e transazioni per prodotto, valore ed evidenza. Su cataloghi completi questo poteva produrre decine di migliaia di operazioni separate.

La v249 usa invece:

- un piano colonne compilato una sola volta;
- iterazione veloce del DataFrame;
- una sola transazione per l'intero catalogo;
- upsert dei prodotti a batch;
- `executemany` per provenienza e valori canonici;
- batch limitati per contenere la memoria;
- riutilizzo dei record il cui hash non è cambiato.

Il test prestazionale automatico impedisce il ritorno al vecchio salvataggio riga-per-riga. Nei benchmark di costruzione il nuovo percorso supera ampiamente il miglioramento richiesto di dieci volte rispetto al percorso legacy dominato dalle transazioni individuali.

## Cache persistente della normalizzazione

Uno snapshot già completato con lo stesso motore viene riutilizzato immediatamente. La cache è accettata solo quando:

- lo stato è `COMPLETED`;
- la versione del motore coincide;
- il numero dei prodotti coincide;
- ogni prodotto possiede valori persistiti.

Un'esecuzione interrotta o appartenente a una versione precedente viene ricostruita automaticamente. La checkbox **Rigenera anche se questa stessa vista è già stata normalizzata** consente comunque di forzare una nuova elaborazione.

## Marchio Innpro dal campo `producer`

I listini Innpro espongono spesso il marchio commerciale nel campo `producer`. Il normalizzatore v249 mappa quindi:

```text
producer del listino
→ brand del prodotto canonico
→ colonna Marca
→ brand/manufacturer del feed marketplace
```

Sono riconosciuti anche `producer_name` e `producent`.

La priorità resta corretta:

1. un campo `brand`/`marca` realmente valorizzato;
2. in sua assenza, `producer`;
3. gli altri alias produttore già supportati.

Una colonna `brand` presente ma vuota non blocca il fallback a `producer`. La provenienza memorizza il campo sorgente originale, per esempio:

```text
Campo canonico: brand
Campo sorgente: producer
Valore sorgente: Habotest
```

## Compatibilità con snapshot precedenti

Il motore di normalizzazione è versionato come `249`. Uno snapshot elaborato dalle versioni precedenti viene quindi rigenerato una volta, così i marchi mancanti vengono recuperati dal campo `producer`. Dopo la ricostruzione, le aperture successive riutilizzano la memoria persistente.

## Protezione della release

Il gate di coerenza rifiuta il pacchetto se manca anche uno solo dei seguenti elementi:

- alias `producer` nel mapping del brand;
- prova di precedenza del brand esplicito;
- avanzamento percentuale e conteggi UI;
- salvataggio batch in una transazione;
- cache di normalizzazione verificata;
- test regressione v249;
- copia auto-riparante allineata.

## Dati e funzioni preservati

Restano inclusi Seller, account, fornitori, listini, tassonomie cached-first, categorie Kaufland ufficiali, feed prodotto, pubblicazione controllata, Packlink, Buy Box, cancellazione, ordini, tracking, contabilità, storico, SQLite/PostgreSQL e avvio unico tramite `AVVIA_WINDOWS.bat`.

## Feed completo del fornitore nella scheda prodotto

La v249 non si limita più ai campi minimi EAN/SKU/prezzo. Il prodotto canonico conserva anche:

- marchio dal campo `producer` quando `brand`/`marca` sono vuoti;
- descrizione lunga e breve;
- tutti gli URL delle immagini, senza fermarsi alla prima immagine;
- documenti, manuali e allegati;
- URL della scheda prodotto;
- parametri tecnici annidati;
- l'intero record originale sotto `source_attributes`.

Kaufland e Worten/Mirakl ricevono titolo, descrizione, marchio e tutte le immagini nei rispettivi formati. Documenti e URL scheda vengono mappati soltanto quando la tassonomia ufficiale prevede un attributo compatibile, evitando campi inventati o non ammessi.

Nella griglia dello snapshot sono visibili anche **Marca**, **Descrizione**, numero di **URL immagini** e numero di **Documenti**, così il Seller può verificare immediatamente che il contenuto del listino sia stato realmente letto.

## Risultati di verifica finali

- suite completa: **578 test superati + 6 subtest**;
- test mirati v249/full feed: **18 superati**;
- benchmark 7.056 righe: circa **4,10 s / 1.720 prodotti al secondo**;
- riapertura dello stesso snapshot tramite cache: circa **0,15 s**.
