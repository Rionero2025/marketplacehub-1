@echo off
setlocal
cd /d "%~dp0"
python tools\verify_release_consistency.py
if errorlevel 1 (
  echo.
  echo ERRORE: release NON distribuibile. Correggere i problemi prima di creare marketplace_hub.zip.
  exit /b 1
)
echo.
echo Coerenza release verificata: OK.
exit /b 0
