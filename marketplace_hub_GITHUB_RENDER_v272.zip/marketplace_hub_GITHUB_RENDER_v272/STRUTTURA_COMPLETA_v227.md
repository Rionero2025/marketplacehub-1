# Marketplace Hub v227 — struttura completa

Pacchetto autonomo completo Windows.

- Pagine Streamlit Python: **23**
- Servizi Python: **44**
- File test: **64**
- Strumenti: **5**

## Correzione v227
La rigenerazione massiva considera la tariffa storica ripristinata come tariffa valida. Gli ordini con tariffa precedente compatibile non vengono più inviati al motore di quotazione Packlink. Il ricalcolo massivo riguarda esclusivamente gli ordini senza tariffa valida.

## Aggiornamento installazione esistente
Usare `AGGIORNA_INSTALLAZIONE_ESISTENTE_v227_WINDOWS.bat`. Database, cartella `data`, `.streamlit/secrets.toml` e `.venv` vengono preservati.
