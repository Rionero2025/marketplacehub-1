# Aggiornamento v127 — scelta esplicita per ordini Cecotec già elaborati

Nella pagina **Creazione Ordini Cecotec**, quando la selezione contiene righe già presenti nello storico, l'avviso propone due caselle alternative:

- **Seleziona solo le offerte che non sono state ancora elaborate**: esclude dal nuovo file tutte le righe già esportate.
- **Ignora l’avviso e genera tutte le offerte selezionate**: include anche le righe già elaborate.

Le due caselle sono mutuamente esclusive. Il pulsante di generazione resta disattivato finché non viene scelta una modalità. Se tutte le righe selezionate sono già state elaborate e viene scelta la prima opzione, il programma segnala che non ci sono nuove righe da generare.
