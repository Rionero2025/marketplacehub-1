# Marketplace Hub v178

## Correzione Tracciabilità ordini dopo invio API

Risolto il `NameError: editor_version_key is not defined` che poteva comparire dopo
l'invio di uno o più tracking al marketplace.

Dopo un invio riuscito o dopo il riconoscimento di ordini già spediti, la pagina:

- rimuove dalla selezione gli ordini completati;
- incrementa la revisione corretta della griglia di Tracciabilità;
- ricrea AgGrid senza conservare checkbox ormai completati;
- continua a mostrare l'esito dell'invio e gli eventuali errori sulle righe restanti;
- non interrompe più il flusso prima del riepilogo finale.
