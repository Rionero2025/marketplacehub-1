# Aggiornamento v197 — refresh automatico IP AB Online

## Problema corretto

Quando l'indirizzo IP pubblico del PC cambiava, l'integrazione AB Online poteva
continuare a mostrare o riutilizzare lo stato IP della sessione precedente.
L'errore 59 del Gateway restava quindi poco chiaro anche dopo l'autorizzazione
del nuovo IP nel pannello AB.

## Nuovo comportamento

- prima di ogni verifica, aggiornamento completo o aggiornamento rapido viene
  rilevato nuovamente l'IPv4 pubblico corrente;
- ogni richiesta AB Online usa un nuovo opener HTTP e una connessione con
  `Connection: close`, senza riutilizzare sessioni o proxy memorizzati;
- il collegamento diretto viene tentato per primo; il proxy di sistema resta
  soltanto come fallback di connettività;
- il programma confronta IP precedente e IP corrente;
- il nuovo IP e la data dell'ultima verifica vengono salvati nelle credenziali
  cifrate del listino;
- in caso di errore 59 viene effettuato automaticamente un secondo tentativo
  dopo il rinnovo della rete;
- se il Gateway continua a rifiutare l'accesso, viene mostrato l'IP da
  autorizzare;
- quando VPN o proxy espongono un IP diverso, vengono mostrati separatamente
  l'IP rilevato dal PC e quello visto da AB Online.

## Interfaccia

Il pulsante è ora denominato **Aggiorna IP e verifica AB Online**.
La pagina mostra l'ultimo IP rilevato e la data della verifica.

## Verifiche

- test parsing e importazione AB Online;
- rilevamento IP JSON e testo semplice;
- confronto IP precedente/corrente;
- retry automatico dell'errore 59;
- compilazione di tutti i moduli;
- suite completa: 370 test superati e 6 subtest superati.
