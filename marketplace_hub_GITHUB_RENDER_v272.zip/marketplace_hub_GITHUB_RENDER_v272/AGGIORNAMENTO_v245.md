# Marketplace Hub v245 — categoria automatica e feed prodotto completo

## Obiettivo
La v245 sviluppa la fase successiva di **Creazione Prodotti / Catalog Intelligence** partendo dalla v244 e preservando integralmente la pietra miliare v243.

Il caso operativo principale è adesso il prodotto che non esiste ancora su Kaufland o Worten. Marketplace Hub determina una categoria pertinente utilizzando esclusivamente la tassonomia ufficiale già memorizzata nel database e prepara una scheda prodotto completa prima di qualunque futura pubblicazione.

La scrittura remota resta intenzionalmente disabilitata in questa release. La v245 classifica, prepara, valida, conserva e rende ispezionabili i payload, ma non crea ancora prodotti o offerte reali.

## Tassonomia persistente: nessun download ripetuto
Il nuovo punto di accesso `ensure_account_taxonomy()` controlla prima il database.

Flusso normale:

1. prima configurazione dell'account/storefront: download via API e snapshot nel database;
2. aperture e lavorazioni successive: lettura immediata dello snapshot locale;
3. nuovo download soltanto quando il Seller preme **Aggiorna tassonomia via API**, quando lo snapshot manca o quando una futura gestione errori ne richiederà l'aggiornamento.

Una tassonomia già memorizzata rimane consultabile anche prima della decifratura delle credenziali: le credenziali vengono caricate soltanto quando serve una reale chiamata remota.

Ogni snapshot conserva marketplace, account, ambiente, storefront/canale, locale, scope, hash, categorie, attributi e valori ammessi. Le versioni precedenti non vengono cancellate.

## Determinazione della categoria per singolo prodotto
La v245 non applica più una categoria manuale unica all'intero listino.

Per ciascun prodotto utilizza:

- categoria/famiglia originale del fornitore;
- titolo;
- descrizione completa e breve;
- marca e modello;
- caratteristiche tecniche normalizzate;
- campi grezzi del listino;
- nomi dei file immagine e URL;
- mapping categoria già approvati;
- opzionalmente, per Kaufland, i suggerimenti ufficiali dell'endpoint `/categories/decide/`.

Il classificatore può restituire soltanto categorie foglia presenti nello snapshot ufficiale attivo. Salva fino a cinque candidate, punteggio, segnali utilizzati, fonte e margine tra la prima e la seconda scelta.

Gli stati sono:

- `AUTO_APPROVED`: mapping già approvato o accordo forte tra segnali;
- `REVIEW`: categoria plausibile da confermare;
- `BLOCKED`: nessuna categoria sufficientemente supportata.

## Knowledge Base categorie
Quando il Seller approva una categoria può salvare una regola riutilizzabile:

`Seller + fornitore + famiglia/categoria sorgente + marketplace + storefront → categoria ufficiale`

Le lavorazioni successive utilizzano prima la regola approvata e non richiedono una nuova classificazione completa per la stessa famiglia sorgente.

## Attributi di categoria memorizzati
Per Mirakl/Worten gli attributi di categoria già ottenuti tramite PM11 vengono letti dallo snapshot locale.

Per Kaufland gli attributi specifici della categoria vengono scaricati soltanto quando quella categoria viene utilizzata per la prima volta. Il dettaglio viene salvato in `taxonomy_category_enrichments`; i prodotti successivi leggono la copia locale senza una nuova richiesta API.

Sono preservati:

- obbligatorietà;
- attributi condizionali;
- tipo dati;
- molteplicità;
- unità;
- vincoli e regex;
- valori ammessi;
- dati grezzi restituiti dal marketplace.

## Feed prodotto completo
Dopo l'approvazione della categoria, Marketplace Hub prepara un feed distinto per marketplace.

### Kaufland
Il payload contiene:

- EAN;
- titolo;
- descrizione;
- descrizione breve;
- produttore/marca;
- MPN/modello;
- categoria;
- tutti gli URL immagini disponibili;
- caratteristiche tecniche mappate e formattate secondo il tipo ufficiale;
- unità normalizzate;
- anteprima separata dell'offerta futura.

### Worten/Mirakl
Il record dinamico contiene:

- SKU prodotto;
- EAN e tipo identificatore;
- codice categoria;
- titolo e descrizione;
- marca;
- MPN;
- immagini numerate;
- attributi della gerarchia;
- locale;
- riga piatta pronta per essere trasferita nel template reale del tenant nella fase di pubblicazione.

## Validazione deterministica
La v245 blocca la scheda quando mancano dati realmente necessari e non inventa valori.

Controlli inclusi:

- EAN/GTIN;
- titolo, marca, descrizione e immagini;
- categoria esistente e foglia;
- attributi obbligatori;
- valore singolo/multiplo;
- numero intero, decimale, booleano, data, EAN e URL;
- lunghezza minima/massima;
- regex;
- valori numerici min/max;
- allowed values;
- validità degli URL immagine;
- readiness score.

Se un attributo tecnico obbligatorio non è presente nei dati del fornitore, lo stato è `BLOCKED`; l'attributo non viene generato artificialmente.

## Nuove strutture database
Sono state aggiunte in modo idempotente:

- `taxonomy_category_enrichments`;
- `category_classification_runs`;
- `product_category_candidates`;
- `product_category_assignments`;
- `category_mapping_rules`;
- `product_feed_preparations`.

Nessuna tabella o riga preesistente viene eliminata.

## Interfaccia
La pagina **Creazione Prodotti** ora contiene:

1. Account e tassonomia;
2. Catalogo sorgente;
3. Determina categorie;
4. Prepara feed;
5. Storico.

Mostra tassonomia attiva, data/hash, categorie candidate, confidence, fonte, approvazioni, stato della validazione, campi mancanti, payload tecnico e job persistenti.

## Limite intenzionale della v245
`remote_write_enabled` resta `False`.

La ricerca EAN, la creazione reale dei product data, il polling, i report errori e la creazione dell'offerta verranno collegati nella fase successiva. La ricerca EAN sarà un controllo anti-duplicato e non la fonte necessaria per determinare la categoria.
