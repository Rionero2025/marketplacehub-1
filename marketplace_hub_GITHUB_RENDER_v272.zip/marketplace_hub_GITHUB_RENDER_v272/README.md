# Marketplace Hub v272 — Cloud-ready

Marketplace Hub v272 parte dalla release v271 e aggiunge la base per esecuzione online con **GitHub + Render + PostgreSQL**.

## Avvio cloud

La guida completa è in [`ONLINE_DEPLOY.md`](ONLINE_DEPLOY.md).

Componenti principali:

- Streamlit/Python;
- PostgreSQL tramite `DATABASE_URL`;
- Docker;
- Render Blueprint (`render.yaml`);
- persistent disk per gli artefatti locali ancora usati dall'app;
- login amministratore obbligatorio nel deploy online;
- CI GitHub Actions.

## Avvio locale Docker

```bash
docker compose up --build
```

Poi apri `http://localhost:8501`.

## Avvio Windows storico

I file Windows della v271 sono stati mantenuti per compatibilità. Il repository GitHub/Render, però, deve essere avviato con Docker/Render e non tramite il launcher Windows.

## Sicurezza repository

Il `.gitignore` esclude segreti, database locali, file `data/`, log ed esportazioni operative. Non inserire API key o password nei sorgenti.
