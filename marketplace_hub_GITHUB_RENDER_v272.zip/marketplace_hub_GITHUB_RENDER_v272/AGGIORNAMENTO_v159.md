# Marketplace Hub v159

## Ticket e messaggi marketplace con IA controllata

La precedente pagina Assistenza Kaufland è stata sostituita nella navigazione da una console unificata **Ticket e messaggi**, compatibile con gli account Kaufland e Worten del Seller selezionato.

### API utilizzate

- Kaufland: elenco ticket e messaggi, risposta con `interim_notice`, allegati e chiusura tramite API Seller v2 già presenti nel progetto.
- Worten/Mirakl: M11 per la sincronizzazione incrementale dei thread, M10 per la conversazione completa, M12 per rispondere in `multipart/form-data` e M13 per scaricare gli allegati.
- Gli endpoint Mirakl deprecati `/api/messages` e `/api/orders/{order_id}/messages` non vengono utilizzati.

### Console grafica

I ticket sono divisi in:

- Da rispondere;
- Prioritari con meno di 24 ore;
- In attesa del cliente;
- Informativi;
- Chiusi;
- Da leggere.

Sono disponibili ricerca, filtri per stato, priorità, lettura e data, selezione multipla e apertura del singolo ticket con la conversazione completa.

### SLA

La scadenza è chiaramente calcolata sullo SLA configurato, predefinito a 24 ore:

- Worten: da `shop_reply_needed_since`;
- Kaufland: dall’ultimo messaggio ricevuto o aggiornamento del ticket quando `is_seller_responsible=true`.

### Risposte

La risposta viene inviata via API dalla stessa pagina. Il testo è completamente modificabile in un editor visuale, con fallback a editor testuale. Sono supportati allegati e, per Kaufland, l’avviso provvisorio `interim_notice`.

### IA

La pagina consente di:

- salvare una OpenAI API Key cifrata per account;
- generare una bozza IA senza inviarla;
- modificare liberamente la bozza;
- attivare l’automazione soltanto sui ticket selezionati;
- scegliere categorie autorizzate, modello, confidenza minima e istruzioni del Seller;
- eseguire le risposte automatiche dopo la sincronizzazione o manualmente.

Prima di ogni invio automatico il programma rilegge il ticket dall’API e verifica che sia ancora richiesta una risposta, che il thread non sia cambiato e che la stessa risposta non sia già stata inviata. Rimborsi, risarcimenti, annullamenti, frodi, controversie legali, garanzie controverse e casi incerti richiedono sempre controllo umano.

### Persistenza

Thread, messaggi, impostazioni IA, bozze, classificazioni e azioni API vengono memorizzati nel database per Seller, account, marketplace e ambiente.
