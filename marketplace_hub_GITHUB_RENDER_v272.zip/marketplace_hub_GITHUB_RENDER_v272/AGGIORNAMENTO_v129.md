# Aggiornamento v129 — Dashboard generale Seller

- La Dashboard iniziale mostra automaticamente tutti i Seller attivi in una griglia a due colonne.
- Non è presente alcun radio button o selettore Seller nella Dashboard.
- Ogni riquadro mostra, affiancati, vendite e guadagno per:
  - oggi;
  - settimana corrente da lunedì;
  - mese corrente;
  - periodo complessivo.
- Il guadagno usa le stesse regole della Contabilità: accredito marketplace meno costo di acquisto e costi extra.
- Annullati, cancellati, no stock e rimborsati valgono zero.
- Le righe con dati insufficienti non generano un guadagno artificiale e vengono segnalate nel riquadro.
- I periodi sono calcolati nel fuso orario Europe/Rome.
