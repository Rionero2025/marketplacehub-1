@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - Riparazione installazione
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA_MARKETPLACE_HUB.ps1" -Repair -NoLaunch
if errorlevel 1 (
  echo.
  echo RIPARAZIONE NON COMPLETATA. Consulta la cartella logs.
  pause
  exit /b 1
)
echo.
echo Riparazione completata. Premi un tasto per avviare Marketplace Hub.
pause
call "%~dp0AVVIA_WINDOWS.bat"
