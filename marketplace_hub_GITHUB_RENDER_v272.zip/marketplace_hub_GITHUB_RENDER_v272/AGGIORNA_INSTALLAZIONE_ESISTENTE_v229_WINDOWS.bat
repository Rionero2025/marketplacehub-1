@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub v229 - Aggiornamento installazione esistente
color 0B
cls
echo ============================================================================
echo       MARKETPLACE HUB v229 - AGGIORNA INSTALLAZIONE ESISTENTE
echo ============================================================================
echo.
echo Questo aggiornamento sincronizza TUTTO il codice del pacchetto v229 in:
echo   %USERPROFILE%\Documents\marketplace_hub
echo.
echo VENGONO PRESERVATI:
echo   - cartella data e database
echo   - Seller, ordini, storico e configurazioni salvate
echo   - .streamlit\secrets.toml e credenziali cifrate
echo   - ambiente .venv gia' installato
echo.
echo Marketplace Hub verra' chiuso se risulta in esecuzione nella cartella target.
echo.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AGGIORNA_INSTALLAZIONE_ESISTENTE_v229.ps1"
if errorlevel 1 (
  echo.
  echo AGGIORNAMENTO NON COMPLETATO.
  pause
  exit /b 1
)
exit /b 0
