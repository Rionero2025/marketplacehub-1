# Aggiornamento v125 — azzeramento economico per stati non contabilizzabili

La pagina **Contabilità** forza automaticamente a `0` tutti i valori economici quando lo stato, le note contabili o il numero ordine fornitore contengono uno dei seguenti avvisi:

- `no stock` / `out of stock`;
- `annullare`;
- `cancellato` / `annullato` e corrispondenti stati API;
- `rimborsato`, incluso `Rimborsato parzialmente` e gli stati API `REFUNDED`, `FULLY_REFUNDED`, `PARTIALLY_REFUNDED`.

Vengono azzerati:

- vendita originale e vendita netta;
- rimborso;
- costo di acquisto;
- commissione marketplace;
- costo extra;
- importo da pagare;
- margine lordo;
- ricavo netto;
- percentuale di ricavo.

La data di pagamento stimata viene svuotata. La regola prevale sui valori provenienti dalle API, dai listini, dalle modifiche manuali e dai file Excel di confronto. Si applica anche agli ordini già memorizzati, senza obbligare a riscaricarli.

Verifica: **205 test automatici e 6 subtest superati**.
