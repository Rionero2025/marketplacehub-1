# Aggiornamento v109 — regole complete di accredito Kaufland

## Calcolo della data

- **Con numero di tracking:** pagamento previsto 14 giorni dopo la consegna al
  cliente rilevata da Kaufland.
- **Senza numero di tracking:** pagamento previsto 21 giorni dopo che l’unità
  è stata contrassegnata come spedita.
- **Pagamento già rilasciato:** la data effettiva comunicata da Kaufland ha
  sempre priorità sulle stime.

## Ticket

- I ticket vengono collegati tramite ID unità ordine.
- Per ogni ticket chiuso viene aggiunta la durata intercorsa fra apertura e
  completa risoluzione.
- Gli intervalli sovrapposti non vengono contati due volte.
- Se almeno un ticket è ancora aperto, la data visualizzata è provvisoria e il
  riepilogo non dichiara ancora una data definitiva per l’intero blocco.
- La tabella mostra giorni di ritardo, numero di ticket aperti e relativi ID.

## Interfaccia

- La tabella mostra la regola applicata a ogni ordine.
- Per le spedizioni con tracking non ancora consegnate compare:
  **Tracking presente · consegna non ancora rilevata**.
- Per le spedizioni senza tracking viene mostrata subito la data
  **spedizione + 21 giorni**, quando la data di spedizione è disponibile.
- I totali distinguono **Netto disponibile** e **Netto in attesa** per tutti
  gli ordini spediti, non soltanto per quelli nello stato Ricevuto.
- Nuovi filtri: disponibile, in attesa di accredito, data non determinabile e
  ticket aperto.

## Aggiornamento

1. Chiudere il programma.
2. Conservare la cartella `data`.
3. Sostituire i file del programma con quelli della v109.
4. Riavviare e sincronizzare ordini e ticket Kaufland.

## Verifica

Compilazione completata e 143 test automatici superati.
