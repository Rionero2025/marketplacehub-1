# Marketplace Hub v263 — Storico persistente Ordini INNPRO

## Riconoscimento ordini già generati
La sezione **Creazione Ordini INNPRO** registra ora ogni export tramite il numero ordine originale del marketplace.

Quando viene selezionato un ordine già presente nello storico, Marketplace Hub mostra:
- numero ordine marketplace;
- data e ora della precedente generazione;
- nome esatto del file INNPRO nel quale l'ordine era stato inserito;
- pulsante per riscaricare direttamente il file archiviato.

Il controllo è effettuato a livello di ordine: se un ordine contiene più righe, il suo numero viene considerato già generato quando almeno una riga INNPRO valida è stata realmente inserita in un file archiviato.

## Protezione duplicati
In presenza di ordini già generati, la scelta predefinita è **Genera solo gli ordini non ancora generati**. Rimane disponibile l'opzione esplicita **Genera comunque tutti gli ordini selezionati** per le rigenerazioni volontarie.

## Archivio file INNPRO
Il precedente download diretto è stato trasformato nel flusso **Genera, memorizza e prepara il download**. Il nome del file viene fissato una sola volta al momento della generazione e il CSV viene salvato nell'archivio persistente `data/innpro_orders`.

La pagina contiene anche **Archivio file INNPRO**, con gli ultimi file generati, data, numero di ordini, righe esportate, EAN unici, quantità totale e possibilità di nuovo download.

## Backup e portabilità
I file INNPRO archiviati sono ora inclusi dal backup compatto solo quando risultano referenziati dal database. In questo modo lo storico resta trasferibile senza reintrodurre il problema dei backup gonfiati da file orfani.

## Compatibilità preservata
Restano invariati formato INNPRO `EAN;quantità`, validazione EAN-13, aggregazione quantità, ordini Kaufland/Worten, Contabilità v259, Packlink v255, Catalog Intelligence, Seller, credenziali e avvio `estrai → AVVIA_WINDOWS.bat`.
