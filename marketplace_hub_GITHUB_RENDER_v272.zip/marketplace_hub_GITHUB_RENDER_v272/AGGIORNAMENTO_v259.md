# Marketplace Hub v259 — Contabilità: ricalcolo immediato dopo valori manuali

## Obiettivo
Quando in **Contabilità** viene inserito o modificato manualmente un valore economico, il programma deve ricalcolare subito il **Margine utile** e la ripartizione tra **BEBOL** e **Seller** usando le percentuali già configurate nell'anagrafica Seller.

## Correzioni v259

### 1. Margine immediato nella stessa riga
Le celle economiche modificabili della tabella principale (`Vendita`, `Acquisto`, `Commissione`, `Rimborso`, `Da ricevere`, `Costo Extra`) alimentano ora in tempo reale le colonne protette:
- **Margine utile**;
- **Nostra quota / BEBOL**;
- **Quota Seller**.

Il calcolo rimane quello contabile già stabilito:
- `Margine lordo = Da ricevere - Acquisto`;
- `Margine utile = Margine lordo - Costo Extra`;
- successivamente il margine utile viene diviso secondo le percentuali configurate per il Seller.

### 2. Totali superiori aggiornati senza una seconda modifica
Dopo il salvataggio automatico di una cella, la pagina rilegge soltanto la cache contabile locale, senza riscaricare gli ordini dai marketplace. Nella stessa esecuzione vengono quindi aggiornati:
- Margine utile totale;
- totale acquisti/commissioni/da ricevere;
- quota BEBOL;
- quota Seller;
- valori usati dalle successive esportazioni Excel/PDF.

### 3. Coerenza Vendita / Commissione / Da ricevere
Quando si modifica manualmente `Vendita` o `Commissione`, la griglia mantiene in tempo reale anche `Da ricevere = Vendita - Commissione`, salvo un valore `Da ricevere` inserito esplicitamente dall'utente. Il backend continua a usare la stessa regola persistente.

### 4. Persistenza
I valori manuali continuano a essere autorevoli e persistenti nel database e non vengono cancellati da successive sincronizzazioni API o ricalcoli dei listini.

### 5. Stati annullati/rimborsati
Le protezioni esistenti restano prioritarie: righe cancellate, annullate, rimborsate o rese non possono essere riportate artificialmente a valori economici positivi tramite modifica manuale.

## Compatibilità preservata
Restano invariati:
- selezione listini Contabilità v257 e protezione Innpro LIGHT v256;
- Catalog Intelligence AI v258;
- Packlink v255;
- database, `data`, Seller, ordini, storico, configurazioni e credenziali;
- auto-riparazione `_release_payload` e protezione anti-downgrade;
- avvio `estrai → AVVIA_WINDOWS.bat`.
