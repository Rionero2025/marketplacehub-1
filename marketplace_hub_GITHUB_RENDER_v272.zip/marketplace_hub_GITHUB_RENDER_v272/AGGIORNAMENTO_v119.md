# Aggiornamento v119 — Correzione visualizzazione ordini Cecotec

- Corretto il filtro della pagina **Creazione Ordini Cecotec**: un multiselect vuoto ora significa **tutti i valori**, non più nessun risultato.
- Cecotec resta preselezionato come fornitore.
- Stato ordine e Nazione possono restare vuoti per mostrare tutti gli stati e tutte le nazioni.
- Aggiunti contatori: righe nel periodo, righe Cecotec e righe visibili.
- Migliorati i messaggi diagnostici quando il periodo o i filtri non restituiscono ordini.
