# Marketplace Hub v169

## Correzione parametri OpenAI

- I profili OpenAI nativi utilizzano ora la Responses API (`/v1/responses`).
- Il limite di output viene inviato come `max_output_tokens`, compatibile con i modelli OpenAI recenti.
- Il parametro legacy `max_tokens` non viene più inviato ai modelli OpenAI.
- Gli endpoint compatibili OpenAI che rifiutano `max_tokens` vengono ritentati automaticamente con `max_completion_tokens`.
- Le risposte IA continuano a essere richieste con `store=false`.
