# Marketplace Hub v158

## Dashboard con periodo selezionabile e riepilogo BEBOL

La Dashboard consente ora di scegliere il periodo economico da visualizzare:

- Giorno, con scelta libera della data;
- Settimana corrente, dal lunedì alla data odierna;
- Mese corrente, dal primo giorno del mese alla data odierna;
- Intervallo personalizzato, con data iniziale e finale inclusive.

Tutti i riepiloghi economici vengono ricalcolati usando lo stesso intervallo:

- numero ordini;
- vendite;
- margine utile;
- righe con guadagno da verificare;
- quota complessiva dei Seller;
- quota complessiva BEBOL.

È stato aggiunto un riquadro principale **Guadagno complessivo BEBOL
nell'intervallo**, ottenuto sommando la quota BEBOL calcolata separatamente per
ogni Seller secondo la percentuale configurata nella relativa anagrafica.

Ogni scheda Seller mostra inoltre un nuovo riquadro a larghezza completa con i
risultati del periodo selezionato, mantenendo anche i riepiloghi di oggi,
settimana, mese e complessivo già presenti.
