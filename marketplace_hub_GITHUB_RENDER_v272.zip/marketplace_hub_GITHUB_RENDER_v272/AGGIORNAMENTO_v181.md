# Marketplace Hub v181

## Cancellazione catalogo per ambito

La sezione **Cancellazione dai Marketplace** permette ora di scegliere l'ambito prima di selezionare le offerte:

1. **Cancella tutto il catalogo**;
2. **Cancella uno o più fornitori**;
3. selezione di uno o più listini pubblicati su Kaufland oppure selezione manuale su Worten.

La scelta dei fornitori e dei listini avviene dentro un form con checkbox: i singoli click non provocano il rerun di Streamlit. La selezione viene applicata soltanto premendo il pulsante dedicato.

Per Kaufland la cronologia viene letta a livello di intero account, così le cancellazioni globali rimangono riconosciute anche quando successivamente si filtra un solo listino. Ogni offerta mostra fornitore e listino di origine.

Per Worten il fornitore viene ricostruito dal prefisso dello SKU composito senza effettuare associazioni arbitrarie. Gli SKU non riconoscibili restano nel gruppo **Sconosciuto**.

La modalità di cancellazione, i fornitori, i listini e gli SKU coinvolti vengono conservati nello storico delle operazioni.
