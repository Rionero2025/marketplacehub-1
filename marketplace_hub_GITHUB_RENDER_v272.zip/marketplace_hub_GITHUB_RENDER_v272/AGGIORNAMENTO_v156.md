# Marketplace Hub v156

## Archivio permanente dei file spedizioni e caricamento tramite URL

La pagina **Tracciabilità ordini** conserva ora i documenti di spedizione nel
database dell'account selezionato. I file rimangono disponibili dopo i rerun di
Streamlit, la chiusura del browser e il riavvio del programma.

### Origini supportate

- caricamento dal computer;
- riutilizzo dei file già presenti nell'archivio;
- download da uno o più URL pubblici, uno per riga.

Sono accettati XLSX, XLS, CSV, TSV, TXT e PDF, fino a 25 MB per file.

### Archivio file spedizioni

Per ogni file vengono memorizzati:

- Seller, marketplace e account;
- nome e contenuto originale;
- SHA-256 per evitare duplicati;
- origine Upload oppure URL;
- URL sorgente, quando presente;
- formato MIME e dimensione;
- fornitore rilevato o selezionato;
- data di salvataggio;
- ultimo utilizzo e numero di utilizzi.

Dall'archivio è possibile selezionare più file da riutilizzare, scaricare una
copia del documento originale oppure eliminarlo con conferma.

Se lo stesso URL restituisce un contenuto aggiornato, viene salvata una nuova
versione perché il suo SHA-256 è differente. Se il contenuto è identico, il file
non viene duplicato.

### Sicurezza URL

Il downloader accetta soltanto HTTP e HTTPS, limita i reindirizzamenti, blocca
host locali, reti private e indirizzi riservati, applica un limite di 25 MB e
verifica che il formato sia tra quelli supportati.
