# Marketplace Hub v226 — struttura completa del pacchetto

Pacchetto autonomo Windows con aggiornamento dell'installazione esistente e nuova installazione.

## Conteggi
- Pagine Streamlit Python: **23**
- Servizi Python: **44**
- Test Python: **63**
- Tool Python: **5**
- File presenti prima del manifesto finale: **295**

## Correzione Packlink v226
- recupero destinatario da tutte le righe ordine;
- fallback sui dati grezzi già memorizzati da Kaufland/Worten;
- trasferimento completo di CAP/città/Paese nel blocco `to`;
- trasferimento completo del mittente registrato nel blocco `from`;
- nessun `selectedWarehouseId` automatico per i mittenti locali;
- memoria tariffa/pacco/valore dichiarato mantenuta;
- conferma ridondante v225 ancora rimossa.

## Script Windows principali
- `INSTALLA_TUTTO_WINDOWS.bat` — installazione completa v226;
- `AGGIORNA_INSTALLAZIONE_ESISTENTE_v226_WINDOWS.bat` — aggiorna il codice preservando i dati utente;
- `AVVIA_WINDOWS.bat` — avvio normale;
- `VERIFICA_PACCHETTO_v226_WINDOWS.bat` — verifica struttura e allineamento Packlink.
