# Marketplace Hub v204 - Documenti contabili in PDF

## Nuova sezione nella Contabilità

In fondo alla pagina **Contabilità** è disponibile la sezione **Generazione Documenti in PDF**.

## Selezione marketplace

- Se il Seller ha un solo marketplace attivo, viene selezionato automaticamente.
- Se sono disponibili due o più marketplace, possono essere inclusi o esclusi tramite flag.
- Il documento utilizza tutti gli account attivi del Seller appartenenti ai marketplace scelti.

## Periodi disponibili

- Giorno, con scelta della data.
- Settimana corrente, da lunedì a domenica.
- Mese corrente.
- Seleziona mese, con scelta di uno, più mesi oppure tutti i mesi disponibili.
- Anno corrente.
- Seleziona anno, predisposto per uno, più anni oppure tutti gli anni disponibili.
- Intervallo personalizzato Dal/Al.

## Contenuto del PDF

- Seller, marketplace inclusi, periodo e data di generazione.
- Riepilogo complessivo di righe, ordini, quantità, vendite, acquisti, commissioni, rimborsi, importi da ricevere, margine lordo e margine utile.
- Ripartizione del margine tra nostra quota e quota Partner secondo le percentuali configurate nel Seller.
- Riepilogo separato per ogni marketplace.
- Dettaglio completo delle righe contabili, attivabile o disattivabile.
- Evidenza delle righe con costo mancante, in perdita o annullate/cancellate.
- Intestazioni ripetute, numerazione pagine e impaginazione orizzontale A4.

Il PDF è un documento gestionale interno e non sostituisce fatture, estratti conto o documenti fiscali.
