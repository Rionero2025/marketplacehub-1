# Marketplace Hub v224 — sincronizzazione reale installazione + guardia Packlink

## Correzione dell'errore mostrato a video
La pagina Packlink v223 richiedeva in realtà `services/packlink.py >= 223`, ma il testo dell'errore indicava erroneamente `v221`. Se la vecchia installazione in `C:\Users\...\Documents\marketplace_hub` continuava a contenere il servizio v221, la pagina nuova veniva correttamente bloccata ma con un messaggio fuorviante.

La v224:
- usa `PACKLINK_REQUIRED_SERVICE_VERSION = 224` nella pagina;
- usa `PACKLINK_SERVICE_VERSION = 224` nel servizio;
- mostra sempre dinamicamente la versione realmente richiesta e quella caricata;
- mantiene `last_order_draft_configuration` e la memoria della tariffa scelta per ogni ordine;
- elimina le cache Python dopo l'aggiornamento.

## Nuovo aggiornamento dell'installazione esistente
`AGGIORNA_INSTALLAZIONE_ESISTENTE_v224_WINDOWS.bat` copia realmente tutto il codice del pacchetto nella cartella predefinita:

`%USERPROFILE%\Documents\marketplace_hub`

Preserva intenzionalmente:
- `data/` e database;
- `.streamlit/secrets.toml`;
- `.venv/`;
- runtime e log locali.

Prima della copia crea inoltre un backup dei file critici sotto `data/backups/pre_update_v224_*`.

## Avvio
`AVVIA_WINDOWS.bat` usa ora `.venv\Scripts\python.exe` quando l'ambiente virtuale è disponibile, evitando di avviare accidentalmente Marketplace Hub con un Python globale differente.
