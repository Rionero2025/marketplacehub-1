# Marketplace Hub v235 — Packlink: Paese + Città/codice postale completi

## Problema corretto
Le bozze create via API contenevano già nome, indirizzo, telefono ed email del destinatario, ma il portale Packlink PRO lasciava incompleti i due selettori **Paese** e **Città o codice postale**. Il solo invio di `to.country`, `to.zip_code` e `to.city` non garantiva che una bozza creata tramite API diretta avesse anche gli identificativi interni usati da quei selettori.

## Correzione v235
Prima di `POST /v1/shipments`, Marketplace Hub risolve il destinatario con gli endpoint location ufficiali Packlink:

- `GET /v1/locations/postalzones/destinations`
- `GET /v1/locations/postalcodes`

Il draft viene quindi completato con:

- `additional_data.postal_zone_id_to`
- `additional_data.zip_code_id_to`
- `additional_data.postal_zone_name_to`

I campi canonici dell'indirizzo restano comunque:

- `to.country` in ISO-2 (es. `SK`)
- `to.zip_code` (es. `04011`)
- `to.city` (es. `Kosice Lorincik`)

Il mittente non viene risolto nuovamente tramite le location API: continua a usare il vero `selectedWarehouseId` Packlink già associato.

## Protezione da bozze INCOMPLETE
Se Packlink non restituisce una zona/località coerente con Paese e codice postale del destinatario, **la bozza non viene creata**. Viene restituito l'errore sull'ordine interessato, evitando di generare altre spedizioni `INCOMPLETO` nel portale Packlink.

Per CZ/SK vengono provate sia la forma compatta sia quella visuale del CAP (`04011` / `040 11`), mantenendo il codice postale dell'ordine come riferimento vincolante.

## Flusso Packlink invariato
- API key Packlink PRO diretta.
- Nessun `POST /v1/integrations` obbligatorio.
- Tariffe precedenti, corriere, servizio, pacco, peso/dimensioni e valore dichiarato restano memorizzati per la rigenerazione.
- Mittente tramite warehouse Packlink reale.

## Avvio
Il file distribuito si chiama sempre `marketplace_hub.zip`.
Estrarre il pacchetto e usare soltanto `AVVIA_WINDOWS.bat`: l'allineamento del codice con l'installazione in `Documents\\marketplace_hub` è automatico e non richiede un installer/aggiornamento separato.
