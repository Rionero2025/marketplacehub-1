# Aggiornamento v118 — Creazione Ordini Cecotec

- Nuova pagina **Creazione Ordini Cecotec** nel menu principale.
- Scelta iniziale obbligatoria tra Kaufland e Worten e relativo account.
- Sincronizzazione ordini, cache persistente e filtri per fornitore, stato, nazione, periodo e ricerca.
- Selezione multipla con quadratini, intervalli, seleziona/deseleziona tutti i risultati filtrati e memoria della selezione.
- Estrazione del codice/EAN dallo SKU composto `fornitore_codice_costo_prezzominimo`.
- Match con la vista Cecotec salvata e recupero dello SKU Cecotec con un solo zero iniziale.
- Normalizzazione automatica dei telefoni nel formato internazionale `00...`, con lookup online e fallback locale.
- Generazione dei file Cecotec in `.xlsx` o `.xls`, mantenendo vuoti `order`, `nif` e `addressee_order_number`.
- Il file viene generato anche in presenza di righe non valide; tali righe vengono escluse e segnalate.
- Avviso obbligatorio prima della rigenerazione di righe già esportate.
- Archivio persistente dei file generati e possibilità di riscaricarli.
- Correzione endpoint ordini Worten per gli account configurati con URL terminante in `/api`.
- Supporto completo agli stati order-unit Kaufland già gestiti dalla v117.
