# Aggiornamento v128 — ordini Cecotec esportati anche senza EAN/SKU

- Le righe Cecotec senza EAN nello SKU composito vengono comunque esportate.
- Se l’EAN non è presente nel listino Cecotec, la colonna `article` resta vuota.
- Tutti gli altri dati dell’ordine (quantità, cliente, indirizzo, telefono, email e numero ordine) vengono compilati normalmente.
- La pagina segnala quante righe richiedono la compilazione manuale dello SKU dopo il download.
- Restano escluse soltanto le righe esplicitamente riconosciute come appartenenti a un fornitore diverso da Cecotec.
