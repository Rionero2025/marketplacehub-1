# Aggiornamento v121 — Contabilità ordini

- Aggiunta nel menu laterale la nuova pagina **Contabilità**.
- Scelta obbligatoria del marketplace e dell’account: Kaufland o Worten.
- Download via API di tutte le righe ordine nel periodo, compresi annullati,
  rifiutati, resi, rimborsati e rimborsati parzialmente.
- Lettura di prodotto, EAN, quantità, cliente, tracking/corriere, stato, vendita,
  commissione effettiva e importo da ricevere.
- Conversione automatica degli importi Kaufland PLN/CZK in EUR con cambio BCE.
- Match del costo di acquisto con listini e viste salvate del fornitore, prima
  per EAN e poi per SKU/codice prodotto. Per Cecotec usa il costo della nazione
  di destinazione.
- Ordini cancellati inclusi con valori economici azzerati; resi e rimborsi
  inclusi con ricavo marketplace azzerato e costo prodotto mantenuto, così non
  vengono mostrati utili inesistenti.
- Data **PAGATO** stimata come data ordine + 21 giorni; vuota quando non è dovuto
  alcun pagamento.
- Filtri per fornitore, stato API, nazione e ricerca; selezione multipla, Shift,
  selezione/deselezione di tutte le righe filtrate e memoria delle spunte.
- Campi manuali persistenti: N Ordine Fornitore, Costo Extra e SCONTRINO.
- File Excel con le colonne originali del prospetto e le colonne aggiuntive
  Stato Ordine, Quantità, Rimborso e Note contabili. Margini e percentuali sono
  formule Excel.
- Riepilogo automatico di vendite, acquisti, commissioni, rimborsi, importi da
  ricevere e ricavo netto.
- Archivio persistente dei file contabili e avviso prima di riesportare righe
  già incluse in un file precedente.
- 192 test automatici e 6 subtest superati.
