# Marketplace Hub v235 — struttura completa

Pacchetto completo autonomo. La cartella distribuita nello ZIP si chiama `marketplace_hub` e l'archivio si chiama `marketplace_hub.zip`.

- File totali nel pacchetto (manifesto incluso): **370**
- Pagine Python: **23**
- Servizi Python: **44**
- File test: **71**
- Versione: **235**
- Avvio normale: `AVVIA_WINDOWS.bat`
- Aggiornamento codice: automatico all'avvio, senza eseguire file di aggiornamento separati
- Dati preservati: `data`, database, Seller, ordini, storico, tariffe/configurazioni, `.streamlit/secrets.toml`, `.venv`
- Modalità Packlink: API key PRO diretta
- Mittente: warehouse Packlink reale (`selectedWarehouseId`)
- Destinatario: `to.country` + `to.zip_code` + `to.city` + `postal_zone_id_to` + `zip_code_id_to`
