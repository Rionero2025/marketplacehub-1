# Aggiornamento v108 — pagamento effettivo Kaufland

## Data comunicata da Kaufland

- La data effettiva di disponibilità del ricavato ha ora priorità sulla stima
  `ricevuto + 14 giorni`.
- Gli ordini nello stato API `sent_and_autopaid` vengono riconosciuti come già
  pagati e non restano più in **Non ancora determinabile**.
- Per questo stato `ts_updated_iso` identifica il passaggio a
  **Spedito e pagato automaticamente** e viene conservato come data effettiva
  di disponibilità.
- Sono supportati anche gli eventuali campi API espliciti di rilascio del
  ricavato, che hanno priorità sul timestamp dello stato.

## Esempio verificato

- Ordine: `MWUEH75`.
- Unità ordine: `314568010015543`.
- Stato: **Spedito e pagato automaticamente**.
- Data comunicata nel Seller Portal: **25-07-2026 alle 15:03**.
- Il programma mostra questa data come pagamento effettivo e non indica più
  **Non ancora determinabile**.

## Riepilogo degli ordini selezionati

- La tabella distingue la data di pagamento/disponibilità effettiva dalla
  previsione calcolata.
- Se tutte le unità selezionate sono già disponibili, il riepilogo usa la
  formulazione **è stato pagato del tutto entro la data gg-mm-aaaa**.
- Se almeno un pagamento è futuro, mantiene la formulazione
  **sarà pagato del tutto entro la data gg-mm-aaaa**.
- La fonte della data di pagamento è visibile in una colonna dedicata.

## Compatibilità

- Il database viene aggiornato automaticamente con la nuova colonna
  `payment_source`.
- Le installazioni precedenti e i dati già archiviati restano compatibili.
- Dopo l’installazione è sufficiente eseguire una nuova sincronizzazione degli
  ordini Kaufland.

## Verifica

La versione è stata controllata con compilazione completa e 138 test
automatici superati.
