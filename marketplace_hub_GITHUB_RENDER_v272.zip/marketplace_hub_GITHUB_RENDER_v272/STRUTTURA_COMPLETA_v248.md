# Marketplace Hub v248 — struttura del pacchetto completo

La v248 parte dalla pietra miliare v243, preserva Catalog Intelligence v244-v247 e corregge la classificazione dei prodotti nuovi su Kaufland affinché utilizzi automaticamente il servizio ufficiale di suggerimento categorie senza trasformare una bassa confidenza in un blocco tecnico.

## Struttura Python

- `pages/`: 24 file Python
- `services/`: 65 file Python
- `services/catalog_intelligence/`: 19 file Python
- `tests/`: 84 file Python
- `tools/`: 18 file Python
- `_release_payload/`: 109 file Python auto-riparanti
- codice applicativo controllato dal gate: 109 file Python

## File applicativi modificati

- `pages/3_Creazione_Prodotti.py`
- `services/kaufland.py`
- `services/catalog_intelligence/__init__.py`
- `services/catalog_intelligence/normalization.py`
- `services/catalog_intelligence/category_classifier.py`
- `services/catalog_intelligence/workflow.py`
- `services/catalog_intelligence/schema.py`
- `tools/verify_release_consistency.py`

## Test v248

- `tests/test_kaufland_category_decide_v248.py`

## Documentazione e verifica

- `AGGIORNAMENTO_v248.md`
- `VALIDAZIONE_v248.txt`
- `STRUTTURA_COMPLETA_v248.md`
- `tools/verify_package_v248.py`
- `VERIFICA_PACCHETTO_v248_WINDOWS.bat`
- `MANIFESTO_SHA256_v248.txt`

## Flusso categoria Kaufland

```text
Prodotto normalizzato completo
→ categorie foglia lette dal database
→ eventuale Knowledge Base approvata
→ POST /categories/decide/ con feed completo
→ prime cinque categorie ufficiali ordinate
→ controllo contro lo snapshot locale
→ AUTO_APPROVED oppure REVIEW
```

La chiamata ufficiale non sostituisce la tassonomia locale: lo snapshot salvato continua a essere l'autorità per verificare che l'ID esista e sia una categoria foglia del canale selezionato.

## Stati classificazione

- `AUTO_APPROVED`: categoria ufficiale prima in graduatoria e valida nello snapshot, oppure mapping approvato;
- `APPROVED`: categoria confermata manualmente;
- `REVIEW`: categoria incerta, API non disponibile, categoria non ancora presente nello snapshot o selezione manuale necessaria;
- nessun `BLOCKED` dovuto esclusivamente alla confidenza della categoria.

Il blocco tecnico resta disponibile nella preparazione/validazione del feed per dati obbligatori realmente mancanti.

## Persistenza

La v248 continua a utilizzare:

- snapshot tassonomia memorizzati;
- categorie foglia locali;
- candidati per prodotto;
- assegnazioni categoria;
- Knowledge Base dei mapping;
- job persistenti;
- payload e validazioni precedenti.

Le assegnazioni storiche `BLOCKED` create dalla sola classificazione vengono migrate a `REVIEW` senza eliminare dati.

## Funzioni preservate

Restano incluse:

- gestione Seller e account;
- fornitori e listini;
- Kaufland e Worten/Mirakl;
- Creazione Prodotti;
- tassonomie cached-first;
- feed completi e pubblicazione controllata;
- Buy Box persistente;
- cancellazione senza doppio download;
- Packlink PRO e CSV;
- ordini, tracking, contabilità e storico;
- SQLite e PostgreSQL;
- avvio unico tramite `AVVIA_WINDOWS.bat`;
- auto-riparazione del codice;
- gate obbligatorio di coerenza e manifesto SHA-256.
