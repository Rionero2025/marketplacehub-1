# Marketplace Hub v226 — Packlink: mittente e destinatario completi

## Problema corretto
Una spedizione poteva essere creata su Packlink con Paese visibile ma CAP/città non valorizzati, nonostante il mittente fosse già registrato in Marketplace Hub e i dati del cliente fossero presenti nell'ordine Kaufland/Worten.

## Correzioni v226
- Il destinatario non viene più letto solo dalla prima riga dell'ordine: i campi vengono recuperati dalla prima riga utile dell'intero ordine.
- Se la cache normalizzata è incompleta, vengono recuperati indirizzo, CAP, città, Paese, nome, telefono ed email anche dal `raw_json` già memorizzato.
- Sono gestite le strutture Kaufland `shipping_address_lookup -> address_data -> data` e le strutture Mirakl/Worten `shipping_address` / `delivery_address`.
- Il mittente registrato nella rubrica Marketplace Hub mantiene direttamente `street1`, `zip_code`, `city`, `country`, telefono ed email nel blocco `from` del Draft Packlink.
- Per un mittente locale non viene più aggiunto automaticamente un `selectedWarehouseId` remoto: questo evita che un vecchio magazzino Packlink possa sostituire i dati salvati localmente. L'ID viene inviato solo quando il magazzino è scelto direttamente da Packlink.
- Il payload `additional_data` è riallineato alla struttura del core Packlink, senza inventare identificativi di zona/CAP non restituiti da Packlink.
- Gli header di versione dell'integrazione sono aggiornati alla v226.

## Funzioni precedenti mantenute
- memoria per ordine di pacco, peso/dimensioni, tariffa, corriere, servizio, `service_id`, costo tariffa e valore dichiarato;
- `Seleziona tutti da rigenerare` ripristina le impostazioni precedenti;
- nessuna checkbox di conferma aggiuntiva dopo la scelta del corriere;
- creazione singola e massiva delle spedizioni Packlink.

## Aggiornamento installazione esistente
Chiudere Marketplace Hub, estrarre completamente il pacchetto e avviare:

`AGGIORNA_INSTALLAZIONE_ESISTENTE_v226_WINDOWS.bat`

Lo script preserva `data`, database, Seller, configurazioni, `.streamlit/secrets.toml`, credenziali cifrate e `.venv`.
