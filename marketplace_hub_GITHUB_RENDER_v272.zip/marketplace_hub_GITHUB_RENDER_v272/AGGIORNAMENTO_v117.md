# Aggiornamento v117 — selezione nelle date di pagamento

## Quadratini per ogni riga

La tabella **Date previste di pagamento** dispone ora di una colonna
`Seleziona` con un quadratino per ogni unità ordine.

Sono disponibili anche i comandi:

- `Seleziona tutte le righe di pagamento`;
- `Deseleziona tutte le righe di pagamento`.

La selezione è indipendente da quella della tabella ordini superiore e resta
stabile durante i ricalcoli Streamlit.

## Informazioni sulle righe scelte

Il riepilogo sotto la tabella considera esclusivamente le righe spuntate e
mostra:

- numero di righe selezionate;
- netto totale da ricevere;
- costo di acquisto rilevato;
- guadagno rilevato;
- netto già disponibile;
- netto ancora in attesa;
- data entro cui il blocco selezionato sarà completamente disponibile.

Gli ordini cancellati valgono zero e sono esclusi dalla data finale. Le righe
con costo non calcolabile concorrono al netto Kaufland, ma non ai totali di
costo e guadagno.

## Verifica

Compilazione completata e 170 test automatici superati.
