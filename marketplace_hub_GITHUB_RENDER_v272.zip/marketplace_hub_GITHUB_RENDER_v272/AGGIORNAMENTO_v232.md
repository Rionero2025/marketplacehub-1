# Marketplace Hub v232 — avvio unico con aggiornamento automatico

La v232 elimina l'obbligo operativo di eseguire un file `AGGIORNA_INSTALLAZIONE_ESISTENTE_...` prima di ogni nuova release.

## Flusso normale

1. Scarica il pacchetto completo.
2. Estrai lo ZIP.
3. Avvia **`AVVIA_WINDOWS.bat`**.

Se esiste l'installazione abituale in `%USERPROFILE%\Documents\marketplace_hub`, l'avvio confronta automaticamente la versione e i file critici. Se il pacchetto è più recente, sincronizza il codice e poi avvia Marketplace Hub. Se è già allineato, non ricopia nulla.

## Dati preservati automaticamente

La sincronizzazione esclude e non sovrascrive:

- `data/` e database;
- Seller, ordini, storico e configurazioni salvate nel database;
- tariffe e configurazioni Packlink memorizzate;
- `.streamlit/secrets.toml` e credenziali cifrate;
- `.venv`, `.runtime` e log locali.

Prima di una sincronizzazione vengono inoltre salvati in `data/backups/pre_auto_update_v232_*` gli eventuali file database/configurazione critici presenti.

## Protezione da downgrade

Se viene aperto per errore un vecchio pacchetto mentre nel PC è già installata una release più recente, l'avvio non esegue il downgrade e apre la versione più recente già installata.

## Prima installazione

Se `.venv` non esiste, `AVVIA_WINDOWS.bat` richiama automaticamente l'installer completo una sola volta e poi avvia il programma. Non è necessario lanciare manualmente `INSTALLA_TUTTO_WINDOWS.bat` per il normale flusso v232.

## Compatibilità Packlink

Il motore Packlink resta compatibile con il servizio v230+ e conserva tutte le correzioni fino alla v231: destinatario ricostruito dall'ordine corrente, warehouse ufficiale del mittente, memoria di tariffa/pacco e fix `_existing_shipping`.
