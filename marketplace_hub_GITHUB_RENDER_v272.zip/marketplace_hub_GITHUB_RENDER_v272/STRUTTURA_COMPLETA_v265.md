# Marketplace Hub v265 — struttura e garanzie

Release: **265**

## File principali aggiornati
- `app.py` — nuova voce laterale **Prodotti più venduti**;
- `pages/0_Dashboard.py` — riquadro cliccabile Top 10 e passaggio del periodo alla pagina statistiche;
- `pages/3_Prodotti_Piu_Venduti.py` — nuova pagina completa di classifica, filtri, confronto periodo precedente, dettaglio ed export CSV;
- `services/product_stats.py` — motore di aggregazione prodotto, filtri, ordinamenti, confronto e breakdown;
- `services/dashboard.py` — esposizione di Paese e SKU composito nelle righe di dettaglio già coerenti con Contabilità;
- `tests/test_product_stats_v265.py` — test del motore statistico;
- `tests/test_product_stats_ui_v265.py` — test dei contratti UI/navigazione;
- `services/catalog_intelligence/__init__.py` — allineamento versione release;
- `VERSION.txt` — release 265.

## Contratto Prodotti più venduti
- il ranking usa le quantità reali e non il semplice numero di righe/ordini;
- le righe economicamente azzerate non incrementano le unità vendute;
- EAN è la chiave prodotto prioritaria, con fallback a SKU composito e nome normalizzato;
- le statistiche derivano dalla cache `accounting_order_lines` e non richiedono chiamate API;
- margini incompleti restano `None`/Da verificare e non vengono trasformati in zero;
- filtri correnti e periodo vengono applicati anche al confronto con il periodo precedente;
- il periodo precedente ha la stessa durata dell'intervallo corrente;
- il dettaglio prodotto è sempre ricavato dalle stesse righe che compongono la classifica.

## Contratto Dashboard Top 10
- il riquadro usa il periodo selezionato nella Dashboard;
- la classifica è ordinata per unità vendute;
- l'apertura della pagina statistiche conserva il periodo;
- nessuna API viene chiamata per il rendering del Top 10;
- le righe di dettaglio già lette per il Top 10 vengono riutilizzate anche dalle card di dettaglio Dashboard, evitando un'ulteriore lettura duplicata nello stesso rendering.

## Regole release preservate
- ZIP finale `marketplace_hub.zip`;
- avvio con `AVVIA_WINDOWS.bat` dopo estrazione;
- `_release_payload` allineato al codice live, incluse la nuova pagina e il nuovo service;
- protezione anti-downgrade;
- database, `data`, Seller, ordini, storico INNPRO, credenziali, configurazioni e `.venv` preservati durante gli aggiornamenti ordinari.
