# Marketplace Hub v227 — rigenerazione senza ricalcolo tariffe già memorizzate

## Correzione
Quando si usa **Seleziona tutti da rigenerare**, la tariffa Packlink storica del singolo ordine viene ora considerata una tariffa valida a tutti gli effetti se pacco/peso/dimensioni coincidono con l'ultima configurazione salvata.

- Le tariffe precedenti ripristinate non vengono più contate tra gli ordini da quotare.
- Il riepilogo mostra correttamente `Con tariffe valide` e `Da quotare / ricalcolare`.
- Il pulsante massivo ricalcola esclusivamente gli ordini che non hanno alcuna tariffa valida.
- Se tutti gli ordini hanno la tariffa precedente ripristinata, il ricalcolo massivo è disabilitato.
- La tariffa storica resta utilizzabile per la creazione massiva senza una nuova interrogazione API.
- Una nuova quotazione viene richiesta solo quando l'utente modifica manualmente il singolo ordine/pacco oppure quando non esiste una configurazione storica compatibile.

Le correzioni v226 per mittente/destinatario rimangono incluse.
