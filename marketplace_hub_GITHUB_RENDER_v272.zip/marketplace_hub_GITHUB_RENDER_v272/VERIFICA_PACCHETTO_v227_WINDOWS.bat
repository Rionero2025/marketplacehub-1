@echo off
setlocal
cd /d "%~dp0"
set PY=python
if exist ".venv\Scripts\python.exe" set PY=.venv\Scripts\python.exe
%PY% tools\verify_package_v227.py
if errorlevel 1 (
  echo.
  echo VERIFICA v227 FALLITA.
  pause
  exit /b 1
)
echo.
echo PACCHETTO v227 VERIFICATO.
pause
