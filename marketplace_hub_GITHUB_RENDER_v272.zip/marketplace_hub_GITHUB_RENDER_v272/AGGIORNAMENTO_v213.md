# Marketplace Hub v213 — Correzione installazione Packlink PRO

## Problema corretto
La pagina `pages/4_Packlink_PRO.py` della v212 richiede funzioni introdotte nel servizio
`services/packlink.py` v211/v212, tra cui `load_packlink_weight_catalog`. Su alcune
installazioni Windows il file pagina era stato aggiornato mentre `services/packlink.py`
rimaneva alla versione precedente; il vecchio installer non interrompeva l'esecuzione
se una copia falliva. Il risultato era `ImportError: cannot import name
load_packlink_weight_catalog`.

## Correzione v213
- hotfix che sostituisce obbligatoriamente sia la pagina sia `services/packlink.py`;
- rimozione automatica dell'attributo sola lettura prima della copia;
- controllo `errorlevel` dopo ogni copia;
- verifica finale della presenza di `load_packlink_weight_catalog` e delle funzioni
  della memoria pacchi;
- marcatore `PACKLINK_SERVICE_VERSION = 213`;
- controllo preventivo nella pagina Packlink che mostra un messaggio leggibile se
  in futuro pagina e servizio dovessero essere nuovamente disallineati;
- pulizia delle cartelle `__pycache__` per forzare il caricamento dei file aggiornati.

Database, credenziali, ordini, indirizzi mittente, profili pacco e cartella `data` non
vengono modificati dall'hotfix.
