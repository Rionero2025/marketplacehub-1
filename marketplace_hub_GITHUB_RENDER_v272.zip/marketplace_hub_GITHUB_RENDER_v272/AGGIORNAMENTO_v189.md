# Aggiornamento v189

## Ripristino cancellazione Kaufland basata sulle pubblicazioni effettive

La pagina `Cancellazione dai Marketplace > Kaufland` è stata ripristinata alla logica stabile della v168.

- mostra esclusivamente i listini realmente pubblicati dall'account selezionato;
- ricostruisce le offerte ancora attive dalla cronologia `CREA/AGGIORNA` meno le cancellazioni già concluse;
- separa Produzione e Playground;
- permette di scegliere listino e Paesi;
- mantiene la cancellazione per intervalli con memoria persistente;
- usa lo SKU esatto inviato al marketplace, senza ricostruirlo dal listino corrente;
- al momento della cancellazione interroga Kaufland per quello SKU/storefront e cancella soltanto le unità effettivamente presenti;
- se un'offerta non è più presente, viene verificata senza creare conteggi artificiali da cache o snapshot globali.

Sono state rimosse dalla pagina Kaufland le modalità di azzeramento globale introdotte successivamente, che potevano sommare snapshot locali, duplicati o offerte di più storefront.
