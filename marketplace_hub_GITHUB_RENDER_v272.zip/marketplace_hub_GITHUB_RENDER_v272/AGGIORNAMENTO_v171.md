# Marketplace Hub v171

## Correzione definitiva parsing JSON IA Ticket

- Le risposte OpenAI Responses API vengono analizzate blocco per blocco senza concatenare più oggetti JSON.
- Il programma legge anche eventuali campi strutturati `parsed` presenti nella risposta.
- Se Responses API completa la richiesta ma non restituisce JSON utilizzabile, viene effettuato un secondo tentativo automatico tramite Chat Completions Structured Outputs con lo stesso schema rigoroso.
- Il fallback utilizza `max_completion_tokens`, non `max_tokens`.
- Le risposte non JSON di un provider non bloccano i provider di fallback configurati.
- Aggiunti test per output suddiviso in più blocchi e fallback Responses → Chat Completions.
