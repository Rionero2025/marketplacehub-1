# Aggiornamento v205 — PostgreSQL locale e migrazione protetta

- Aggiunto backend PostgreSQL tramite Psycopg 3 e connection pool.
- SQLite resta il backend predefinito per installazioni esistenti.
- Aggiunto layer di compatibilità per query `?`, `AUTOINCREMENT`, `PRAGMA table_info`, `GROUP_CONCAT` e BLOB.
- Convertiti gli upsert SQLite `INSERT OR IGNORE/REPLACE` in SQL portabile.
- Nuova configurazione persistente `data/database.toml`.
- Nuovo migratore `tools/migrate_sqlite_to_postgresql.py` con backup preventivo, copia completa, riallineamento identity e verifica conteggi.
- Nuovi script Windows per configurazione, migrazione, reset controllato e ritorno a SQLite.
- Nuova pagina laterale **Database** con stato backend, pool, test connessione e test scrittura.
- Launcher aggiornato per installare Psycopg e `psycopg_pool`.
- Nessuna cancellazione automatica del database SQLite.
- Suite SQLite: 389 test + 6 subtest superati.
