@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='data\database.toml'; if(!(Test-Path $p)){Write-Host 'database.toml non trovato'; exit 1}; $c=Get-Content $p -Raw; $c=[regex]::Replace($c,'(?m)^engine\s*=.*$','engine = \"sqlite\"'); Set-Content $p $c -Encoding UTF8; Write-Host 'SQLite riattivato. Riavvia Marketplace Hub.'"
pause
