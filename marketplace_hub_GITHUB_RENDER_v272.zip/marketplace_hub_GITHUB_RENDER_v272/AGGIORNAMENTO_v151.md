# Marketplace Hub v151

## Correzione HTTP 404 nell’invio tracking Worten

L’URL API Worten salvato dal programma termina normalmente con `/api`. Il client
OR23/OR24 aggiungeva nuovamente `/api/orders`, generando per errore un indirizzo
`/api/api/orders/...` e ricevendo HTTP 404.

La versione v151 normalizza l’URL dell’istanza Mirakl e accetta entrambe le
configurazioni:

- `https://marketplace.worten.pt`
- `https://marketplace.worten.pt/api`

Entrambe producono ora gli endpoint corretti:

- OR23: `PUT /api/orders/{order_id}/tracking`
- OR24: `PUT /api/orders/{order_id}/ship`

Il pulsante rimane `Invia aggiornamento spedizione` e non richiede di digitare
SPEDISCI.
