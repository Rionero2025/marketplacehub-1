# Marketplace Hub v165

## Tracciabilità ordini: selezione multipla stabile e filtri completi

- La tabella operativa della pagina **Tracciabilità ordini** usa AgGrid in modalità manuale.
- Le spunte multiple non causano più un rerun a ogni click: dopo la selezione si preme **Applica** nel componente.
- Il quadratino dell'intestazione seleziona tutte le righe attualmente filtrate nella griglia.
- Restano disponibili i pulsanti: seleziona tutti i filtrati, seleziona solo inviabili filtrati e deseleziona tutti.
- La selezione viene conservata in `session_state` anche cambiando filtri.

### Filtri aggiunti

- ricerca libera su ordine, cliente, tracking, corriere, market, fornitore e problemi;
- stato API marketplace;
- macro-stato marketplace;
- stato originale del file spedizioni;
- stato operativo;
- tracking presente o assente;
- corriere presente o assente;
- invio API consentito o bloccato;
- urgenza e scadenza;
- market/nazione;
- fornitore;
- numero minimo di unità/righe;
- solo ordini con problemi;
- azzeramento completo dei filtri avanzati.

Gli stati non riconosciuti vengono conservati e mostrati come `Altro / sconosciuto`, così eventuali nuovi codici API non vengono eliminati dalla vista.
