# Marketplace Hub v228 — bozze Packlink complete: Paese e Città/codice postale

## Problema corretto
Packlink PRO poteva creare la bozza ma lasciarla nello stato **INCOMPLETO**: nel pannello Destinatario i selettori **Paese** e **Città o codice postale** risultavano vuoti anche quando Marketplace Hub possedeva country, città e codice postale dell'ordine.

## Correzione v228
Prima di `POST /v1/shipments`, Marketplace Hub risolve sia il mittente sia il destinatario contro le API località Packlink:

- `locations/postalzones/origins` / `locations/postalzones/destinations` per l'identificativo interno del Paese/zona;
- `locations/postalcodes` per l'identificativo interno della Città/codice postale;
- valorizza `postal_zone_id_from`, `postal_zone_id_to`, `zip_code_id_from`, `zip_code_id_to` e `postal_zone_name_to` dentro `additional_data`;
- mantiene indirizzo, contatti e dati cliente provenienti dal marketplace;
- salva nello storico il payload realmente inviato a Packlink.

Se Packlink non riconosce Paese o Città/codice postale, la v228 **ferma quell'ordine prima di creare la bozza**, evitando nuove bozze INCOMPLETE da completare manualmente.

## Funzioni precedenti preservate
Rimangono attive la memoria del pacco e della tariffa precedente, la rigenerazione senza riquotazione quando la tariffa è valida, il recupero indirizzi Kaufland/Worten e la creazione massiva senza checkbox di conferma ridondante.
