# Marketplace Hub v218 — Packlink massivo, memoria pacchi, anti-duplicato e quote 400

## 1. Ordini già organizzati su Packlink
Per ogni ordine selezionato il programma controlla:
- l'ultima bozza Packlink creata da Marketplace Hub;
- le spedizioni Packlink già sincronizzate e abbinate tramite numero ordine / custom reference.

Quando trova una corrispondenza mostra:

**✓ Ordine già organizzato per la spedizione su Packlink**

Per sicurezza non crea una seconda bozza. È disponibile la casella:

**Seleziona se vuoi ricreare e forzare l'ordine per Packlink**

Solo attivandola vengono riabilitati pacco, tariffe e creazione. Le ricreazioni forzate non cancellano il vecchio riferimento: ogni nuova creazione viene registrata anche nello storico `packlink_order_draft_history`.

## 2. Creazione massiva delle bozze
Dopo aver scelto manualmente il servizio tramite radio button per ogni ordine, compare la sezione **Creazione massiva bozze Packlink**.

Il pulsante massivo:
- crea tutte le bozze pronte in una sola operazione;
- salta gli ordini già organizzati se non è stata attivata la forzatura;
- non si ferma se una singola bozza va in errore;
- mostra progresso ed esito ordine per ordine;
- è ripetibile: le bozze già riuscite vengono riconosciute e non duplicate.

Il servizio di spedizione continua a essere scelto manualmente per ogni ordine: nessun corriere viene preselezionato dal programma.

## 3. Memoria completa dei pacchi
Tutti i pacchi utilizzati per chiedere tariffe vengono memorizzati nel database del Seller con:
- peso;
- lunghezza;
- larghezza;
- altezza;
- nome/etichetta;
- numero di utilizzi;
- ultimo utilizzo.

È presente anche il pulsante **Salva questo pacco in memoria** per registrarlo esplicitamente prima della spedizione.

Non viene più applicato il limite UI delle prime 15/30 configurazioni locali: tutti i pacchi attivi del Seller sono disponibili per il riutilizzo.

Quando una bozza viene creata con successo, il pacco viene inoltre associato alla composizione prodotti dell'ordine così da essere riproposto nelle spedizioni future degli stessi articoli.

## 4. Correzione HTTP 400 nelle tariffe Packlink
La richiesta `/v1/services` mantiene peso e dimensioni reali e ora normalizza il codice postale prima dell'invio.

Sono gestiti in particolare i CAP numerici che possono perdere lo zero iniziale durante import/cache. Esempio: per Slovacchia `3851` viene ripristinato come `03851`. In caso di HTTP 400 il client prova soltanto varianti equivalenti del CAP, senza alterare peso o dimensioni.

Se tutte le varianti vengono rifiutate, l'errore indica Paese, CAP normalizzato e caratteristiche del pacco per permettere di capire se il problema è effettivamente il limite del servizio Packlink.

## 5. Ordini in perdita
Confermata la regola della v216/v217: redditività, margine, costo di acquisto e stato economico non vengono utilizzati per decidere se un ordine può essere inviato a Packlink.

## Database
La v218 aggiunge automaticamente la tabella `packlink_order_draft_history`. Non è richiesta alcuna migrazione manuale ed è compatibile con SQLite/PostgreSQL attraverso il layer database del progetto.
