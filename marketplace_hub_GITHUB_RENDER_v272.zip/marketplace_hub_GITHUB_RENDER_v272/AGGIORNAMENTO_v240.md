# Marketplace Hub v240 — normalizzazione internazionale CAP Packlink CSV

La v240 normalizza il CAP in base al Paese prima di generare `packlink_pro_import.csv`.

Correzione principale: Slovacchia `04011` -> `040 11`.
Sono gestiti anche i formati con separatore di CZ, PL, GR, PT, BR, NL, CA, IE, GB, JP, LV, AD, US e i sistemi numerici a lunghezza fissa dei principali Paesi europei/internazionali. Per i formati non riconosciuti il valore viene preservato senza trasformazioni distruttive.

Fonte delle regole: metadati UPU/libaddressinput (dataset usato da Chromium/Android per gli indirizzi internazionali).
