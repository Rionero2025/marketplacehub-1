# Marketplace Hub v246 — pubblicazione reale controllata Kaufland e Worten/Mirakl

## Obiettivo

La v246 sviluppa la terza fase di **Creazione Prodotti / Catalog Intelligence** partendo dalla v245 e preservando integralmente la pietra miliare v243.

La tassonomia, la categoria, il feed completo e la validazione vengono già preparati dalla v245. La v246 aggiunge il motore persistente che controlla i duplicati, crea o aggiorna i dati prodotto, attende l'esito e soltanto dopo crea o aggiorna l'offerta commerciale.

## Separazione obbligatoria prodotto/offerta

Il flusso non considera un prodotto pubblicato soltanto perché è stato generato un file o inviato un payload.

Stadi distinti:

1. controllo anti-duplicato;
2. creazione/aggiornamento product data;
3. elaborazione e accettazione del prodotto;
4. creazione/aggiornamento offerta;
5. verifica finale dello stato;
6. completamento del singolo item.

Un'offerta non viene inviata mentre il prodotto è ancora in elaborazione o è stato rifiutato.

## Pianificazione anti-duplicato

Per ciascun item vengono consultati:

- EAN;
- SKU Seller stabile;
- stato del canale già memorizzato;
- import ancora in corso;
- prodotto/offerta eventualmente già presenti sul marketplace.

Azioni possibili:

- `CREATE_PRODUCT`;
- `UPDATE_PRODUCT`;
- `POLL_PRODUCT` / `POLL_PRODUCT_IMPORT`;
- `CREATE_OFFER`;
- `UPDATE_OFFER`;
- `POLL_OFFER` / `POLL_OFFER_IMPORT`;
- `NO_ACTION`.

La stessa operazione conclusa con lo stesso hash non viene ripetuta. Se cambia il feed, viene riaperto soltanto il prodotto modificato.

## Kaufland

Il motore Kaufland implementa:

- ricerca del prodotto per EAN;
- ricerca della unit tramite `id_offer` e storefront;
- `PUT` dei product data;
- polling dello stato product data;
- creazione della unit/offerta;
- aggiornamento di una unit esistente tramite `PATCH /units/{id_unit}/`;
- esclusione dei campi immutabili dal PATCH;
- configurazioni warehouse, shipping group e VAT indicator;
- memorizzazione degli identificativi prodotto/unit;
- retry soltanto per errori temporanei.

## Worten/Mirakl

Il motore Mirakl implementa:

- controllo anti-duplicato tramite le API disponibili all'account;
- CSV prodotto UTF-8 con BOM e separatore `;`;
- invio P41 con forma multipart documentata e fallback compatibile soltanto dopo un esplicito HTTP 400/422;
- salvataggio dell'import ID;
- polling P42;
- download dei report disponibili;
- CSV offerta separato;
- invio OF01, polling dello stato e report OF03;
- associazione degli esiti ai prodotti tramite EAN/SKU quando presenti nei report.

Il programma usa le capacità effettivamente autorizzate dal tenant Worten. Un file solamente generato non viene marcato come pubblicato.

## Modalità Simulazione

La simulazione:

- non esegue chiamate di scrittura;
- genera payload/CSV locali;
- salva gli artefatti nel job;
- consente il download dalla pagina;
- lascia inalterato lo stato remoto.

## Modalità Reale

Le scritture sono protette da un doppio controllo:

1. modalità `REAL`;
2. `remote_write_enabled=True` trasmesso esclusivamente dal checkbox dell'interfaccia per il ciclo corrente.

Lo sblocco non viene persistito. Il repository elimina inoltre dalle impostazioni dei job chiavi, secret, token e altri dati sensibili.

## Job persistenti

Sono state aggiunte in modo idempotente:

- `publication_item_runtime`;
- `publication_item_events`;
- `product_channel_states`;
- `publication_artifacts`.

Le tabelle conservano prossima azione, controllo duplicati, identificativi remoti, import ID, risposte, retry, eventi, artefatti e stato del prodotto sul canale.

## Stati principali

- `READY`;
- `PLANNED`;
- `PRODUCT_SUBMITTED`;
- `PRODUCT_PROCESSING`;
- `PRODUCT_ACCEPTED`;
- `PRODUCT_REJECTED`;
- `OFFER_PENDING`;
- `OFFER_PROCESSING`;
- `OFFER_ACTIVE`;
- `OFFER_REJECTED`;
- `EXISTING_OFFER`;
- `COMPLETED`;
- `REVIEW_REQUIRED`.

## Errori e retry

Gli errori HTTP temporanei e di rete vengono classificati come retryable senza eliminare gli stati validi precedenti. Gli errori tecnici non correggibili automaticamente passano in revisione. Il pulsante di retry rimette in coda soltanto gli item compatibili.

## Tassonomia cached-first preservata

La v246 non introduce download automatici delle categorie. La pubblicazione utilizza lo snapshot già associato al job. Tassonomia e attributi non vengono riscaricati durante la pianificazione, il polling o la creazione dell'offerta.

## Verifica reale

Le logiche sono coperte da test con client Kaufland/Mirakl simulati, incluse idempotenza, import, polling, report, protezione scrittura, modifica del payload e aggiornamento offerta. Le chiamate live devono essere inizialmente verificate con le credenziali del Seller su un singolo prodotto.
