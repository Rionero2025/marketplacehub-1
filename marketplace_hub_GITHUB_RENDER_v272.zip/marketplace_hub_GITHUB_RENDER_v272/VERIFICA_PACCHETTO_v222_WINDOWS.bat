@echo off
setlocal
cd /d "%~dp0"
set "PY="
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
if not defined PY if exist ".runtime\python\python.exe" set "PY=.runtime\python\python.exe"
if not defined PY set "PY=python"
%PY% tools\verify_package_v222.py
if errorlevel 1 (
  echo.
  echo VERIFICA NON SUPERATA.
  pause
  exit /b 1
)
echo.
echo PACCHETTO v222 VERIFICATO.
pause
