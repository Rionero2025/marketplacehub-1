# Marketplace Hub v233 — Packlink: registrazione integrazione ufficiale e destinatario completo

## Problema corretto
Le bozze Packlink potevano contenere nome, cognome, indirizzo, telefono ed email del destinatario ma restare **INCOMPLETE** perché nel portale Packlink i selettori **Paese** e **Città o codice postale** non risultavano realmente agganciati, anche quando il payload locale conteneva `to.country`, `to.zip_code` e `to.city`.

## Allineamento al core Packlink 2026
La v233 segue il flusso del core e-commerce ufficiale Packlink aggiornato:

1. l'indirizzo destinatario continua a usare i campi ufficiali `country`, `zip_code`, `city`, `street1`, nome, cognome, telefono ed email;
2. il mittente usa il warehouse Packlink reale tramite `additional_data.selectedWarehouseId`;
3. Marketplace Hub registra automaticamente il negozio con `POST /v1/integrations` quando non esiste ancora un `integration_id` server-side;
4. l'`integration_id` restituito da Packlink viene salvato e inserito in `additional_data.integration_id` prima di `POST /v1/shipments`;
5. la sorgente draft legacy `PRO` viene migrata automaticamente a `module_marketplace_hub`, coerentemente con la convenzione dei moduli Packlink (`module_woocommerce`, ecc.);
6. gli header `X-Module-Version` e `X-Ecommerce-Version` sono aggiornati alla v233.

Marketplace Hub è locale e continua a sincronizzare gli stati via polling. Per la registrazione viene usato un URL webhook configurabile; in assenza di un endpoint pubblico viene usato il dominio RFC riservato `marketplace-hub.invalid`, che non può essere assegnato a terzi.

## Protezione anti-bozze incomplete
Se Packlink rifiuta la registrazione dell'integrazione, Marketplace Hub **blocca la creazione prima del POST della spedizione** e mostra l'errore API reale. Non vengono quindi create altre bozze incomplete in sequenza.

## Avvio
Non serve eseguire aggiornatori separati. Estrarre lo ZIP e usare soltanto:

`AVVIA_WINDOWS.bat`

L'avvio sincronizza automaticamente il codice nella cartella installata e preserva `data`, database, Seller, credenziali, ordini, storico, configurazioni e memoria delle tariffe Packlink.
