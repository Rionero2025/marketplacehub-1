# Marketplace Hub v216 — Packlink: ordini sempre abbinabili per numero ordine

## Regola operativa
Packlink non deve applicare alcun filtro economico agli ordini.

Un ordine non viene escluso per:
- perdita;
- margine negativo;
- costo non calcolabile;
- mancanza di dati contabili.

Se il numero ordine appartiene a uno degli account marketplace attivi del Seller, l'ordine deve poter essere recuperato, selezionato e portato al flusso Packlink. Gli eventuali dati obbligatori richiesti dall'API Packlink (indirizzo, pacco, servizio) restano naturalmente necessari al momento della creazione della bozza.

## Kaufland
La sincronizzazione massiva continua a leggere le order units, ma ora confronta il risultato con il manifest `/orders` e recupera via `/orders/{id_order}` gli ordini presenti nel manifest ma assenti dalle pagine per stato.

Il limite silenzioso predefinito di 5.000 righe è stato rimosso dalla sincronizzazione Kaufland e Worten.

## Caricamento file ordini
Il file caricato viene confrontato con **tutta la cache del Seller**, non soltanto con gli ordini del periodo attualmente visualizzato.

Se un numero presente nel file non è nella cache:
1. Kaufland: ricerca diretta tramite numero ordine su `/orders/{id_order}`;
2. Worten/Mirakl: ricerca OR11 tramite `order_ids` e, come fallback, `order_references_for_seller`;
3. l'ordine trovato viene inserito nella cache;
4. viene selezionato automaticamente;
5. resta elaborabile da Packlink anche se è fuori dal periodo visualizzato.

## Interfaccia
La pagina mostra esplicitamente la regola "nessuna esclusione per perdita/margine" e indica quanti ordini sono stati recuperati direttamente dai marketplace.

## Database
Nessuna migrazione schema richiesta.
