param(
    [string]$Target = "$env:USERPROFILE\Documents\marketplace_hub",
    [switch]$NoLaunch
)

$ErrorActionPreference = "Stop"
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Source = [System.IO.Path]::GetFullPath($Source).TrimEnd('\')
$Target = [System.IO.Path]::GetFullPath($Target).TrimEnd('\')
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host ("=" * 76) -ForegroundColor DarkCyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host ("=" * 76) -ForegroundColor DarkCyan
}
function Write-Ok([string]$Message) { Write-Host "[OK] $Message" -ForegroundColor Green }
function Fail([string]$Message) { throw $Message }

Write-Step "Marketplace Hub v225 - sincronizzazione installazione esistente"
Write-Host "Pacchetto sorgente: $Source"
Write-Host "Installazione target: $Target"

$sourceService = Join-Path $Source "services\packlink.py"
$sourcePage = Join-Path $Source "pages\4_Packlink_PRO.py"
if (-not (Test-Path $sourceService) -or -not (Test-Path $sourcePage)) {
    Fail "Il pacchetto sorgente non contiene i file Packlink richiesti. Estrai completamente lo ZIP v225 e riprova."
}
$sourceText = Get-Content $sourceService -Raw
if ($sourceText -notmatch 'PACKLINK_SERVICE_VERSION\s*=\s*(\d+)') { Fail "Versione Packlink non rilevabile nel pacchetto sorgente." }
$sourceVersion = [int]$Matches[1]
if ($sourceVersion -lt 224) { Fail "Il pacchetto sorgente non contiene services\packlink.py v224 o successivo: risulta v$sourceVersion." }
Write-Ok "Pacchetto sorgente Packlink v$sourceVersion"

if (-not (Test-Path $Target)) {
    Write-Step "Prima installazione nella cartella Documenti"
    New-Item -ItemType Directory -Force -Path $Target | Out-Null
}

# Ferma soltanto i processi Python che stanno eseguendo questa specifica installazione.
Write-Step "Chiusura Marketplace Hub in esecuzione"
try {
    $running = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -and $_.CommandLine.Contains($Target)
    }
    foreach ($proc in $running) {
        try { Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop; Write-Host "Chiuso processo $($proc.ProcessId)" }
        catch { Write-Host "Impossibile chiudere processo $($proc.ProcessId): $($_.Exception.Message)" -ForegroundColor Yellow }
    }
} catch {
    Write-Host "Controllo processi non disponibile: $($_.Exception.Message)" -ForegroundColor Yellow
}

# Backup dei dati critici PRIMA di qualunque copia.
Write-Step "Backup preventivo dei dati esistenti"
$backupRoot = Join-Path $Target "data\backups\pre_update_v225_$Stamp"
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
$backupFiles = @(
    "data\marketplace_hub.db",
    "data\marketplace_hub.db-wal",
    "data\marketplace_hub.db-shm",
    "data\marketplace_hub.db-journal",
    "data\database.toml",
    ".streamlit\secrets.toml"
)
$backedUp = 0
foreach ($relative in $backupFiles) {
    $candidate = Join-Path $Target $relative
    if (Test-Path $candidate) {
        Copy-Item $candidate -Destination $backupRoot -Force
        $backedUp++
    }
}
if ($backedUp -gt 0) { Write-Ok "Backup creato: $backupRoot ($backedUp file)" }
else { Write-Host "Nessun database/configurazione precedente da copiare." -ForegroundColor DarkGray }

$sourceResolved = $Source.ToLowerInvariant()
$targetResolved = $Target.ToLowerInvariant()
if ($sourceResolved -ne $targetResolved) {
    Write-Step "Sincronizzazione COMPLETA del codice v225"
    # /E copia tutto il programma senza cancellare i file utente nel target.
    # data, .venv, runtime/log e secrets.toml vengono volutamente preservati.
    $args = @(
        $Source, $Target, "/E", "/COPY:DAT", "/DCOPY:DAT", "/R:2", "/W:1", "/NFL", "/NDL", "/NP",
        "/XD", (Join-Path $Source "data"), (Join-Path $Source ".venv"), (Join-Path $Source ".runtime"), (Join-Path $Source "logs"),
        "/XF", "secrets.toml", "*.pyc", "*.pyo"
    )
    & robocopy @args | Out-Host
    $rc = $LASTEXITCODE
    if ($rc -ge 8) { Fail "Robocopy non ha completato la sincronizzazione (codice $rc)." }
    Write-Ok "Codice v225 copiato nell'installazione esistente"
} else {
    Write-Ok "Il pacchetto è già nella cartella di installazione: nessuna copia necessaria"
}

Write-Step "Pulizia cache Python"
Get-ChildItem -Path $Target -Directory -Filter "__pycache__" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem -Path $Target -File -Include "*.pyc","*.pyo" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
Write-Ok "Cache Python eliminate"

Write-Step "Verifica file realmente installati"
$targetService = Join-Path $Target "services\packlink.py"
$targetPage = Join-Path $Target "pages\4_Packlink_PRO.py"
if (-not (Test-Path $targetService) -or -not (Test-Path $targetPage)) { Fail "File Packlink mancanti dopo la sincronizzazione." }
$targetServiceText = Get-Content $targetService -Raw
$targetPageText = Get-Content $targetPage -Raw
if ($targetServiceText -notmatch 'PACKLINK_SERVICE_VERSION\s*=\s*(\d+)') { Fail "Versione services\packlink.py non rilevabile nel target." }
$installedVersion = [int]$Matches[1]
if ($installedVersion -lt 224) { Fail "Aggiornamento non riuscito: il target contiene ancora services\packlink.py v$installedVersion." }
if ($targetPageText -notmatch 'PACKLINK_REQUIRED_SERVICE_VERSION\s*=\s*224') { Fail "La pagina Packlink installata non è quella v225." }
if ($targetPageText -match 'Confermo la creazione della spedizione pronta per il pagamento su Packlink PRO') { Fail "La pagina Packlink installata contiene ancora la conferma ridondante rimossa in v225." }
if ($targetServiceText -notmatch 'def\s+last_order_draft_configuration\s*\(') { Fail "last_order_draft_configuration manca nel servizio installato." }
Write-Ok "services\packlink.py installato: v$installedVersion"
Write-Ok "Pagina Packlink v225 allineata"
Write-Ok "Memoria configurazione/tariffa Packlink presente"

# Se esiste già un virtualenv, verifica l'import reale dal TARGET per escludere moduli vecchi.
$venvPython = Join-Path $Target ".venv\Scripts\python.exe"
if (Test-Path $venvPython) {
    Write-Step "Verifica import reale con il Python dell'installazione"
    $check = "import pathlib,sys; root=pathlib.Path(r'$Target'); sys.path.insert(0,str(root)); import services.packlink as p; print(p.__file__); print(p.PACKLINK_SERVICE_VERSION); assert int(p.PACKLINK_SERVICE_VERSION)>=224; assert hasattr(p,'last_order_draft_configuration')"
    & $venvPython -c $check
    if ($LASTEXITCODE -ne 0) { Fail "Import reale services.packlink non riuscito dal target." }
    Write-Ok "Import reale Packlink service v224+ riuscito"
}

Write-Host ""
Write-Host "AGGIORNAMENTO v225 COMPLETATO" -ForegroundColor Green
Write-Host "Dati, database, Seller, credenziali e secrets.toml sono stati preservati." -ForegroundColor Green
Write-Host "Installazione attiva: $Target" -ForegroundColor Green

if (-not $NoLaunch) {
    $startBat = Join-Path $Target "AVVIA_WINDOWS.bat"
    if (Test-Path $startBat) {
        Write-Step "Avvio Marketplace Hub aggiornato"
        Start-Process -FilePath $startBat -WorkingDirectory $Target
    }
}
