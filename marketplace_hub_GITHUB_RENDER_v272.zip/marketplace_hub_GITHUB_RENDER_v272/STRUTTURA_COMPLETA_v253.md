# Marketplace Hub v253 — struttura e garanzie

Release completa costruita sulla baseline stabile v243 e su tutte le funzioni v244-v252.

## Componenti
- pagine Streamlit: 24
- servizi Python: 65
- strumenti Python: 23 (incluso verificatore v253)
- file Python applicativi principali: 114
- test automatici: 91

## Correzioni v253
- Invio massivo Packlink non più bloccato dal riepilogo stale dei frammenti Streamlit dopo la selezione manuale delle tariffe.
- Il pulsante massivo rilegge al click i candidati aggiornati in `st.session_state` ed elabora solo quelli realmente pronti.
- Telefono destinatario: se assente nell'ordine, viene usato automaticamente il telefono mittente.
- Fallback telefono applicato sia al payload API sia al CSV ufficiale Packlink.
- Il numero cliente presente ha sempre priorità e non viene sovrascritto.
- I contatti del mittente locale completano il warehouse Packlink quando l'API non restituisce telefono/email.
- CSV Packlink generabile indipendentemente dall'esito della creazione bozza via API.
- Report CSV con indicazione degli ordini che hanno usato il telefono mittente come fallback.

## Auto-riparazione
Tutto il codice Python applicativo è duplicato in `_release_payload` e verificato prima della distribuzione.

## Distribuzione
Il file distribuito si chiama sempre `marketplace_hub.zip`.
Flusso utente: estrai -> `AVVIA_WINDOWS.bat`.
Nessuna installazione o aggiornamento manuale separato.
