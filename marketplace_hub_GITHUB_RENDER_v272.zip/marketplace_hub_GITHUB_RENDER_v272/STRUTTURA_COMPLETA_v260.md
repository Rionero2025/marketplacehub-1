# Marketplace Hub v260 — struttura e garanzie

Release: **260**

## Evoluzione principale
La release introduce un sistema nativo di **backup e trasferimento completo dei dati tra PC**. L'utente non deve più copiare manualmente database, cartelle `data` o `secrets.toml`.

## Nuovi file applicativi
- `pages/5_Backup_Trasferimento.py`
- `services/data_transfer.py`
- `tests/test_data_transfer_v260.py`

## File modificati
- `app.py` — nuova voce di navigazione **Backup e trasferimento**;
- `services/catalog_intelligence/__init__.py` — allineamento release a v260.

## Contratto `services.data_transfer`
Il servizio espone:
- `create_transfer_package(password)`;
- `inspect_transfer_package(package_bytes, password)`;
- `restore_transfer_package(package_bytes, password)`;
- `TransferError` per errori di validazione/import.

### Formato
- identificatore: `marketplace-hub-transfer`;
- formato: v1;
- estensione UI: `.mhubbackup`;
- cifratura: Fernet;
- derivazione chiave: PBKDF2-HMAC-SHA256;
- salt casuale per ogni backup;
- SHA-256 individuale per ogni payload interno.

### SQLite
`marketplace_hub.db` viene acquisito tramite `sqlite3.Connection.backup()` e verificato con `PRAGMA integrity_check`.

### File persistenti
Vengono inclusi tutti i file regolari sotto `data/`, ad eccezione del database copiato separatamente e dei file transitori WAL/SHM/journal/tmp/part.

`data/database.toml` viene rigenerato in forma portabile dalla configurazione **attiva**:
- `engine = "sqlite"` per installazioni SQLite;
- configurazione PostgreSQL completa e risolta per installazioni PostgreSQL.

### Credenziali
Il pacchetto include `.streamlit/secrets.toml`; se il file non esiste ma `MARKETPLACE_HUB_MASTER_KEY` è disponibile nell'ambiente, il servizio crea nel backup un `secrets.toml` portabile contenente la chiave attiva.

Questo è necessario perché le credenziali marketplace/API nel database restano cifrate con la stessa master key.

## Sicurezza import
L'import accetta solo:
- `manifest.json`;
- `database/marketplace_hub.db`;
- `config/secrets.toml`;
- file sotto `data/`.

Sono rifiutati percorsi assoluti, `..`, membri non dichiarati, checksum incoerenti, pacchetti non autenticati e backup creati da una release successiva a quella installata.

## Staging e rollback
Il contenuto viene scritto prima in una cartella temporanea sotto la root del programma.

Il cambio dati avviene solo dopo la validazione completa:
- `data/` corrente → `migration_backups/pre_import_.../data`;
- staging `data/` → `data/` attivo.

Se un passaggio successivo fallisce, il servizio tenta il rollback automatico dei dati e del `secrets.toml` precedente.

## UI
La pagina mostra:
- password + conferma per esportazione;
- pulsante di preparazione backup;
- metriche Seller/account/listini/file;
- download del `.mhubbackup`;
- upload backup sul PC di destinazione;
- verifica preventiva senza modifica dati;
- riepilogo release/database/contenuto;
- conferma esplicita prima dell'importazione;
- percorso del backup automatico precedente;
- messaggio di riavvio obbligatorio.

## Test specifici v260
`tests/test_data_transfer_v260.py` verifica:
- export/import SQLite completo;
- ripristino Seller/database;
- ripristino file `data/`;
- trasferimento master key;
- creazione backup automatico dello stato destinazione;
- rifiuto password errata;
- rifiuto backup proveniente da release più nuova;
- password minima;
- configurazione PostgreSQL attiva resa portabile;
- presenza della nuova pagina nella navigazione.

## Contratti preservati
- distribuzione finale: `marketplace_hub.zip`;
- avvio: estrai → `AVVIA_WINDOWS.bat`;
- auto-riparazione dal `_release_payload`;
- protezione anti-downgrade;
- normali aggiornamenti preservano `data`, database, Seller, ordini, storico, configurazioni, credenziali e `.streamlit/secrets.toml`;
- riuso `.venv`/Python esistenti;
- Contabilità v259 preservata;
- Catalog Intelligence preservato;
- Packlink v255 preservato.
