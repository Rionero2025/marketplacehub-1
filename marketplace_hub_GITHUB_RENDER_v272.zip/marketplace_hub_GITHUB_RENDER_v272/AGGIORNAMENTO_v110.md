# Aggiornamento v110 — guadagno ordini Kaufland dallo SKU

## Struttura dello SKU

Il programma riconosce gli SKU composti nel formato:

`fornitore_EAN_costoacquisto_prezzominimo`

La lettura avviene partendo da destra, quindi resta valida anche quando il nome
del fornitore contiene un trattino basso.

Esempio:

`Innpro_6974662350503_335.07_452.34`

- Fornitore: `Innpro`
- EAN: `6974662350503`
- Costo di acquisto: `335,07 €`
- Prezzo minimo: `452,34 €`

## Calcolo del guadagno

`Guadagno ordine = netto pagato da Kaufland − costo di acquisto dello SKU`

La percentuale viene calcolata sul costo:

`Guadagno % = guadagno ordine ÷ costo di acquisto × 100`

## Interfaccia

- Nuove colonne: costo acquisto SKU, guadagno ordine, guadagno percentuale e
  fonte del costo.
- Nuovi totali: costo acquisto, guadagno, percentuale complessiva sul costo,
  unità in perdita e unità senza costo rilevabile.
- Costo e guadagno compaiono anche nella tabella delle date di pagamento, nel
  riepilogo per valuta originale e nei CSV.
- Gli ordini cancellati incidono zero sul guadagno complessivo.
- Gli SKU originali o non conformi restano non calcolabili: il programma non
  inventa un costo.

## Verifica

Compilazione completata e 146 test automatici superati.
