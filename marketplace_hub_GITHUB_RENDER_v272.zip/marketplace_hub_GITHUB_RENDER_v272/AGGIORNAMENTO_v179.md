# Marketplace Hub v179

## Correzione unità multiple Kaufland negli ordini Cecotec

La verifica live non passa più una stringa contenente più `id_order_unit`
separati da virgole a un endpoint che accetta un solo identificativo numerico.

- gli ID aggregati vengono separati e verificati singolarmente;
- la tabella di controllo mostra una riga per ogni unità Kaufland;
- se tutte le unità sono pronte, il comportamento rimane invariato;
- se soltanto alcune unità devono ancora essere spedite, il file Cecotec include
  esclusivamente quelle unità e adegua automaticamente la quantità;
- unità già spedite, ricevute, cancellate o ancora `open` vengono escluse;
- se anche una sola unità non può essere verificata, la riga viene bloccata per
  evitare ordini fornitore incompleti o duplicati;
- sono supportati anche vecchi valori salvati come JSON, con punto e virgola o
  separatori multipli.
