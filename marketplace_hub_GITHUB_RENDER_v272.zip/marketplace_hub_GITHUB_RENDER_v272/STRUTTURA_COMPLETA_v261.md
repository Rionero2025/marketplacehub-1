# Marketplace Hub v261 — struttura e garanzie

Release: **261**

## File modificati
- `services/data_transfer.py` — formato backup v2, compattazione, compatibilità v260, rilocazione percorsi;
- `pages/5_Backup_Trasferimento.py` — UI dimensione/compattazione e messaggio upload 1 GB;
- `.streamlit/config.toml` — upload/message size 1 GB;
- `services/catalog_intelligence/__init__.py` — allineamento release.

## Nuovi test
- `tests/test_data_transfer_v261.py`.

## Contratto backup v261
- formato logico: `marketplace-hub-transfer`, versione 2;
- cifratura: AES-256-GCM binaria;
- KDF: PBKDF2-HMAC-SHA256, 600.000 iterazioni;
- checksum SHA-256 per ogni file interno;
- snapshot SQLite consistente e `PRAGMA integrity_check`;
- compattazione dei file gestiti non più referenziati;
- riscrittura dei percorsi assoluti verso il nuovo PC;
- import retrocompatibile dei backup formato v1/v260 Fernet;
- staging, safety backup e rollback come in v260.

## Limite upload
La configurazione Streamlit distribuita e auto-riparata imposta 1024 MB per upload e messaggi.

## Regole release preservate
- ZIP finale sempre `marketplace_hub.zip`;
- avvio esclusivamente con `AVVIA_WINDOWS.bat` dopo estrazione;
- `_release_payload` allineato al codice live;
- protezione anti-downgrade;
- dati, credenziali e `.venv` preservati durante gli aggiornamenti ordinari.
