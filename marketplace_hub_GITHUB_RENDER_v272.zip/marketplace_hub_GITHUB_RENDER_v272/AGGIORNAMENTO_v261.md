# Marketplace Hub v261 — Backup compatto e import oltre 200 MB

## Correzione principale
La v260 esportava indiscriminatamente tutti i file sotto `data/` e cifrava il pacchetto con Fernet. Questo poteva produrre backup molto grandi perché:
- nelle cartelle dei listini restavano download precedenti, file intermedi e copie non più utilizzate;
- Fernet codifica il contenuto cifrato in Base64, aggiungendo circa il 33% di dimensione al file già compresso;
- Streamlit accettava di default upload fino a 200 MB.

## Nuovo formato v2
La v261 usa **AES-256-GCM binario** con chiave derivata tramite PBKDF2-HMAC-SHA256. Non esiste più l'espansione Base64 tipica di Fernet.

I backup v260 restano importabili: la v261 riconosce anche il vecchio magic/header e continua a decifrare i pacchetti Fernet.

## Compattazione sicura
Per SQLite il database viene prima acquisito con la SQLite Backup API. Da quello snapshot vengono individuati i file locali realmente referenziati dalle tabelle applicative.

Nelle cartelle gestite:
- `price_lists`;
- `saved_views`;
- `accounting_exports`;
- `cecotec_orders`;
- `catalog_intelligence`;

vengono trasferiti i file ancora collegati al database. File vecchi, duplicati o orfani non più referenziati non entrano nel backup. Nessun file viene cancellato dal PC sorgente.

Le altre configurazioni e i file persistenti non gestiti continuano a essere trasferiti normalmente.

## Percorsi portabili tra PC
La v261 corregge anche i percorsi assoluti salvati nel database (`local_path`, `snapshot_path`, `file_path`). Durante l'import sul nuovo PC vengono riscritti verso la nuova cartella `data` dell'installazione di destinazione.

La riscrittura viene eseguita anche per i vecchi backup v260, ricostruendo i percorsi dai file presenti nel pacchetto.

## Upload
`.streamlit/config.toml` porta a **1 GB** i limiti locali:
- `server.maxUploadSize = 1024`;
- `server.maxMessageSize = 1024`.

Questo permette di importare anche un backup v260 già creato da 300–400 MB, se necessario.

## UI
La pagina mostra ora:
- dimensione reale del backup generato;
- numero e dimensione dei file vecchi/orfani esclusi automaticamente;
- tipo di cifratura;
- indicazione esplicita della compatibilità con backup v260.

## Compatibilità preservata
Restano invariati Contabilità v259, Catalog Intelligence, Packlink v255, database, Seller, account marketplace, ordini, storico, credenziali e avvio `estrai → AVVIA_WINDOWS.bat`.
