# Marketplace Hub v135

## Contabilità: celle editabili con memoria permanente

La tabella principale della Contabilità consente ora la modifica diretta delle celle operative:

- fornitore e prodotto;
- EAN e quantità;
- vendita, acquisto, commissione, rimborso, importo da ricevere e costo extra;
- numero ordine fornitore;
- pagamento stimato;
- cliente, tracking, scontrino e note.

Le modifiche vengono salvate automaticamente nel database senza pulsante di conferma e senza chiamare `st.rerun`. La griglia conserva posizione, filtri, ordinamento e selezione.

Gli override manuali sono registrati nella tabella `accounting_manual_overrides`; per questo:

- restano disponibili dopo la chiusura e il riavvio del programma;
- non vengono cancellati da un nuovo download API;
- non vengono cancellati dal ricalcolo dei costi sui listini;
- vengono utilizzati anche nella Dashboard, nei totali, nella ripartizione del margine e nell'Excel esportato.

Gli identificativi ordine, lo stato, le fonti e le formule rimangono protetti. Le regole di azzeramento per annullati, cancellati, no stock e rimborsati prevalgono sempre sulle modifiche manuali.
