# Marketplace Hub v251 — concorrenza SQLite e bootstrap non bloccante

## Problema corretto
Durante una normalizzazione Catalog Intelligence con molte righe, una transazione di scrittura SQLite poteva essere ancora attiva mentre Streamlit eseguiva un nuovo rerun della pagina. Il rerun richiamava nuovamente `bootstrap()` e quindi l'intera catena DDL, inclusa `ensure_catalog_schema()`. SQLite consente un solo writer alla volta e poteva quindi generare `sqlite3.OperationalError: database is locked`.

## Correzioni strutturali
- `init_db()` è ora inizializzato una sola volta per processo e per database attivo.
- Le chiamate successive di bootstrap nello stesso processo sono no-op e non rieseguono CREATE/ALTER/DDL.
- `services.catalog_intelligence.schema.ensure_schema()` è protetto da cache process-scoped per database e revisione schema.
- La migrazione Catalog Intelligence non viene più eseguita ad ogni funzione repository.
- La pagina `Creazione Prodotti` non richiama più un secondo `ensure_schema()` immediatamente dopo `bootstrap()`.
- SQLite usa timeout connessione di 60 secondi e `PRAGMA busy_timeout=60000`.
- WAL, `synchronous=NORMAL` e foreign keys restano attivi.
- La persistenza dei cataloghi continua a effettuare commit per batch: i writer lock sono rilasciati tra un blocco e l'altro.
- Retry automatico sui lock temporanei rimane attivo.

## Compatibilità cache normalizzazione
`NORMALIZATION_ENGINE_VERSION` resta intenzionalmente a 250: v251 corregge la concorrenza DB ma non modifica il contenuto normalizzato. Gli snapshot v250 già completi possono quindi essere riutilizzati senza rigenerare inutilmente migliaia di prodotti.

## Gate release
Il gate obbligatorio ora impedisce la distribuzione se:
- manca la cache process-scoped dell'inizializzazione DB;
- manca la guardia dello schema Catalog Intelligence;
- timeout/busy timeout SQLite tornano a valori non protetti;
- la pagina reintroduce `bootstrap()` seguito da `ensure_schema()`;
- `_release_payload` non coincide con il codice live.

## Dati preservati
Nessuna cancellazione di database, `data`, Seller, account, ordini, listini, tassonomie, cataloghi normalizzati, job, tariffe, configurazioni, credenziali o `.streamlit/secrets.toml`.
