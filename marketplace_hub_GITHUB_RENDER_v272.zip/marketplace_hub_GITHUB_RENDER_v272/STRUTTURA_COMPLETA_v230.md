# Marketplace Hub v230 — struttura completa

- pagine Python: **23**
- servizi Python: **44**
- file di test: **67**
- strumenti Python: **8**

La release v230 è costruita sopra la v229 completa e mantiene Kaufland, Worten, Cecotec, Packlink PRO, contabilità, tracciabilità, database SQLite/PostgreSQL, migrazioni e installer Windows.

Correzione principale v230: la destinazione Packlink viene ricostruita dall'ordine corrente immediatamente prima del POST e le candidature batch precedenti non possono più sostituire Paese/Città/codice postale.
