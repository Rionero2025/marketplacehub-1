# Marketplace Hub v154

## Tracciabilità: selezione persistente, invii idempotenti e scadenze

### Selezione ordini

- Le selezioni della tabella **Ordini con tracking abbinato** vengono conservate in `st.session_state` e non si perdono dopo il rerun di Streamlit.
- Sono disponibili i pulsanti **Seleziona tutti**, **Seleziona solo inviabili** e **Deseleziona tutti**.
- I pulsanti agiscono sugli ordini visibili dopo l'applicazione dei filtri.

### Controllo degli ordini già spediti

- Prima di mostrare la tabella viene letto lo storico persistente degli invii API riusciti.
- Prima dell'invio viene eseguito un secondo controllo per evitare doppi invii causati da rerun, schede multiple o selezioni obsolete.
- Gli ordini già spediti vengono saltati e non bloccano l'invio degli ordini restanti.
- Il riepilogo distingue ordini inviati, già spediti e saltati, ed eventuali errori.

### Data limite di spedizione

- Per Worten viene letta prima di tutto la data `shipping_deadline` restituita da Mirakl.
- Per Kaufland viene letta la data `delivery_time_expires_iso` restituita sulle order unit.
- Se Mirakl non restituisce la data esatta ma fornisce `leadtime_to_ship`, viene mostrata una data esplicitamente indicata come **stimata**.
- Gli ordini senza dato API non ricevono scadenze inventate e mostrano **Non disponibile**.

### Filtri urgenza

Sono disponibili:

- **Filtra ordini urgenti (<24 ore)**;
- **Filtra ordini scaduti**;
- filtro per intervallo **Scadenza dal / al**;
- **Mostra tutti**.

Gli ordini già scaduti sono evidenziati in rosso e la data di scadenza usa uno sfondo rosso acceso. Gli ordini con meno di 24 ore sono evidenziati in arancione.
