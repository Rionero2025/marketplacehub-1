# Marketplace Hub v250 — struttura completa

Release completa derivata dalla baseline v243 con Catalog Intelligence v244-v250.

## Funzioni v250

- avanzamento percentuale reale durante lettura, normalizzazione e persistenza;
- contatori prodotti letti, normalizzati e memorizzati;
- velocità e ETA;
- persistenza durabile a blocchi;
- normalizzazione accelerata dei parametri Innpro/IOF;
- `producer` → `brand` con provenienza;
- conservazione di descrizioni, immagini, documenti e parametri tecnici;
- cache persistente degli snapshot già completati.

## Struttura applicativa

- `pages/`: 24 pagine Python;
- `services/`: 65 file Python;
- `tests/`: 88 file Python;
- `tools/`: 20 verificatori/migrazioni Python;
- `_release_payload/`: copia auto-riparante di tutto il codice Python applicativo.

## Distribuzione

Il file distribuito deve chiamarsi sempre `marketplace_hub.zip`.

Uso normale:

1. estrai;
2. avvia `AVVIA_WINDOWS.bat`.
