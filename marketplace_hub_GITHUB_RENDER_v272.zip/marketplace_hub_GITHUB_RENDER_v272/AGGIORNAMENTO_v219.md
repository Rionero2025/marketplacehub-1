# Marketplace Hub v219 — Packlink PRO veloce e pronto per il pagamento

## Obiettivo
Questa release interviene su due punti del flusso Packlink PRO:

1. eliminare il rerun dell'intera pagina quando si modifica una singola spedizione;
2. creare record Packlink completi destinati al flusso **Bozza → Pronti per il pagamento**, in modo che sul sito Packlink resti soltanto il pagamento prima dell'etichetta.

## Prestazioni Streamlit
- Ogni ordine Packlink è ora renderizzato da un proprio `st.fragment` indipendente.
- Modificare pacco, peso, dimensioni, servizio, conferma o valore dichiarato reruna solo la scheda di quell'ordine.
- Le altre decine di ordini non vengono rieseguite.
- Non vengono riscaricati marketplace, file caricati, listini o cataloghi durante queste interazioni.
- Il controllo massivo tariffe è un fragment separato.
- La creazione massiva è un fragment separato e legge le scelte conservate in `st.session_state`.
- Un rerun completo viene effettuato soltanto dopo un'operazione massiva di ricalcolo tariffe, per aggiornare tutte le schede in una sola volta.

## Packlink: Pronti per il pagamento
Il flusso di creazione usa `POST /v1/shipments`, come il core e-commerce ufficiale Packlink, ma prima dell'invio Marketplace Hub verifica che siano presenti tutti i dati controllabili localmente:

- mittente completo, telefono ed email;
- destinatario completo, telefono ed email;
- servizio e corriere scelti;
- peso e dimensioni validi;
- contenuto, valore e valuta;
- numero ordine marketplace;
- metadati articolo;
- `selectedWarehouseId` solo quando il mittente locale corrisponde in modo forte e univoco a un vero magazzino restituito da Packlink;
- data/fascia di ritiro solo quando sono restituite dalla tariffa Packlink selezionata, senza inventare valori.

Dopo la creazione viene eseguito anche un GET della spedizione appena creata per leggere, quando già disponibile, lo stato remoto restituito da Packlink.

## Invio massivo
Le scelte di servizio dei singoli ordini vengono conservate in Session State. Il blocco massivo legge tali scelte al momento dell'invio, crea tutte le spedizioni pronte una dopo l'altra e continua anche se un singolo ordine restituisce errore.

## Memoria pacchi e anti-duplicato
Restano attive tutte le funzioni v218:
- memoria permanente di peso e dimensioni;
- riuso dei pacchi del Seller;
- peso prioritario dai listini;
- controllo ordini già organizzati;
- forzatura esplicita per ricreare una spedizione;
- storico dei riferimenti Packlink.
