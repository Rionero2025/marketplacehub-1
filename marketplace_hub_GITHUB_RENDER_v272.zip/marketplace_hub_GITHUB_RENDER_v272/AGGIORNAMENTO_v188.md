# Marketplace Hub v188

## Cancellazione Kaufland semplificata

- Rimossi dal progetto operativo tutti i riferimenti alla precedente modalità basata su file pubblici.
- La pagina mostra soltanto **Cancella tutto il catalogo** e **Cancella offerte selezionate**.
- Eliminati campi, messaggi, metodi client, servizi e test non più utilizzati.
- Nuove chiavi Streamlit v188 impediscono il ripristino di widget appartenenti a versioni precedenti.
- Restano selezione multipla senza rerun, filtri avanzati, ripresa delle operazioni, retry, gestione 429 e verifica delle offerte residue.
