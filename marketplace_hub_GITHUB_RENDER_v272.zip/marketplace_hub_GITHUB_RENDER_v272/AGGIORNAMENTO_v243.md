# Marketplace Hub v243 — Cancellazione Kaufland senza doppio download

## Obiettivo
La pagina **Cancellazione dai Marketplace → Kaufland** non riscarica più l'inventario una seconda volta quando l'utente preme **Cancella tutto** o **Cancella offerte selezionate**.

## Nuovo flusso
1. L'utente scarica/aggiorna e verifica le offerte una sola volta.
2. Le unità reali Kaufland restano memorizzate nel database locale.
3. Filtri e selezione lavorano sul set memorizzato.
4. Alla conferma della cancellazione, gli ID `id_unit` già verificati diventano direttamente il set di DELETE.
5. Non viene eseguito un nuovo `GET /units` prima della cancellazione.
6. Dopo i DELETE, il database locale viene aggiornato con `mark_units_removed`; non viene eseguita automaticamente una terza scansione completa.
7. Un `404` durante DELETE viene considerato **già assente**, quindi completato correttamente.

## Sicurezza operativa
- **Cancella tutto** significa tutte le offerte presenti nell'ultima fotografia verificata e memorizzata dei Paesi scelti.
- Eventuali nuove offerte arrivate sul marketplace dopo l'ultima sincronizzazione non vengono inventate né ricercate implicitamente: per includerle basta premere esplicitamente **Aggiorna offerte nuove e modificate** prima della cancellazione.
- La cancellazione continua a usare gli `id_unit` reali restituiti da Kaufland.

## Prestazioni
Viene eliminato il secondo ciclo di download dell'inventario prima dei DELETE e anche la risincronizzazione automatica successiva. La cancellazione parte immediatamente sul set già pronto in memoria persistente.
