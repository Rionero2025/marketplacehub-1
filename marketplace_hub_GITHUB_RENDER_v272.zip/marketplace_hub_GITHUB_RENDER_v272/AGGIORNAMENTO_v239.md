# Marketplace Hub v239 — Export CSV ufficiale Packlink PRO

## Obiettivo
La v239 aggiunge la generazione del CSV ufficiale Packlink PRO direttamente dagli ordini selezionati, evitando la creazione bozza via API quando si preferisce l’importazione massiva CSV.

## Tracciato
- usa esattamente le 30 colonne del template italiano Packlink `csv_pro.csv`;
- separatore `;`;
- codifica UTF-8 con BOM;
- CAP esportati come testo, quindi vengono conservati gli zeri iniziali (es. `04011`);
- colonna assicurazione valorizzata esclusivamente con `yes` o `no`;
- decimali con punto.

## Dati
Per ogni ordine selezionato vengono esportati mittente, destinatario, Paese, CAP/città, telefono/email, titolo merce, valore dichiarato, peso e dimensioni del pacco. Il pacco segue la stessa memoria per ordine già utilizzata nella pagina Packlink.

## Utilizzo
Nella pagina Packlink PRO compare la sezione **Esporta CSV ufficiale Packlink PRO**. Il file scaricato si chiama `packlink_pro_import.csv` ed è pronto per la funzione Packlink PRO **Importa un file CSV**.
