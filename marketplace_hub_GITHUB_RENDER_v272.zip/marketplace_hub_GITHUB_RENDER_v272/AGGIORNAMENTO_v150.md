# Marketplace Hub v150

## Invio diretto dell'aggiornamento spedizione

Nella pagina **Tracciabilità ordini** non è più necessario digitare `SPEDISCI`.
Dopo avere selezionato uno o più ordini validi è sufficiente premere il pulsante:

**Invia aggiornamento spedizione**

Il pulsante esegue direttamente il flusso API previsto dal marketplace:

- **Worten/Mirakl:** invia tracking e corriere tramite OR23 e, in caso di esito positivo, conferma la spedizione tramite OR24;
- **Kaufland:** invia tracking e codice corriere sulle order unit selezionate e le contrassegna come spedite.

## Correzione della rivalidazione Worten

Una riga già verificata come inviabile non viene più bloccata perché nella tabella è mostrata l'etichetta tradotta `Spedita · tracking disponibile`.
Prima dell'invio restano comunque obbligatori:

- ordine Worten nello stato `SHIPPING`;
- un solo numero di tracking;
- tracking valorizzato;
- corriere valorizzato.

Il caso `1106522536-A`, tracking `04308I811234`, corriere `MRW`, viene quindi inviato correttamente.

## Corrieri

Il payload OR23 conserva il corriere corretto proveniente dal file. I principali alias vengono normalizzati, per esempio:

- `GLS NACIONAL` e `GLS ITALIA` → `GLS`;
- `DHL PAKET` → `DHL`;
- `DPD FRANCE` → `DPD`;
- `DSV_ITALIA` → `DSV`.

Per i corrieri non riconosciuti come standard, il programma invia il nome originale senza inventare un codice errato.

## Esito visibile

La tabella finale riporta esplicitamente:

- ordine;
- tracking inviato;
- corriere inviato;
- esito dell'aggiornamento tracking;
- esito della conferma della spedizione;
- messaggio restituito dall'API.
