# Marketplace Hub v237 — struttura completa

- `pages/`: 23 file
- `services/`: 45 file
- `tests/`: 73 file
- `tools/`: 12 file
- `_release_payload/`: 6 file

Release completa con avvio unico `AVVIA_WINDOWS.bat` e auto-riparazione dei file Packlink critici.
