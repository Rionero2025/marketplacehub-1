@echo off
setlocal
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set "OUT=logs\diagnostica_runtime.txt"
(
  echo MARKETPLACE HUB - DIAGNOSTICA
  echo Data: %date% %time%
  echo Cartella: %CD%
  echo.
  echo ===== PYTHON SISTEMA =====
  where python 2^>nul
  python --version 2^>nul
  where py 2^>nul
  py -0p 2^>nul
  echo.
  echo ===== VENV =====
  if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" --version
  if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" -m pip --version
  if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" -m pip check
  echo.
  echo ===== TESSERACT =====
  where tesseract 2^>nul
  tesseract --version 2^>nul
  tesseract --list-langs 2^>nul
  echo.
  echo ===== DATABASE CONFIG =====
  if exist "data\database.toml" type "data\database.toml"
  echo.
  echo ===== FILE PRINCIPALI =====
  dir /b app.py launcher.py requirements.txt requirements-installer.txt 2^>nul
) > "%OUT%" 2>&1
if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" tools\verify_runtime.py >> "%OUT%" 2>&1
echo Diagnostica creata: %CD%\%OUT%
start notepad "%OUT%"
pause
