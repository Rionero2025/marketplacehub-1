# Marketplace Hub v268 — Contabilità: selettore Seller stabile durante la verifica

## Correzione

È stato corretto il comportamento della pagina **Contabilità** quando si arriva dalla funzione **Prodotti più venduti → ordini da verificare**.

Prima, la coda di verifica reimpostava ad ogni rerun di Streamlit il Seller collegato all'ordine da controllare. Per questo, scegliendo manualmente un altro Seller dal menu a tendina, la pagina faceva refresh e tornava immediatamente al Seller iniziale.

Dalla v268:

- Seller, Marketplace e Account vengono posizionati automaticamente **una sola volta** quando si entra in un gruppo della coda di verifica;
- dopo il primo posizionamento, i menu a tendina restano liberi e una scelta manuale del Seller non viene più sovrascritta al refresh;
- i pulsanti **Account precedente** e **Account successivo** continuano a spostare correttamente la verifica sul gruppo successivo, riallineando Seller/Marketplace/Account solo in quel momento;
- la coda di verifica resta disponibile in sessione e può essere chiusa con **Chiudi verifica**;
- nessuna modifica al database o ai dati contabili esistenti.

## Compatibilità

- Dashboard v267 preservata;
- Prodotti più venduti v265-v267 preservati;
- Contabilità e modifica inline v259/v266 preservate;
- SQLite e PostgreSQL invariati.

## Correzione pacchetto di avvio

È stato inoltre corretto il payload auto-riparante della v268:

- `_release_payload/VERSION.txt` è ora allineato a `VERSION.txt` = **268**;
- il launcher verifica la versione del payload **prima** di copiare qualsiasi file;
- se payload e release non coincidono, l'avvio viene bloccato senza modificare l'installazione;
- il release gate controlla esplicitamente anche l'allineamento di `VERSION.txt` tra root e `_release_payload`.

Questo elimina il caso in cui l'auto-riparazione riportava `VERSION.txt` a 266 mentre Catalog Intelligence era già 268.
