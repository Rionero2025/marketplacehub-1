# Marketplace Hub v182

## Correzione generazione IA Ticket

- Parsing JSON robusto per Responses API, Chat Completions, content array, output multipli, JSON annidato e risposte racchiuse in Markdown.
- Supporto ai campi `parsed`, `output_parsed`, `message.parsed` e argomenti delle tool call.
- I modelli GPT-5/o-series usano reasoning minimo per evitare che il budget venga consumato prima della risposta.
- Se la Responses API termina per `max_output_tokens`, il programma riprova una volta con un budget maggiore.
- Se un provider ignora comunque Structured Outputs, Marketplace Hub richiede una bozza testuale e la inserisce nell'editor invece di mostrare un errore.
- La bozza testuale di emergenza richiede sempre controllo umano e non può essere inviata automaticamente.
- Conservazione del dettaglio tecnico dell'errore strutturato nello storico interno.
