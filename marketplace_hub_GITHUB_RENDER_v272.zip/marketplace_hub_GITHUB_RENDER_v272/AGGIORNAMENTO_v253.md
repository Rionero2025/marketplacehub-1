# Marketplace Hub v253 — Packlink: invio massivo, telefono fallback e CSV sempre operativo

## Obiettivo
La v253 corregge due problemi operativi della pagina **Packlink PRO** senza modificare il flusso degli ordini, dei listini o degli altri marketplace.

## 1. Invio massivo dopo scelta manuale delle tariffe
Le schede ordine Packlink sono frammenti Streamlit indipendenti per mantenere la pagina veloce. In precedenza, dopo avere scelto manualmente le tariffe nelle singole schede, il candidato risultava correttamente salvato in `st.session_state`, ma il riepilogo massivo poteva rimanere visivamente fermo al rerun precedente e lasciare il pulsante disabilitato.

La v253 modifica il comportamento:
- il pulsante **Crea massivamente tutte le spedizioni Packlink pronte per pagamento** resta cliccabile quando esistono ordini selezionati;
- al click il frammento massivo rilegge lo stato aggiornato di tutte le schede;
- vengono elaborati soltanto gli ordini che hanno realmente una tariffa/servizio selezionato;
- se nessun ordine è pronto viene mostrato un avviso e non viene creata alcuna spedizione vuota.

## 2. Telefono cliente mancante
Non tutti i marketplace obbligano il cliente a lasciare un numero di telefono, mentre Packlink richiede il telefono per una spedizione pronta al pagamento.

Nuova regola v253:
- se il cliente ha un telefono, viene usato il suo numero;
- se il telefono cliente manca realmente, Marketplace Hub usa automaticamente **il telefono del mittente**;
- il fallback viene applicato sia al payload API Packlink sia al CSV ufficiale;
- il telefono del cliente, quando presente, non viene mai sovrascritto;
- se il warehouse Packlink non restituisce i campi di contatto, il programma conserva telefono/email del mittente salvato localmente mantenendo comunque indirizzo e ID ufficiali del warehouse.

## 3. CSV Packlink indipendente dalla creazione API
Il CSV ufficiale Packlink continua a essere generato direttamente dagli ordini selezionati, dal mittente e dai pacchi configurati. Non dipende dall'esito della creazione bozza via API.

In particolare:
- un errore nella creazione della bozza API non impedisce il download del CSV;
- il telefono destinatario mancante viene compilato con il numero mittente;
- il report UI indica quanti ordini hanno usato questo fallback;
- restano preservate le 30 colonne ufficiali, il separatore `;`, UTF-8 BOM, CAP nazionali e zeri iniziali.

## Compatibilità
- baseline v243 e tutte le evoluzioni v244-v252 preservate;
- SQLite/PostgreSQL invariati;
- Seller, ordini, storico, configurazioni, tariffe, credenziali e `.streamlit/secrets.toml` non vengono cancellati;
- auto-riparazione del codice applicativo mantenuta;
- anti-downgrade mantenuto;
- distribuzione sempre come `marketplace_hub.zip` con avvio tramite `AVVIA_WINDOWS.bat`.
