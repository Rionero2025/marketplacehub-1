# Marketplace Hub v238 — avvio senza reinstallazione runtime

- `AVVIA_WINDOWS.bat` riutilizza il Python/Streamlit già presenti sul PC.
- `.venv` non è più obbligatoria per l’avvio: viene usata solo se esiste già.
- L’installer runtime parte esclusivamente quando non esiste alcun Python utilizzabile con Streamlit.
- `launcher.py` non esegue più `pip install -r requirements.txt` solo perché manca lo stamp `.runtime` in una cartella appena estratta.
- Restano invariate tutte le correzioni Packlink v237/v235, inclusi menu Packlink PRO e risoluzione Paese + Città/codice postale.
- Nessun dato utente viene cancellato o reinizializzato.
