@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - Aggiorna librerie
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv assente: avvio installazione completa.
  call "%~dp0INSTALLA_TUTTO_WINDOWS.bat"
  exit /b %errorlevel%
)
".venv\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :errore
".venv\Scripts\python.exe" -m pip install --upgrade --prefer-binary -r requirements-installer.txt
if errorlevel 1 goto :errore
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto :errore
".venv\Scripts\python.exe" tools\verify_runtime.py
if errorlevel 1 goto :errore
echo.
echo Librerie aggiornate e verificate.
pause
exit /b 0
:errore
echo.
echo Aggiornamento non completato. Usa RIPARA_INSTALLAZIONE_WINDOWS.bat
pause
exit /b 1
