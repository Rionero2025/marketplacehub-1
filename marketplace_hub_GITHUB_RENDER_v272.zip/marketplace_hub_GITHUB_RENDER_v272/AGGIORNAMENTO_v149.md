# Marketplace Hub v149

## Correzione invio tracking Worten

La validazione API non usa più il testo descrittivo mostrato nella tabella come
se fosse lo stato originale del file. I valori grezzi hanno priorità:

- `SENT TO WAREHOUSE` + tracking + corriere + Worten `SHIPPING` è inviabile;
- il label `Spedita · tracking disponibile` è riconosciuto comunque come pronto;
- label come `RECEIVED · già spedito` vengono ricondotti a `RECEIVED` e non sono
  reinviati;
- l'ordine 1106522536-A con tracking 04308I811234 e corriere MRW supera la
  validazione locale e procede alle chiamate API OR23/OR24.
