# Marketplace Hub v248 — classificazione ufficiale Kaufland senza blocchi impropri

## Problema corretto

Nella pagina **Creazione Prodotti → Determina categorie**, i prodotti nuovi potevano essere classificati esclusivamente tramite similarità lessicale sulla tassonomia locale. Quando il titolo del listino conteneva soprattutto SKU o codice modello, il punteggio risultava molto basso e tutti gli articoli venivano marcati `BLOCKED`, anche se il feed conteneva descrizione, marca, famiglia fornitore, specifiche e immagini sufficienti per chiedere a Kaufland la categoria corretta.

La bassa confidenza nella categoria non è un errore tecnico del prodotto e non deve impedire la lavorazione.

## Contratto ufficiale Kaufland adottato

Per i prodotti Kaufland la v248 utilizza automaticamente:

```text
POST /categories/decide/
```

Il corpo della richiesta viene costruito con i dati reali del feed:

- titolo commerciale;
- descrizione completa;
- marca/produttore;
- categoria o famiglia del fornitore;
- specifiche tecniche;
- campi sorgente disponibili;
- riferimenti ricavabili dai nomi delle immagini;
- prezzo in centesimi quando disponibile.

Kaufland restituisce fino a cinque categorie ordinate dalla più probabile. Il primo risultato viene accettato automaticamente soltanto quando corrisponde a una categoria foglia presente nello snapshot ufficiale già salvato nel database.

## Nuova regola di stato

La classificazione categoria non produce più `BLOCKED` per scarsa confidenza.

- primo suggerimento ufficiale Kaufland + categoria foglia nello snapshot: `AUTO_APPROVED`;
- mapping già approvato nella Knowledge Base: `AUTO_APPROVED`;
- suggerimento ufficiale non ancora presente nello snapshot: `REVIEW`;
- sola similarità locale debole: `REVIEW`;
- nessuna categoria candidata: `REVIEW` con selezione manuale richiesta.

`BLOCKED` resta riservato alla fase successiva di validazione deterministica del feed, per problemi reali come un attributo obbligatorio assente o un valore tecnicamente non valido.

## Feed completo anche quando il titolo è uno SKU

Se il campo titolo è uguale allo SKU o al modello, Marketplace Hub cerca nel feed sorgente un vero nome prodotto attraverso gli alias internazionali più comuni (`name`, `product_name`, `designation`, `bezeichnung`, `nazwa`, ecc.). Se non esiste un campo titolo migliore, compone una descrizione identificativa esclusivamente con dati realmente presenti nel feed, senza inventare caratteristiche.

## Tassonomia cached-first

La tassonomia ufficiale continua a essere letta dal database. La classificazione non riscarica categorie e attributi a ogni prodotto o a ogni apertura. La chiamata `/categories/decide/` serve soltanto a determinare la categoria più probabile per il prodotto corrente.

## Compatibilità con dati già elaborati

All'avvio della v248, le vecchie assegnazioni categoria v245-v247 con stato `BLOCKED` vengono convertite in `REVIEW`. Seller, account, prodotti, tassonomie, candidati e job restano memorizzati. È quindi sufficiente eseguire nuovamente **Determina categorie dal feed completo**.

## Resilienza

- la richiesta prova prima lo storefront selezionato;
- in caso di HTTP 400 di validazione viene eseguito un solo retry senza parametri opzionali, coerente con l'esempio base della documentazione;
- un problema temporaneo di credenziali o rete non trasforma tutti i prodotti in bloccati;
- i candidati locali restano disponibili per la revisione manuale;
- la categoria restituita dall'API viene sempre verificata contro lo snapshot locale ufficiale.

## Prevenzione della regressione

La release viene rifiutata se:

- Kaufland non abilita automaticamente `/categories/decide/`;
- il client non contiene la chiamata ufficiale;
- una bassa confidenza categoria torna a produrre `BLOCKED`;
- manca la migrazione delle vecchie assegnazioni;
- pagina, workflow, client e classifier non sono allineati;
- la copia auto-riparante differisce dal codice live.

## Dati e funzioni preservati

Restano integralmente preservati la pietra miliare v243, Catalog Intelligence v244-v247, pubblicazione prodotto/offerta, tassonomie persistenti, Packlink, Buy Box, cancellazione, ordini, tracking, contabilità, storico, SQLite/PostgreSQL e avvio unico tramite `AVVIA_WINDOWS.bat`.
