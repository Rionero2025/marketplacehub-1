# Marketplace Hub v206 — Integrazione Packlink PRO per Seller

## Obiettivo
La versione v206 aggiunge Packlink PRO come servizio logistico configurabile separatamente per ogni Seller.

## Attivazione per Seller
Aprire **Gestione Seller → Servizi e integrazioni** e selezionare il Seller.

Per Packlink PRO:
1. incollare la **API key Packlink PRO**;
2. premere **Verifica e attiva Packlink PRO**;
3. Marketplace Hub esegue un controllo reale della chiave contro Packlink prima di salvarla come attiva;
4. solo se il controllo riesce la chiave viene cifrata e memorizzata;
5. l'integrazione può essere disattivata, riattivata o rimossa senza eliminare lo storico spedizioni.

La chiave viene salvata cifrata con lo stesso sistema già utilizzato per le credenziali marketplace.

## Nuova pagina Packlink PRO
È stata aggiunta la voce **Packlink PRO** nella barra laterale.

La pagina consente di:
- verificare nuovamente la connessione;
- sincronizzare le spedizioni restituite dalla API Packlink;
- mantenere una cache locale/PostgreSQL dello storico scaricato;
- selezionare uno o più account Kaufland/Worten dello stesso Seller;
- aggiornare facoltativamente la cache degli ordini marketplace;
- abbinare le spedizioni agli ordini;
- filtrare e controllare gli abbinamenti;
- correggere manualmente i casi ambigui/non abbinati;
- esportare il risultato in CSV.

## Logica di matching
Il match dà priorità a:
1. riferimento ordine Packlink = numero ordine marketplace;
2. nome cliente normalizzato;
3. email e telefono, quando disponibili;
4. compatibilità temporale e ulteriori segnali già usati dal motore di Tracciabilità.

Gli ordini vengono confrontati solo all'interno degli account marketplace appartenenti allo stesso Seller.

Per velocizzare cataloghi molto grandi, gli ordini vengono indicizzati prima per numero ordine e cliente: il motore dettagliato viene eseguito solo sui candidati plausibili e non su ogni combinazione spedizione × ordine.

## Collegamento con Tracciabilità ordini
Nella pagina **Tracciabilità ordini**, quando Packlink PRO è attivo per il Seller e sono presenti spedizioni già abbinate all'account selezionato, compare il pulsante **Usa abbinamenti Packlink**.

Il tracking e il corriere vengono caricati direttamente nel flusso operativo già esistente. In questo modo non è necessario caricare manualmente il file spedizioni quando i dati sono già disponibili da Packlink.

## Database
La v206 crea automaticamente, sul motore database attivo (SQLite o PostgreSQL), le tabelle:
- `seller_integrations`
- `packlink_shipments`
- `packlink_matches`
- `packlink_sync_runs`

Non sono necessarie modifiche manuali al database.

## Nota sulla sincronizzazione delle spedizioni
La documentazione pubblica Packlink e il core ufficiale open-source confermano l'autenticazione tramite API key, il controllo cliente, i dettagli della singola spedizione, il riferimento ordine, il tracking e i webhook. La disponibilità della **collection completa delle spedizioni** deve essere verificata con la specifica API key Packlink PRO del Seller: la v206 prova la collection `v1/shipments`, gestisce più forme di paginazione e, se l'account/API non la espone, mostra l'errore HTTP esatto senza cancellare credenziali o storico.

Questa scelta evita di simulare dati o di considerare riuscita una sincronizzazione che Packlink non ha effettivamente autorizzato.

## Webhook
Marketplace Hub è ancora locale, quindi non può ricevere in modo affidabile callback Internet da Packlink. In v206 la sincronizzazione è quindi manuale/polling.

Quando Marketplace Hub sarà pubblicato online, la struttura dati è già predisposta per aggiungere un endpoint webhook Packlink e aggiornare automaticamente stato/tracking delle spedizioni.

## Compatibilità
- SQLite: sì
- PostgreSQL v205: sì
- Kaufland: sì
- Worten: sì
- dati/credenziali esistenti: non vengono cancellati

## Test
La release è stata verificata con:
- compilazione completa Python;
- test specifici Packlink;
- suite completa Marketplace Hub: **393 test superati + 6 subtest**.

La chiamata reale con l'API key Packlink PRO del Seller deve essere eseguita sul PC dell'utente perché la chiave non è inclusa nel progetto.
