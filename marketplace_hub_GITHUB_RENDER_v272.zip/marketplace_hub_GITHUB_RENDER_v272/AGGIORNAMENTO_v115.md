# Aggiornamento v115 — correzione `database is locked`

## Problema

Il controllo Buy Box Worten salvava ogni singola offerta tramite una nuova
transazione SQLite. Con molti risultati o un altro rerun Streamlit in corso,
una transazione poteva trovare il database temporaneamente occupato e
interrompere il controllo con:

`Controllo Buy Box Worten non riuscito: database is locked`

## Correzione database

- SQLite utilizza la modalità WAL, che consente letture mentre è in corso una
  scrittura.
- Ogni connessione attende fino a 30 secondi quando il database è
  temporaneamente occupato.
- Letture e scritture ritentano automaticamente soltanto gli errori transitori
  `locked` o `busy`.
- Gli altri errori SQL non vengono nascosti e continuano a essere segnalati.

## Correzione Buy Box Worten

- I risultati vengono salvati in blocchi da massimo 100 offerte.
- Ogni blocco usa una sola transazione anziché una transazione per riga.
- I blocchi già completati restano salvati anche durante controlli molto
  lunghi.
- Tutte le funzioni v114 restano invariate.

## Verifica

Compilazione completata e 159 test automatici superati, incluso un test reale
di scrittura multipla su database SQLite in modalità WAL.
