@echo off
cd /d "%~dp0"
python tools\verify_package_v247.py
pause
