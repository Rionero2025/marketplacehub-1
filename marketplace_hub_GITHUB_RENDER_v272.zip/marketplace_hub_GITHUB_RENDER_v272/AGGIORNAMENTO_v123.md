# Aggiornamento v123 — Confronto e integrazione contabile da Excel

- Aggiunta nella pagina **Contabilità** la sezione **Confronta e completa con un file Excel**.
- Supportati file `.xlsx` e `.xls`, inclusi il prospetto originale e i file generati dal programma.
- Selezione del foglio Excel quando il file contiene più schede.
- Individuazione automatica della riga di intestazione, anche in presenza di titoli o righe iniziali.
- Abbinamento delle righe secondo questa priorità:
  1. marketplace + numero ordine + EAN esatto;
  2. numero ordine + prodotto;
  3. numero ordine univoco, utile per i vecchi file che contengono SKU alfanumerici invece dell'EAN.
- Il file Excel completa **soltanto i campi mancanti**. I valori validi già ricavati da API o listini non vengono sovrascritti.
- Campi integrabili: data, market, fornitore, numero ordine fornitore, prodotto, EAN, vendita, acquisto, commissione, costo extra, importo da ricevere, tracking/corriere, cliente, scontrino, pagamento, stato, quantità, rimborso e note.
- Vendita, commissione, payout e costo valorizzati dall'Excel restano memorizzati anche dopo un successivo aggiornamento API, finché l'API non restituisce un valore valido.
- Il ricalcolo costi da listini conserva un costo positivo già presente quando nessun listino produce un match, evitando di cancellare il fallback Excel.
- Anteprima separata in quattro schede:
  - dati da integrare;
  - differenze da controllare;
  - righe non abbinate;
  - esito completo per riga.
- Le differenze non vengono applicate: il programma conserva il dato esistente e le evidenzia per il controllo.
- Margine lordo, ricavo netto e percentuale sono confrontati ma vengono sempre ricalcolati dal programma.
- Aggiunto download del **report Excel di confronto**.
- Aggiunto storico permanente delle integrazioni Excel con righe sorgente, abbinate, aggiornate, campi integrati, differenze e non abbinate.
- Aggiunta in tabella la colonna **Fonte dati**.
- Recupero automatico del nome cliente nei vecchi prospetti in cui era stato inserito per errore nella colonna Tracking.
- 199 test automatici e 6 subtest superati.
