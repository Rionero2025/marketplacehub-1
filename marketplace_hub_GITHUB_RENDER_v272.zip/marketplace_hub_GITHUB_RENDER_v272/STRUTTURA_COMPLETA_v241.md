# Marketplace Hub v241 — struttura pacchetto completo

Release gate: `tools/verify_release_consistency.py`.

## Conteggi
- `pages/`: 23 file
- `services/`: 46 file
- `tests/`: 77 file
- `tools/`: 13 file
- `_release_payload/`: 7 file
- File totali prima del manifesto v241: **406**

## Regola di coerenza v241

- Confronto automatico di tutto il codice applicativo a ogni avvio, anche a parità di versione.
- Gate pre-release su import locali, simboli dinamici Packlink/CSV, navigazione e `_release_payload`.
- Se il gate fallisce, la release non è distribuibile.
- `services/packlink_csv.py` non può più restare vecchio rispetto a `pages/4_Packlink_PRO.py`.
