# Marketplace Hub v257 — struttura e garanzie

Release: **257**

## Correzione principale
La Contabilità dispone di una whitelist persistente dei listini autorizzati a determinare il costo di acquisto. Il Seller può selezionare/deselezionare i listini direttamente dalla pagina Contabilità.

## File applicativi modificati
- `services/accounting.py`
- `pages/4_Contabilita.py`
- `services/catalog_intelligence/__init__.py` (allineamento versione release)

## Database
Nuova tabella compatibile con SQLite/PostgreSQL:
- `accounting_catalog_preferences`

La tabella memorizza per Seller e listino se il listino è abilitato al calcolo costi. Nessun dato contabile esistente viene cancellato.

## Test specifici
- `tests/test_accounting_catalog_selection_v257.py`
- test v256 Innpro LIGHT preservati
- test Contabilità e sincronizzazione incrementale preservati

## Contratti preservati
- distribuzione: `marketplace_hub.zip`
- avvio: estrai → `AVVIA_WINDOWS.bat`
- auto-riparazione dal `_release_payload`
- protezione anti-downgrade
- preservazione `data`, database, Seller, ordini, storico e configurazioni
- preservazione credenziali e `.streamlit/secrets.toml`
- riuso `.venv`/Python esistenti quando disponibili
