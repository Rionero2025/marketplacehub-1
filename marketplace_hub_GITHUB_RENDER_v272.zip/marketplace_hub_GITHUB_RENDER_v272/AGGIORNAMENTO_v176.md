# Marketplace Hub v176

## Verifica live e classificazione rigorosa degli stati ordine

Questa versione introduce un controllo centralizzato degli stati ordine letto
in tempo reale dalle API ufficiali di Worten/Mirakl e Kaufland.

### Worten / Mirakl

- `STAGING`, `WAITING_ACCEPTANCE`, `WAITING_DEBIT` e
  `WAITING_DEBIT_PAYMENT`: ordine ancora in attesa e non spedibile.
- `SHIPPING`: ordine accettato e pronto per la spedizione.
- `SHIPPED`: ordine già spedito.
- `TO_COLLECT`: ordine già spedito e disponibile per il ritiro.
- `RECEIVED` e `CLOSED`: ordine già consegnato o concluso.
- `REFUSED`, `CANCELED` e l'alias storico `CANCELLED`: ordine bloccato o
  cancellato.
- Gli stati rimborso vengono letti separatamente e non vengono confusi con lo
  stato logistico dell'ordine.

### Kaufland

- `open`: finestra iniziale di cancellazione; unità non ancora spedibile.
- `need_to_be_sent`: unità pronta per la spedizione.
- `sent` e `sent_and_autopaid`: unità già spedita.
- `received`: unità ricevuta.
- `returned` e `returned_paid`: reso o reso già rimborsato.
- `cancelled`: unità cancellata.

Gli ordini Kaufland con più unità vengono verificati a livello di singola
`id_order_unit`: il programma invia soltanto le unità ancora in
`need_to_be_sent` e salta quelle già spedite o cancellate.

## Creazione ordini Cecotec

Prima di generare il file il programma interroga il marketplace e:

- include soltanto gli ordini realmente pronti (`SHIPPING` per Worten,
  `need_to_be_sent` per Kaufland);
- esclude ordini cancellati, rifiutati, già spediti, ricevuti, chiusi o resi;
- mostra stato API, descrizione, macro-stato e motivo dell'esclusione;
- ripete il controllo immediatamente prima della creazione del file;
- aggiorna lo stato memorizzato senza sovrascrivere cliente, indirizzo o altre
  informazioni dell'ordine.

## Tracciabilità ordini

- Gli stati vengono aggiornati via API prima della visualizzazione.
- Un secondo controllo viene effettuato immediatamente prima dell'invio.
- `SHIPPED` e `TO_COLLECT` Worten sono sempre trattati come già spediti.
- Gli ordini cancellati vengono saltati senza bloccare gli altri selezionati.
- Per Kaufland ogni unità viene ricontrollata subito prima del comando
  `PATCH /order-units/{id_order_unit}/send`.
- Gli stati sconosciuti vengono bloccati per sicurezza e mostrati come tali,
  senza essere interpretati arbitrariamente.

## Macro-stati

I filtri distinguono ora:

- In attesa
- Da spedire
- Spedito
- Ricevuto
- Restituito/Rimborsato
- Cancellato
- Sconosciuto, quando l'API restituisce un codice non previsto
