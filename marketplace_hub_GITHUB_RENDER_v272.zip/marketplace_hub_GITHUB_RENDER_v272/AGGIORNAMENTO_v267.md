# Marketplace Hub v267 — Dashboard: Top 10 prodotti più venduti in fondo alla Home

## Modifiche

- Il riquadro **Top 10 prodotti più venduti** è stato spostato **in fondo alla Home/Dashboard**, sotto i riquadri dei Seller.
- Il riquadro è stato ridisegnato in modo più accattivante con:
  - header evidenziato;
  - highlight del prodotto #1 del periodo;
  - KPI rapidi per unità, fatturato e margine della Top 10;
  - lista prodotti con badge quantità / fatturato / margine;
  - avviso visivo sulle righe con margine parziale da verificare.
- Rimane il pulsante **Apri classifica completa e dettaglio →** che porta alla pagina **Prodotti più venduti** mantenendo il periodo selezionato nella Dashboard.
- Nessuna chiamata API aggiuntiva: il riquadro continua a usare solo la cache contabile locale già impiegata dalla Dashboard.

## Compatibilità

- Nessuna modifica al database.
- Nessuna modifica alle credenziali o ai dati esistenti.

## Verifica

- Compilazione Python della pagina Dashboard: OK.
