# Marketplace Hub v264 — struttura e garanzie

Release: **264**

## File aggiornati
- `pages/0_Dashboard.py` — card cliccabili, apertura/chiusura del dettaglio e tabelle contestuali;
- `services/dashboard.py` — modello di dettaglio basato sulle stesse formule e righe della Dashboard, aggregazione univoca per ordine e filtro righe da verificare;
- `tests/test_dashboard_clickable_v264.py` — test di coerenza card/dettaglio;
- `services/catalog_intelligence/__init__.py` — allineamento versione release;
- `VERSION.txt` — release 264.

## Contratto Dashboard
- le card mantengono il periodo selezionato;
- i Seller inclusi nel dettaglio sono gli stessi del riepilogo;
- gli override manuali della Contabilità vengono applicati prima del calcolo;
- annullati/cancellati/no-stock/rimborsati conservano le stesse regole economiche della Contabilità;
- il dettaglio Ordini conta una sola volta ogni numero ordine per Seller/account/marketplace;
- il dettaglio Righe da verificare corrisponde allo stesso criterio del contatore `missing_profit_rows`;
- quote BEBOL/Seller vengono derivate dalle percentuali configurate per ciascun Seller.

## Regole release preservate
- ZIP finale sempre `marketplace_hub.zip`;
- avvio esclusivamente con `AVVIA_WINDOWS.bat` dopo estrazione;
- `_release_payload` allineato al codice live;
- protezione anti-downgrade;
- database, `data`, Seller, ordini, storico INNPRO, credenziali, configurazioni e `.venv` preservati durante gli aggiornamenti ordinari.
