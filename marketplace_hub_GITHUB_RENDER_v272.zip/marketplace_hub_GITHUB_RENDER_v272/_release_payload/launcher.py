from __future__ import annotations

import hashlib
import importlib.util
import os
import secrets
import stat
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _repair_local_storage_permissions() -> None:
    """Clear read-only flags left by ZIP extraction or folder copies."""
    data_dir = ROOT / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    targets = [
        data_dir,
        data_dir / "marketplace_hub.db",
        data_dir / "marketplace_hub.db-wal",
        data_dir / "marketplace_hub.db-shm",
        data_dir / "marketplace_hub.db-journal",
    ]
    for target in targets:
        if not target.exists():
            continue
        try:
            mode = target.stat().st_mode | stat.S_IRUSR | stat.S_IWUSR
            if target.is_dir():
                mode |= stat.S_IXUSR
            os.chmod(target, mode)
        except OSError:
            pass
    if os.name == "nt":
        try:
            subprocess.run(
                ["attrib", "-R", str(data_dir / "*"), "/S", "/D"],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except OSError:
            pass


_repair_local_storage_permissions()
secret_file = ROOT / ".streamlit" / "secrets.toml"
if not secret_file.exists():
    secret_file.parent.mkdir(parents=True, exist_ok=True)
    secret_file.write_text(
        f'MARKETPLACE_HUB_MASTER_KEY = "{secrets.token_urlsafe(48)}"\n',
        encoding="utf-8",
    )

# Modules used by optional UI sections are checked before Streamlit starts.
# streamlit-quill2 exposes the Python module ``streamlit_quill``.
_REQUIRED_MODULES = (
    "streamlit",
    "pandas",
    "openpyxl",
    "st_aggrid",
    "streamlit_quill",
    "psycopg",
    "psycopg_pool",
)


def _requirements_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _missing_modules() -> list[str]:
    return [name for name in _REQUIRED_MODULES if importlib.util.find_spec(name) is None]


def _verify_release_consistency() -> None:
    """Refuse to start a mixed/incomplete application release.

    AVVIA_MARKETPLACE_HUB.ps1 normally self-heals all application code first.
    This second gate runs before Streamlit and prevents page-level ImportError/
    missing-symbol failures if a filesystem/security tool interrupted the copy.
    """
    verifier = ROOT / "tools" / "verify_release_consistency.py"
    if not verifier.is_file():
        print("ERRORE: controllo coerenza release non presente. Avvio annullato.")
        raise SystemExit(2)
    completed = subprocess.run(
        [sys.executable, str(verifier), "--quiet"],
        cwd=ROOT,
        check=False,
    )
    if completed.returncode != 0:
        print(
            "ERRORE: Marketplace Hub contiene file applicativi non allineati. "
            "AVVIA_WINDOWS.bat deve sincronizzare il pacchetto prima dell'avvio."
        )
        raise SystemExit(completed.returncode or 2)


def _ensure_requirements() -> None:
    requirements_file = ROOT / "requirements.txt"
    if not requirements_file.exists():
        return

    runtime_dir = ROOT / ".runtime"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    stamp_file = runtime_dir / "requirements.sha256"
    current_hash = _requirements_hash(requirements_file)
    previous_hash = stamp_file.read_text(encoding="utf-8").strip() if stamp_file.exists() else ""
    missing = _missing_modules()

    # Se tutti i moduli richiesti sono gia' disponibili, non eseguire pip solo
    # perche' il pacchetto e' stato estratto in una cartella nuova e manca lo
    # stamp locale. In questo modo un aggiornamento dell'app non reinstalla le
    # dipendenze Python ad ogni release.
    if not missing:
        if previous_hash != current_hash:
            stamp_file.write_text(current_hash, encoding="utf-8")
        return

    print("Installazione delle sole dipendenze mancanti Marketplace Hub in corso...")
    if missing:
        print("Moduli mancanti:", ", ".join(missing))
    completed = subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "--upgrade",
            "-r",
            str(requirements_file),
        ],
        cwd=ROOT,
        check=False,
    )
    if completed.returncode != 0:
        print("Impossibile installare tutte le dipendenze. Controlla la connessione Internet.")
        return

    # Do not write a successful stamp if a required module is still unavailable.
    if _missing_modules():
        print("Alcuni moduli risultano ancora mancanti dopo l'installazione.")
        return
    stamp_file.write_text(current_hash, encoding="utf-8")


_verify_release_consistency()
_ensure_requirements()
subprocess.run(
    [sys.executable, "-m", "streamlit", "run", str(ROOT / "app.py")],
    cwd=ROOT,
    check=False,
)
