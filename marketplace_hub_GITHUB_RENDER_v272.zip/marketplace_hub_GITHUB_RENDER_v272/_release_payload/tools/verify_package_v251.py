from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "pages/3_Creazione_Prodotti.py",
    "services/db.py",
    "services/catalog_intelligence/__init__.py",
    "services/catalog_intelligence/schema.py",
    "services/catalog_intelligence/normalization.py",
    "tests/test_sqlite_concurrency_v251.py",
    "tests/test_db_lock_retry.py",
    "tools/verify_release_consistency.py",
    "AGGIORNAMENTO_v251.md",
    "STRUTTURA_COMPLETA_v251.md",
    "VALIDAZIONE_v251.txt",
    "MANIFESTO_SHA256_v251.txt",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 251:
    errors.append(f"VERSION.txt non è 251: {version!r}")

contracts = {
    "services/db.py": (
        "_DB_INITIALIZED_KEYS",
        "_DB_INIT_LOCK",
        "timeout=60.0",
        'PRAGMA busy_timeout=60000',
        "_retry_locked(_init_db_once",
    ),
    "services/catalog_intelligence/schema.py": (
        "CATALOG_SCHEMA_REVISION = 251",
        "_SCHEMA_READY",
        "_SCHEMA_LOCK",
        "_retry_locked(migrate",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 251",
    ),
    "services/catalog_intelligence/normalization.py": (
        "NORMALIZATION_ENGINE_VERSION = 250",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v251 incompleto in {relative}: {marker}")

page = ROOT / "pages/3_Creazione_Prodotti.py"
if page.is_file() and "bootstrap()\nensure_schema()" in page.read_text(encoding="utf-8-sig"):
    errors.append("Creazione Prodotti ripete ensure_schema dopo bootstrap")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools/verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_sqlite_concurrency_v251.py",
        "tests/test_db_lock_retry.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test concorrenza falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v251.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v251 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] bootstrap/schema process-scoped")
print("[OK] WAL + busy timeout + retry lock")
print("[OK] test concorrenza SQLite")
print("[OK] cache normalizzazione v250 preservata")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
