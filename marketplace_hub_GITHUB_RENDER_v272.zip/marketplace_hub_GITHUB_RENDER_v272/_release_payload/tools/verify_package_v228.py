from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=[
    'app.py','launcher.py','VERSION.txt','pages/4_Packlink_PRO.py','services/packlink.py',
    'AGGIORNA_INSTALLAZIONE_ESISTENTE_v228_WINDOWS.bat','AGGIORNA_INSTALLAZIONE_ESISTENTE_v228.ps1',
    'AGGIORNAMENTO_v228.md','LEGGIMI_INSTALLAZIONE_COMPLETA_v228.txt',
    'tests/test_packlink_v228_complete_draft_locations.py','MANIFESTO_SHA256_v228.txt'
]
for rel in required:
    if not (ROOT/rel).exists(): errors.append(f'manca {rel}')
if (ROOT/'VERSION.txt').exists() and (ROOT/'VERSION.txt').read_text(encoding='utf-8').strip()!='228':
    errors.append('VERSION.txt non è 228')
page=(ROOT/'pages/4_Packlink_PRO.py').read_text(encoding='utf-8')
service=(ROOT/'services/packlink.py').read_text(encoding='utf-8')
m=re.search(r'PACKLINK_SERVICE_VERSION\s*=\s*(\d+)', service)
if not m or int(m.group(1))<228: errors.append('services/packlink.py deve essere v228+')
for marker in [
    'def prepare_draft_payload', 'locations/postalzones/destinations',
    'locations/postalcodes', 'postal_zone_id_from', 'postal_zone_id_to',
    'zip_code_id_from', 'zip_code_id_to', 'submitted_payload',
]:
    if marker not in service: errors.append(f'manca logica località v228: {marker}')
for marker in [
    'PACKLINK_REQUIRED_SERVICE_VERSION = 228',
    'client.prepare_draft_payload(draft_payload)',
    'def _restorable_historical_service','def _effective_services','pending_orders = [',
]:
    if marker not in page: errors.append(f'manca logica pagina v228: {marker}')
if 'Calcola / aggiorna tariffe per tutti gli ordini selezionati' in page:
    errors.append('presente ancora ricalcolo indiscriminato tariffe')
if 'Confermo la creazione della spedizione pronta per il pagamento su Packlink PRO' in page:
    errors.append('presente ancora conferma ridondante')
print('Marketplace Hub v228 - verifica pacchetto')
if errors:
    for e in errors: print('[ERRORE]',e)
    sys.exit(1)
print('[OK] struttura completa')
print('[OK] Paese e Città/codice postale risolti con ID Packlink prima del POST')
print('[OK] nessuna bozza viene creata se Packlink non riconosce la località')
print('[OK] memoria tariffa/pacco e rigenerazione v227 preservate')
