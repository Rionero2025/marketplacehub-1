from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    ".streamlit/config.toml",
    "pages/5_Backup_Trasferimento.py",
    "services/data_transfer.py",
    "services/catalog_intelligence/__init__.py",
    "tests/test_data_transfer_v261.py",
    "tests/test_data_transfer_v260.py",
    "tests/test_accounting_live_manual_v259.py",
    "AGGIORNAMENTO_v261.md",
    "STRUTTURA_COMPLETA_v261.md",
    "VALIDAZIONE_v261.txt",
    "MANIFESTO_SHA256_v261.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 261:
    errors.append(f"VERSION.txt non è 261: {version!r}")

contracts = {
    "services/data_transfer.py": (
        "TRANSFER_SERVICE_VERSION = 261",
        "TRANSFER_FORMAT_VERSION = 2",
        "SUPPORTED_FORMAT_VERSIONS = {1, 2}",
        'TRANSFER_MAGIC_V1 = b"MHUBBACKUP\\x01"',
        'TRANSFER_MAGIC = b"MHUBBACKUP\\x02"',
        "AESGCM(key).encrypt",
        "Fernet(key).decrypt",
        "compresslevel=9",
        "_select_transferable_data_files",
        "_sqlite_path_plan",
        "_rewrite_staged_sqlite_paths",
        "_legacy_path_rewrites_from_staged",
        '"excluded_orphan_bytes"',
        '"path_rewrites"',
        "source.backup(destination)",
        'destination.execute("PRAGMA integrity_check")',
        'BACKUP_ROOT = ROOT / "migration_backups"',
        "os.replace(DATA_DIR, old_data_backup)",
    ),
    "pages/5_Backup_Trasferimento.py": (
        'st.title("Backup e trasferimento")',
        '"Prepara backup compatto"',
        '"Dimensione backup"',
        'Compattazione automatica',
        'La v261 accetta anche i backup v260 già creati.',
        '1 GB',
    ),
    ".streamlit/config.toml": (
        "maxUploadSize = 1024",
        "maxMessageSize = 1024",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 261",
    ),
    "services/accounting.py": (
        "def computed_profit_values(",
        "def save_accounting_inline_edits(",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v261 incompleto in {relative}: {marker}")

# The config is not Python, but must still be inside the auto-repair payload.
for relative in (
    ".streamlit/config.toml",
    "pages/5_Backup_Trasferimento.py",
    "services/data_transfer.py",
    "services/catalog_intelligence/__init__.py",
    "tools/verify_package_v261.py",
):
    live = ROOT / relative
    bundled = ROOT / "_release_payload" / relative
    if not bundled.is_file():
        errors.append(f"payload v261 mancante: {relative}")
    elif live.read_bytes() != bundled.read_bytes():
        errors.append(f"payload v261 non allineato: {relative}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_data_transfer_v261.py",
        "tests/test_data_transfer_v260.py",
        "tests/test_accounting_live_manual_v259.py",
        "tests/test_accounting.py",
        "tests/test_profit_sharing.py",
        "tests/test_accounting_catalog_selection_v257.py",
        "tests/test_innpro_accounting_light_v256.py",
        "tests/test_catalog_ai_v258.py",
        "tests/test_packlink_v255_order_cache.py",
        "tests/test_app_navigation_v236.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v261/compatibilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v261.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v261 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] backup compatto: file gestiti solo se referenziati")
print("[OK] AES-256-GCM binario senza overhead Base64 Fernet")
print("[OK] import retrocompatibile backup v260/Fernet")
print("[OK] percorsi locali rilocati sul nuovo PC")
print("[OK] upload locale Streamlit elevato a 1 GB")
print("[OK] snapshot SQLite consistente + integrity_check")
print("[OK] staging + backup automatico destinazione + rollback")
print("[OK] Contabilità v259 preservata")
print("[OK] Catalog Intelligence preservato")
print("[OK] Packlink v255 preservato")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
