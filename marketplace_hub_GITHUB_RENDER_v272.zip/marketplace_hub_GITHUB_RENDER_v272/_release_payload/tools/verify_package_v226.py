from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
required = [
    "app.py", "launcher.py", "requirements.txt", "requirements-installer.txt",
    "AVVIA_WINDOWS.bat", "INSTALLA_TUTTO_WINDOWS.bat", "INSTALLA_MARKETPLACE_HUB.ps1",
    "AGGIORNA_INSTALLAZIONE_ESISTENTE_v226_WINDOWS.bat",
    "AGGIORNA_INSTALLAZIONE_ESISTENTE_v226.ps1",
    "pages/4_Packlink_PRO.py", "services/packlink.py", "services/cecotec_orders.py", "services/db.py",
    "tests/test_packlink_v226_address_hydration.py", "AGGIORNAMENTO_v226.md",
    "LEGGIMI_INSTALLAZIONE_COMPLETA_v226.txt", "VERSION.txt",
]
for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f"manca {rel}")

for rel in ("pages/4_Packlink_PRO.py", "services/packlink.py"):
    path = ROOT / rel
    if path.exists():
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except Exception as exc:
            errors.append(f"{rel} non compilabile: {exc}")

service = (ROOT / "services/packlink.py").read_text(encoding="utf-8") if (ROOT / "services/packlink.py").exists() else ""
page = (ROOT / "pages/4_Packlink_PRO.py").read_text(encoding="utf-8") if (ROOT / "pages/4_Packlink_PRO.py").exists() else ""
version = re.search(r"PACKLINK_SERVICE_VERSION\s*=\s*(\d+)", service)
if not version or int(version.group(1)) != 226:
    errors.append("PACKLINK_SERVICE_VERSION non è 226")
if "PACKLINK_REQUIRED_SERVICE_VERSION = 226" not in page:
    errors.append("pagina Packlink non richiede service v226")
for marker in (
    "def _coalesced_order_address(",
    "shipping_address_lookup",
    "def normalize_sender_address(",
    '"zip_code": clean_text(recovered.get("postal_code"))',
    '"selectedWarehouseId": clean_text(warehouse_id) or None',
):
    if marker not in service:
        errors.append(f"manca logica indirizzi v226: {marker}")
for marker in (
    "Seleziona tutti da rigenerare",
    "RIPRISTINATO AUTOMATICAMENTE",
    "TARIFFA PRECEDENTE",
    "if selected_sender_record is None:",
):
    if marker not in page:
        errors.append(f"manca logica pagina Packlink: {marker}")
if "Confermo la creazione della spedizione pronta per il pagamento su Packlink PRO" in page:
    errors.append("è ricomparsa la conferma ridondante v225")
if (ROOT / "VERSION.txt").exists() and (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip() != "226":
    errors.append("VERSION.txt non è 226")
if list(ROOT.rglob("*.pyc")) or [p for p in ROOT.rglob("__pycache__") if p.is_dir()]:
    errors.append("sono presenti cache Python nel pacchetto")

print("Marketplace Hub v226 - verifica pacchetto")
print("File:", sum(1 for p in ROOT.rglob("*") if p.is_file()))
print("Pagine Python:", len(list((ROOT / "pages").glob("*.py"))))
print("Servizi Python:", len(list((ROOT / "services").glob("*.py"))))
print("Test Python:", len(list((ROOT / "tests").glob("test_*.py"))))
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print("[OK] struttura completa")
print("[OK] pagina/servizio Packlink v226 allineati")
print("[OK] recupero mittente + destinatario completo presente")
print("[OK] memoria tariffe/pacchi e flusso veloce mantenuti")
