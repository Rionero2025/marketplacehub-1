from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/3_Creazione_Prodotti.py",
    "services/catalog_intelligence/__init__.py",
    "services/catalog_intelligence/schema.py",
    "services/catalog_intelligence/category_classifier.py",
    "services/catalog_intelligence/category_schema.py",
    "services/catalog_intelligence/feed.py",
    "services/catalog_intelligence/workflow.py",
    "services/catalog_intelligence/normalization.py",
    "services/catalog_intelligence/repository.py",
    "services/catalog_intelligence/publication.py",
    "services/catalog_intelligence/taxonomy.py",
    "services/catalog_intelligence/validation.py",
    "services/catalog_intelligence/marketplaces/kaufland.py",
    "services/catalog_intelligence/marketplaces/mirakl.py",
    "tests/test_catalog_intelligence_v244.py",
    "tests/test_catalog_intelligence_v245.py",
    "tests/test_catalog_publication_v246.py",
    "tools/verify_release_consistency.py",
    "AGGIORNAMENTO_v246.md",
    "STRUTTURA_COMPLETA_v246.md",
    "VALIDAZIONE_v246.txt",
    "MANIFESTO_SHA256_v246.txt",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 246:
    errors.append(f"VERSION.txt non è 246: {version!r}")

app_text = (ROOT / "app.py").read_text(encoding="utf-8-sig", errors="replace")
if "pages/3_Creazione_Prodotti.py" not in app_text:
    errors.append("Creazione Prodotti non è presente nella navigazione")

page_text = (ROOT / "pages/3_Creazione_Prodotti.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
for marker in (
    "Catalog Intelligence",
    "Sincronizza tassonomia ufficiale",
    "Normalizza e memorizza i prodotti",
    "Determina categorie dal feed completo",
    "Prepara feed prodotti completi",
    "Pubblicazione reale controllata",
    "Abilita la scrittura reale per questo ciclo",
    "Controlla duplicati e pianifica",
    "Simula il job",
    "Esegui un ciclo",
):
    if marker not in page_text:
        errors.append(f"pagina Creazione Prodotti incompleta: {marker}")

publication_text = (ROOT / "services/catalog_intelligence/publication.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
for marker in (
    "def plan_publication_job(",
    "def simulate_publication_job(",
    "def submit_products(",
    "def refresh_products(",
    "def submit_offers(",
    "def refresh_offers(",
    "def run_publication_cycle(",
    "def retry_failed_items(",
    "remote_write_enabled",
    "CREATE_PRODUCT",
    "CREATE_OFFER",
):
    if marker not in publication_text:
        errors.append(f"motore pubblicazione incompleto: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        path for path in (ROOT / folder).rglob("*.py") if "__pycache__" not in path.parts
    )
for path in python_files:
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

completed = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
)
if completed.returncode != 0:
    errors.append("gate release fallito: " + (completed.stderr or completed.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v246.txt"
if manifest.is_file():
    for raw_line in manifest.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    path
    for path in ROOT.rglob("*")
    if "__pycache__" in path.parts or path.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti nel pacchetto: {len(cache_files)}")

print("Marketplace Hub v246 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] release consistency gate")
print("[OK] controllo anti-duplicato e pianificazione idempotente")
print("[OK] pubblicazione prodotto prima dell'offerta")
print("[OK] Kaufland product data/unit e Mirakl import/report")
print("[OK] simulazione senza scritture e sblocco reale esplicito")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
