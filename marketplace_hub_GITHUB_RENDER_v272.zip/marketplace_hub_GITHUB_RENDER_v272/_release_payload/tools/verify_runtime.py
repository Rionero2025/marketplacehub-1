from __future__ import annotations

import compileall
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

MODULES = {
    "streamlit": "streamlit",
    "pandas": "pandas",
    "openpyxl": "openpyxl",
    "lxml": "lxml",
    "cryptography": "cryptography",
    "requests": "requests",
    "XlsxWriter": "xlsxwriter",
    "xlwt": "xlwt",
    "xlrd": "xlrd",
    "streamlit-aggrid": "st_aggrid",
    "Pillow": "PIL",
    "pytesseract": "pytesseract",
    "PyMuPDF": "fitz",
    "pypdf": "pypdf",
    "openai": "openai",
    "streamlit-quill2": "streamlit_quill",
    "boto3": "boto3",
    "truststore": "truststore",
    "reportlab": "reportlab",
    "psycopg": "psycopg",
    "psycopg_pool": "psycopg_pool",
    "pytest": "pytest",
}


def ok(message: str) -> None:
    print(f"[OK] {message}")


def warn(message: str) -> None:
    print(f"[AVVISO] {message}")


def fail(message: str) -> None:
    print(f"[ERRORE] {message}")


def main() -> int:
    failures: list[str] = []
    print("=" * 72)
    print("MARKETPLACE HUB - VERIFICA RUNTIME v222")
    print("=" * 72)
    print("Python:", sys.version.replace("\n", " "))
    print("Eseguibile:", sys.executable)
    print("Cartella progetto:", ROOT)

    if sys.version_info[:2] != (3, 13):
        failures.append("Marketplace Hub v222 richiede il runtime Python 3.13 dedicato.")
    else:
        ok("Python 3.13 rilevato")

    for package, module in MODULES.items():
        try:
            imported = importlib.import_module(module)
            version = getattr(imported, "__version__", "") or getattr(imported, "VERSION", "")
            ok(f"{package} importabile" + (f" · {version}" if version else ""))
        except Exception as exc:
            failures.append(f"{package} / {module}: {exc}")
            fail(f"{package}: {exc}")

    data_dir = ROOT / "data"
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(prefix="mh_probe_", dir=data_dir, delete=False) as handle:
            probe = Path(handle.name)
            handle.write(b"ok")
        probe.unlink(missing_ok=True)
        ok("Cartella data scrivibile")
    except Exception as exc:
        failures.append(f"Cartella data non scrivibile: {exc}")
        fail(f"Cartella data non scrivibile: {exc}")

    try:
        from services.db import database_storage_status

        status = database_storage_status()
        if status.get("ok"):
            ok(f"Database {status.get('engine', '?')} raggiungibile e scrivibile")
        else:
            failures.append(f"Database non operativo: {status}")
            fail(f"Database non operativo: {status}")
    except Exception as exc:
        failures.append(f"Verifica database: {exc}")
        fail(f"Verifica database: {exc}")

    tesseract = shutil.which("tesseract")
    if not tesseract:
        for candidate in (
            Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"),
            Path(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"),
        ):
            if candidate.exists():
                tesseract = str(candidate)
                break
    if tesseract:
        try:
            completed = subprocess.run(
                [tesseract, "--version"], capture_output=True, text=True, timeout=20, check=False
            )
            first = (completed.stdout or completed.stderr or "").splitlines()[0]
            ok(f"Tesseract OCR rilevato: {first}")
            lang = subprocess.run(
                [tesseract, "--list-langs"], capture_output=True, text=True, timeout=20, check=False
            )
            langs = {line.strip().lower() for line in (lang.stdout or "").splitlines()[1:] if line.strip()}
            if "eng" not in langs:
                failures.append("Tesseract non dispone del language pack eng.")
            else:
                ok("Tesseract language pack ENG presente")
            for optional in ("ita", "por"):
                if optional in langs:
                    ok(f"Tesseract language pack {optional.upper()} presente")
                else:
                    warn(f"Tesseract language pack {optional.upper()} non presente; OCR userà ENG come fallback")
        except Exception as exc:
            failures.append(f"Tesseract non verificabile: {exc}")
            fail(f"Tesseract non verificabile: {exc}")
    else:
        failures.append("Tesseract OCR non trovato: screenshot/PDF scansiti non saranno leggibili.")
        fail("Tesseract OCR non trovato")

    if not compileall.compile_dir(ROOT / "services", quiet=1, force=False):
        failures.append("Compilazione cartella services non riuscita.")
    else:
        ok("Compilazione services")
    if not compileall.compile_dir(ROOT / "pages", quiet=1, force=False):
        failures.append("Compilazione cartella pages non riuscita.")
    else:
        ok("Compilazione pages")

    report = {
        "python": sys.version,
        "executable": sys.executable,
        "root": str(ROOT),
        "failures": failures,
    }
    runtime = ROOT / ".runtime"
    runtime.mkdir(exist_ok=True)
    (runtime / "verifica_runtime_v222.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    if failures:
        print("\nVERIFICA NON SUPERATA:")
        for item in failures:
            print(" -", item)
        return 1
    print("\nVERIFICA COMPLETATA: runtime Marketplace Hub operativo.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
