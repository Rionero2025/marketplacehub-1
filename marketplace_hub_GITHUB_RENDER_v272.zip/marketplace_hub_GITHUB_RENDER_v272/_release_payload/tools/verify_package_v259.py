from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/4_Contabilita.py",
    "services/accounting.py",
    "services/catalog_intelligence/__init__.py",
    "tests/test_accounting_live_manual_v259.py",
    "tests/test_accounting.py",
    "tests/test_profit_sharing.py",
    "tests/test_accounting_catalog_selection_v257.py",
    "tests/test_innpro_accounting_light_v256.py",
    "AGGIORNAMENTO_v259.md",
    "STRUTTURA_COMPLETA_v259.md",
    "VALIDAZIONE_v259.txt",
    "MANIFESTO_SHA256_v259.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 259:
    errors.append(f"VERSION.txt non è 259: {version!r}")

contracts = {
    "services/accounting.py": (
        "def computed_profit_values(",
        '"our_share_eur": split["our_amount"]',
        '"partner_share_eur": split["partner_amount"]',
        "def save_accounting_inline_edits(",
        'accepted["payout_eur"] = round(sale_value - commission_value, 2)',
    ),
    "pages/4_Contabilita.py": (
        "def _prepare_accounting_frame(",
        "def _render_accounting_summary(",
        "margin_value_getter = JsCode(",
        "our_share_value_getter = JsCode(",
        "partner_share_value_getter = JsCode(",
        "onCellValueChanged=live_formula_refresh",
        "if inline_saved_rows:",
        "no marketplace API call",
        "records = accounting_rows(seller_id, account_id, marketplace)",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 259",
    ),
    "services/cecotec_orders.py": (
        "ORDER_SERVICE_VERSION = 255",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
        "fallback_phone",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v259 incompleto in {relative}: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_accounting_live_manual_v259.py",
        "tests/test_accounting.py",
        "tests/test_profit_sharing.py",
        "tests/test_accounting_catalog_selection_v257.py",
        "tests/test_innpro_accounting_light_v256.py",
        "tests/test_innpro_accounting.py",
        "tests/test_accounting_pdf.py",
        "tests/test_dashboard.py",
        "tests/test_packlink_v255_order_cache.py",
        "tests/test_catalog_ai_v258.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v259/Contabilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v259.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v259 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] margine live dopo valori manuali")
print("[OK] quote BEBOL/Seller live secondo percentuali anagrafiche")
print("[OK] totali ricalcolati dalla cache locale nella stessa interazione")
print("[OK] persistenza override manuali")
print("[OK] Contabilità v256-v257 preservata")
print("[OK] Catalog Intelligence AI v258 preservato")
print("[OK] Packlink v255 preservato")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
