from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
required = [
    "app.py", "launcher.py", "VERSION.txt",
    "pages/4_Packlink_PRO.py", "services/packlink.py",
    "AGGIORNA_INSTALLAZIONE_ESISTENTE_v230_WINDOWS.bat",
    "AGGIORNA_INSTALLAZIONE_ESISTENTE_v230.ps1",
    "AGGIORNAMENTO_v230.md", "LEGGIMI_INSTALLAZIONE_COMPLETA_v230.txt",
    "tests/test_packlink_v230_fresh_destination.py",
    "MANIFESTO_SHA256_v230.txt",
]
for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f"manca {rel}")
if (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip() != "230":
    errors.append("VERSION.txt non è 230")
page = (ROOT / "pages/4_Packlink_PRO.py").read_text(encoding="utf-8")
service = (ROOT / "services/packlink.py").read_text(encoding="utf-8")
m = re.search(r"PACKLINK_SERVICE_VERSION\s*=\s*(\d+)", service)
if not m or int(m.group(1)) < 230:
    errors.append("services/packlink.py deve essere v230+")
for marker in [
    "def packlink_destination_address",
    "def validate_packlink_destination_against_order",
    "clients/warehouses", "selectedWarehouseId",
]:
    if marker not in service:
        errors.append(f"manca logica service v230: {marker}")
for marker in [
    "PACKLINK_REQUIRED_SERVICE_VERSION = 230",
    "packlink_batch_candidate_v230_",
    "current_order_by_key.get(order_key_now)",
    'draft_payload["to"] = packlink_destination_address(current_order)',
    "validate_packlink_destination_against_order",
    "Destinazione che verrà inviata a Packlink",
]:
    if marker not in page:
        errors.append(f"manca logica pagina v230: {marker}")
if "packlink_batch_candidate_v219_" in page:
    errors.append("presente ancora candidatura batch legacy v219")
manifest = ROOT / "MANIFESTO_SHA256_v230.txt"
if manifest.exists():
    for line in manifest.read_text(encoding="utf-8").splitlines():
        line=line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, rel = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:80]}")
            continue
        target=ROOT/rel
        if not target.is_file():
            errors.append(f"manifesto: manca {rel}")
            continue
        actual=hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower()!=expected.lower():
            errors.append(f"manifesto: hash diverso {rel}")
print("Marketplace Hub v230 - verifica pacchetto")
if errors:
    for err in errors:
        print("[ERRORE]",err)
    sys.exit(1)
print("[OK] struttura completa")
print("[OK] destinatario ricostruito dall'ordine corrente")
print("[OK] controllo pre-POST country/zip/city")
print("[OK] candidature batch legacy escluse")
print("[OK] memoria tariffa/pacco preservata")
