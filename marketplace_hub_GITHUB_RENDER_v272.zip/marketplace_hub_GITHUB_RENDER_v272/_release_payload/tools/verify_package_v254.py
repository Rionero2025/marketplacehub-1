from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/4_Packlink_PRO.py",
    "services/packlink.py",
    "services/packlink_csv.py",
    "services/catalog_intelligence/__init__.py",
    "tests/test_packlink_v253.py",
    "tests/test_startup_stale_cleanup_v254.py",
    "AGGIORNAMENTO_v254.md",
    "STRUTTURA_COMPLETA_v254.md",
    "VALIDAZIONE_v254.txt",
    "MANIFESTO_SHA256_v254.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 254:
    errors.append(f"VERSION.txt non è 254: {version!r}")

contracts = {
    "AVVIA_MARKETPLACE_HUB.ps1": (
        "function Get-LivePythonApplicationFiles",
        "function Remove-StaleApplicationCode",
        "Remove-StaleApplicationCode $Root $payloadRoot",
        "Rimossi file applicativi obsoleti",
        "services\\accounting_costs.py / services\\marketplace_deletion.py",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 253",
        "fallback_phone",
        '"phone": current_or_recovered("phone") or clean_text(fallback_phone)',
        'order, fallback_phone=origin.get("phone")',
    ),
    "services/packlink_csv.py": (
        "PACKLINK_CSV_VERSION = 253",
        'fallback_phone=sender_normalized.get("phone")',
        '"recipient_phone_fallback"',
    ),
    "pages/4_Packlink_PRO.py": (
        "PACKLINK_REQUIRED_SERVICE_VERSION = 253",
        "PACKLINK_REQUIRED_CSV_VERSION = 253",
        "disabled=not bool(selected_orders)",
        "Telefono cliente assente: verrà usato automaticamente il numero del mittente.",
        "recipient_phone_fallback",
        "packlink_create_batch_v253",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 254",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v254 incompleto in {relative}: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_startup_stale_cleanup_v254.py",
        "tests/test_packlink_v253.py",
        "tests/test_packlink.py",
        "tests/test_packlink_csv_v239.py",
        "tests/test_packlink_postal_formats_v240.py",
        "tests/test_packlink_v225_no_extra_confirmation.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v254/Packlink falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v254.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v254 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] pulizia automatica file Python obsoleti prima del gate")
print("[OK] dati e runtime esclusi dalla pulizia")
print("[OK] correzioni Packlink v253 preservate")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
