from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
required = [
    'app.py', 'launcher.py', 'VERSION.txt',
    'pages/4_Packlink_PRO.py', 'services/packlink.py',
    'AGGIORNA_INSTALLAZIONE_ESISTENTE_v229_WINDOWS.bat',
    'AGGIORNA_INSTALLAZIONE_ESISTENTE_v229.ps1',
    'AGGIORNAMENTO_v229.md', 'LEGGIMI_INSTALLAZIONE_COMPLETA_v229.txt',
    'tests/test_packlink_v229_official_warehouse_draft.py',
    'MANIFESTO_SHA256_v229.txt',
]
for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f'manca {rel}')
if (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip() != '229':
    errors.append('VERSION.txt non è 229')
page = (ROOT / 'pages/4_Packlink_PRO.py').read_text(encoding='utf-8')
service = (ROOT / 'services/packlink.py').read_text(encoding='utf-8')
m = re.search(r'PACKLINK_SERVICE_VERSION\s*=\s*(\d+)', service)
if not m or int(m.group(1)) < 229:
    errors.append('services/packlink.py deve essere v229+')
markers_service = [
    'clients/warehouses', 'selectedWarehouseId',
    'def match_packlink_warehouse_id', 'def normalize_packlink_warehouse',
    'def prepare_draft_payload', 'def last_order_draft_configuration',
]
for marker in markers_service:
    if marker not in service:
        errors.append(f'manca logica service v229: {marker}')
markers_page = [
    'PACKLINK_REQUIRED_SERVICE_VERSION = 229',
    'match_packlink_warehouse_id(selected_sender, warehouses)',
    'selected_sender_for_draft = dict(packlink_warehouse_by_id[selected_sender_origin_id])',
    'sender=selected_sender_for_draft',
    'def _restorable_historical_service', 'pending_orders = [',
]
for marker in markers_page:
    if marker not in page:
        errors.append(f'manca logica pagina v229: {marker}')
if 'client.prepare_draft_payload(draft_payload)' in page:
    errors.append('presente ancora la vecchia risoluzione v228 dei location ids')
if 'Confermo la creazione della spedizione pronta per il pagamento su Packlink PRO' in page:
    errors.append('presente ancora la conferma ridondante')
if 'Calcola / aggiorna tariffe per tutti gli ordini selezionati' in page:
    errors.append('presente ancora il ricalcolo indiscriminato delle tariffe')

# Verify the v229 SHA-256 manifest. The manifest intentionally excludes itself.
manifest = ROOT / 'MANIFESTO_SHA256_v229.txt'
if manifest.exists():
    import hashlib
    for line in manifest.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        try:
            expected, rel = line.split('  ', 1)
        except ValueError:
            errors.append(f'riga manifesto non valida: {line[:80]}')
            continue
        target = ROOT / rel
        if not target.is_file():
            errors.append(f'manifesto: manca {rel}')
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f'manifesto: hash diverso {rel}')

print('Marketplace Hub v229 - verifica pacchetto')
if errors:
    for err in errors:
        print('[ERRORE]', err)
    sys.exit(1)
print('[OK] struttura completa')
print('[OK] warehouse Packlink ufficiale + selectedWarehouseId')
print('[OK] country ISO-2 nel normale Address DTO')
print('[OK] vecchia risoluzione location-id v228 rimossa dal flusso draft')
print('[OK] memoria tariffa/pacco e rigenerazione preservate')
