from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/4_Contabilita.py",
    "services/accounting.py",
    "services/catalog_intelligence/__init__.py",
    "tests/test_innpro_accounting_light_v256.py",
    "tests/test_accounting.py",
    "tests/test_packlink_v255_order_cache.py",
    "AGGIORNAMENTO_v256.md",
    "STRUTTURA_COMPLETA_v256.md",
    "VALIDAZIONE_v256.txt",
    "MANIFESTO_SHA256_v256.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 256:
    errors.append(f"VERSION.txt non è 256: {version!r}")

contracts = {
    "services/accounting.py": (
        "source_url: str = \"\"",
        "def _is_innpro_light_source(",
        "if _is_innpro_supplier(requested_supplier):",
        "prezzo all'ingrosso LIGHT Innpro",
        "il prezzo del FULL non viene usato in Contabilità",
        "strict_innpro_light",
    ),
    "pages/4_Contabilita.py": (
        "Per Innpro la Contabilità usa esclusivamente il prezzo all'ingrosso",
        "listino LIGHT",
        "il suo prezzo non viene usato come costo di acquisto",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 256",
    ),
    "services/cecotec_orders.py": (
        "ORDER_SERVICE_VERSION = 255",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
        "fallback_phone",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v256 incompleto in {relative}: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_innpro_accounting_light_v256.py",
        "tests/test_innpro_accounting.py",
        "tests/test_accounting.py",
        "tests/test_packlink_v255_order_cache.py",
        "tests/test_packlink_v253.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v256/contabilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v256.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v256 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] Innpro Contabilità usa solo LIGHT")
print("[OK] nessun fallback al prezzo FULL Innpro")
print("[OK] modifiche manuali persistenti preservate")
print("[OK] Packlink v255/v253 preservato")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
