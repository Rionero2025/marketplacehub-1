from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "pages/0_Dashboard.py",
    "pages/3_Prodotti_Piu_Venduti.py",
    "pages/4_Contabilita.py",
    "services/product_stats.py",
    "tests/test_product_stats_v265.py",
    "tests/test_product_stats_review_v266.py",
    "tests/test_product_stats_review_ui_v266.py",
    "AGGIORNAMENTO_v266.md",
    "STRUTTURA_COMPLETA_v266.md",
    "VALIDAZIONE_v266.txt",
    "MANIFESTO_SHA256_v266.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 266:
    errors.append(f"VERSION.txt non è 266: {version!r}")

contracts = {
    "pages/0_Dashboard.py": (
        "Top 10 prodotti più venduti",
        "margin_missing_rows",
        "Margine parziale",
    ),
    "pages/3_Prodotti_Piu_Venduti.py": (
        "margin_review_queue(current_rows)",
        'st.session_state["accounting_review_route"]',
        "Ordini da verificare",
        'st.switch_page("pages/4_Contabilita.py")',
    ),
    "pages/4_Contabilita.py": (
        'review_route = st.session_state.get("accounting_review_route")',
        "_accounting_review_groups(",
        "Completa i campi economici mancanti qui sotto",
        'key=f"accounting_review_editor_',
        "save_accounting_inline_edits(review_changes)",
        "Account successivo →",
        "Chiudi verifica",
    ),
    "services/product_stats.py": (
        "def margin_review_queue(",
        "margin_missing_rows",
        "total margin is the sum of every margin already known",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 266",
    ),
    "services/accounting.py": (
        "def computed_profit_values(",
        "def save_accounting_inline_edits(",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v266 incompleto in {relative}: {marker}")

for relative in (
    "VERSION.txt",
    "app.py",
    "pages/0_Dashboard.py",
    "pages/3_Prodotti_Piu_Venduti.py",
    "pages/4_Contabilita.py",
    "services/product_stats.py",
    "services/catalog_intelligence/__init__.py",
    "tools/verify_package_v266.py",
):
    live = ROOT / relative
    bundled = ROOT / "_release_payload" / relative
    if not bundled.is_file():
        errors.append(f"payload v266 mancante: {relative}")
    elif live.read_bytes() != bundled.read_bytes():
        errors.append(f"payload v266 non allineato: {relative}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"
verify_env["PYTHONPATH"] = str(ROOT) + os.pathsep + verify_env.get("PYTHONPATH", "")

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_product_stats_v265.py",
        "tests/test_product_stats_ui_v265.py",
        "tests/test_product_stats_review_v266.py",
        "tests/test_product_stats_review_ui_v266.py",
        "tests/test_dashboard.py",
        "tests/test_dashboard_clickable_v264.py",
        "tests/test_accounting_live_manual_v259.py",
        "tests/test_innpro_orders_v263.py",
        "tests/test_data_transfer_v261.py",
        "tests/test_packlink_v255_order_cache.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v266/compatibilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v266.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != expected:
            errors.append(f"manifesto: hash non valido {relative}")

if errors:
    for error in errors:
        print("ERRORE:", error)
    raise SystemExit(1)
print("Marketplace Hub v266 verificato: OK")
