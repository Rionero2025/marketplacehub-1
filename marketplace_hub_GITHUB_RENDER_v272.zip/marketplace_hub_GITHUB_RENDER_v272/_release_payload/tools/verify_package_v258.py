from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/2_Provider_IA.py",
    "pages/3_Creazione_Prodotti.py",
    "services/ai_providers.py",
    "services/catalog_intelligence/__init__.py",
    "services/catalog_intelligence/ai_enrichment.py",
    "services/catalog_intelligence/feed.py",
    "services/catalog_intelligence/schema.py",
    "services/catalog_intelligence/workflow.py",
    "tests/test_catalog_ai_v258.py",
    "AGGIORNAMENTO_v258.md",
    "STRUTTURA_COMPLETA_v258.md",
    "VALIDAZIONE_v258.txt",
    "MANIFESTO_SHA256_v258.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 258:
    errors.append(f"VERSION.txt non è 258: {version!r}")

contracts = {
    "app.py": (
        'pages/2_Provider_IA.py',
        'title="Provider IA"',
        'pages/3_Creazione_Prodotti.py',
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 258",
    ),
    "services/catalog_intelligence/schema.py": (
        "CATALOG_SCHEMA_REVISION = 258",
        "CREATE TABLE IF NOT EXISTS catalog_ai_runs",
        "CREATE TABLE IF NOT EXISTS catalog_ai_product_results",
        "CREATE TABLE IF NOT EXISTS product_ai_attribute_mappings",
    ),
    "services/catalog_intelligence/ai_enrichment.py": (
        "AI_CATALOG_ENGINE_VERSION = 258",
        "def product_evidence(",
        "def resolve_category_with_ai(",
        "def map_attributes_with_ai(",
        "Il provider ha restituito una categoria fuori dall'elenco ufficiale consentito.",
        '"source_kind": "AI_EVIDENCE"',
    ),
    "services/catalog_intelligence/feed.py": (
        "supplemental_values: Mapping[str, Any] | None = None",
        "supplemental_mapping_records: Mapping[str, Mapping[str, Any]] | None = None",
        '"source_kind"',
    ),
    "services/catalog_intelligence/workflow.py": (
        "def resolve_review_categories_with_ai(",
        '"candidate_policy": "OFFICIAL_CANDIDATES_ONLY"',
        '"policy": "SOURCE_EVIDENCE_REQUIRED"',
        "ai_profile_id: int | None = None",
    ),
    "pages/3_Creazione_Prodotti.py": (
        "AI Catalog Intelligence · risolvi categorie in revisione",
        "Risolvi categorie in revisione con AI vincolata",
        "AI Catalog Intelligence · completa attributi obbligatori mancanti",
        "Esecuzioni AI Catalog Intelligence",
    ),
    "pages/2_Provider_IA.py": (
        "Seller per i provider IA",
        "Catalog Intelligence",
    ),
    "services/cecotec_orders.py": (
        "ORDER_SERVICE_VERSION = 255",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
        "fallback_phone",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v258 incompleto in {relative}: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_catalog_ai_v258.py",
        "tests/test_catalog_intelligence_v244.py",
        "tests/test_catalog_intelligence_v245.py",
        "tests/test_catalog_publication_v246.py",
        "tests/test_kaufland_category_schema_v247.py",
        "tests/test_kaufland_category_decide_v248.py",
        "tests/test_catalog_feed_completeness_v249.py",
        "tests/test_catalog_normalization_v249.py",
        "tests/test_catalog_normalization_v250.py",
        "tests/test_catalog_normalization_v252.py",
        "tests/test_ai_providers.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test Catalog Intelligence AI v258 falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v258.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v258 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] Provider IA disponibile dalla navigazione")
print("[OK] categorie AI vincolate alle candidate ufficiali")
print("[OK] evidence path sorgente obbligatorio")
print("[OK] mapping attributi AI ri-validato deterministicamente")
print("[OK] memoria persistente mapping AI")
print("[OK] Catalog Intelligence v244-v252 preservato")
print("[OK] Packlink v255 e Contabilità v257 preservati")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
