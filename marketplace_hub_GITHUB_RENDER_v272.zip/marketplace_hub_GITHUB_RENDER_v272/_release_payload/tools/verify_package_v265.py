from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/0_Dashboard.py",
    "pages/3_Prodotti_Piu_Venduti.py",
    "services/dashboard.py",
    "services/product_stats.py",
    "tests/test_product_stats_v265.py",
    "tests/test_product_stats_ui_v265.py",
    "tests/test_dashboard.py",
    "tests/test_dashboard_clickable_v264.py",
    "AGGIORNAMENTO_v265.md",
    "STRUTTURA_COMPLETA_v265.md",
    "VALIDAZIONE_v265.txt",
    "MANIFESTO_SHA256_v265.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 265:
    errors.append(f"VERSION.txt non è 265: {version!r}")

contracts = {
    "app.py": (
        'st.Page("pages/3_Prodotti_Piu_Venduti.py", title="Prodotti più venduti", icon="📈")',
    ),
    "pages/0_Dashboard.py": (
        'key="dashboard_top_products"',
        "_dashboard_top_products_label(",
        "aggregate_product_stats(filter_product_rows(selected_detail_rows))",
        'st.switch_page("pages/3_Prodotti_Piu_Venduti.py")',
        'st.session_state["products_stats_period_mode"] = dashboard_period_mode',
    ),
    "pages/3_Prodotti_Piu_Venduti.py": (
        'st.title("Prodotti più venduti")',
        '"Più venduti (quantità)"',
        '"Maggior fatturato"',
        '"Maggior margine"',
        'selection_mode="single-row"',
        'on_select="rerun"',
        '"Per Seller", "Per Marketplace", "Per Paese", "Per Fornitore", "Ordini"',
        "previous_period_range(",
        "download_button(",
    ),
    "services/product_stats.py": (
        "def product_identity(",
        "def is_sold_line(",
        "def aggregate_product_stats(",
        "def merge_previous_period(",
        "def sort_product_stats(",
        "def aggregate_dimension(",
        "def aggregate_product_orders(",
    ),
    "services/dashboard.py": (
        '"country_code": clean_text(item.get("country_code")).upper()',
        '"composite_sku": clean_text(item.get("composite_sku"))',
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 265",
    ),
    "services/accounting.py": (
        "def computed_profit_values(",
        "def save_accounting_inline_edits(",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v265 incompleto in {relative}: {marker}")

for relative in (
    "VERSION.txt",
    "app.py",
    "pages/0_Dashboard.py",
    "pages/3_Prodotti_Piu_Venduti.py",
    "services/dashboard.py",
    "services/product_stats.py",
    "services/catalog_intelligence/__init__.py",
    "tools/verify_package_v265.py",
):
    live = ROOT / relative
    bundled = ROOT / "_release_payload" / relative
    if not bundled.is_file():
        errors.append(f"payload v265 mancante: {relative}")
    elif live.read_bytes() != bundled.read_bytes():
        errors.append(f"payload v265 non allineato: {relative}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"
verify_env["PYTHONPATH"] = str(ROOT) + os.pathsep + verify_env.get("PYTHONPATH", "")

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_product_stats_v265.py",
        "tests/test_product_stats_ui_v265.py",
        "tests/test_dashboard.py",
        "tests/test_dashboard_clickable_v264.py",
        "tests/test_innpro_orders_v263.py",
        "tests/test_accounting_live_manual_v259.py",
        "tests/test_data_transfer_v261.py",
        "tests/test_packlink_v255_order_cache.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v265/compatibilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v265.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != expected:
            errors.append(f"manifesto: hash non valido {relative}")

if errors:
    for error in errors:
        print("ERRORE:", error)
    raise SystemExit(1)
print("Marketplace Hub v265 verificato: OK")
