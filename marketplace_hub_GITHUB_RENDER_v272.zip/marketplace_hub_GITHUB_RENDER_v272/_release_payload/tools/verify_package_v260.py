from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/5_Backup_Trasferimento.py",
    "services/data_transfer.py",
    "services/catalog_intelligence/__init__.py",
    "tests/test_data_transfer_v260.py",
    "tests/test_accounting_live_manual_v259.py",
    "AGGIORNAMENTO_v260.md",
    "STRUTTURA_COMPLETA_v260.md",
    "VALIDAZIONE_v260.txt",
    "MANIFESTO_SHA256_v260.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 260:
    errors.append(f"VERSION.txt non è 260: {version!r}")

contracts = {
    "app.py": (
        'pages/5_Backup_Trasferimento.py',
        'title="Backup e trasferimento"',
    ),
    "services/data_transfer.py": (
        "TRANSFER_SERVICE_VERSION = 260",
        'TRANSFER_FORMAT = "marketplace-hub-transfer"',
        "PBKDF2_ITERATIONS = 600_000",
        "source.backup(destination)",
        'destination.execute("PRAGMA integrity_check")',
        "Fernet(key).encrypt(payload)",
        '"checksums_sha256": checksums',
        'BACKUP_ROOT = ROOT / "migration_backups"',
        "os.replace(DATA_DIR, old_data_backup)",
        "def create_transfer_package(",
        "def inspect_transfer_package(",
        "def restore_transfer_package(",
        "_portable_database_config_bytes",
        '"config/secrets.toml"',
    ),
    "pages/5_Backup_Trasferimento.py": (
        'st.title("Backup e trasferimento")',
        'st.tabs(["Esporta dati", "Importa su questo PC"])',
        '"Prepara backup completo"',
        '"Scarica backup per il nuovo PC"',
        '"Verifica backup"',
        '"Importa dati su questo PC"',
        "migration_backups",
        "AVVIA_WINDOWS.bat",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 260",
    ),
    "services/accounting.py": (
        "def computed_profit_values(",
        "def save_accounting_inline_edits(",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v260 incompleto in {relative}: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_data_transfer_v260.py",
        "tests/test_accounting_live_manual_v259.py",
        "tests/test_accounting.py",
        "tests/test_profit_sharing.py",
        "tests/test_accounting_catalog_selection_v257.py",
        "tests/test_innpro_accounting_light_v256.py",
        "tests/test_catalog_ai_v258.py",
        "tests/test_packlink_v255_order_cache.py",
        "tests/test_app_navigation_v236.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v260/compatibilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v260.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    p for p in ROOT.rglob("*")
    if "__pycache__" in p.parts or p.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti: {len(cache_files)}")

print("Marketplace Hub v260 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] backup cifrato completo .mhubbackup")
print("[OK] snapshot SQLite consistente + integrity_check")
print("[OK] configurazione PostgreSQL attiva trasferibile")
print("[OK] data + secrets/master key trasferiti")
print("[OK] checksum e validazioni anti-manomissione")
print("[OK] staging + backup automatico destinazione + rollback")
print("[OK] blocco import da release più nuova")
print("[OK] Contabilità v259 preservata")
print("[OK] Catalog Intelligence preservato")
print("[OK] Packlink v255 preservato")
print("[OK] release consistency gate")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
