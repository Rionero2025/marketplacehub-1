from __future__ import annotations

"""Fail-fast consistency gate for Marketplace Hub releases.

The script is intentionally static: it does not import Streamlit pages or connect to
marketplaces. It verifies the contracts that have caused mixed-release failures in
past packages and returns a non-zero exit code on the first invalid release.
"""

import argparse
import ast
import hashlib
import re
import sys
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
LOCAL_PREFIXES = ("services", "tools")

REQUIRED_PAYLOAD_FILES = (
    "app.py",
    "launcher.py",
    "pages/4_Packlink_PRO.py",
    "services/cecotec_orders.py",
    "services/packlink.py",
    "services/packlink_csv.py",
    "services/packlink_order_import.py",
)


CATALOG_INTELLIGENCE_CONTRACTS = {
    "services.catalog_intelligence": ("CATALOG_INTELLIGENCE_VERSION", "ensure_schema"),
    "services.catalog_intelligence.accounts": (
        "load_marketplace_account",
        "marketplace_accounts_for_seller",
    ),
    "services.catalog_intelligence.capabilities": ("discover_account_capabilities",),
    "services.catalog_intelligence.category_classifier": (
        "category_decision",
        "kaufland_decide_payload",
        "rank_categories",
        "source_category_signature",
    ),
    "services.catalog_intelligence.category_schema": (
        "cached_category_attributes",
        "ensure_category_attributes",
    ),
    "services.catalog_intelligence.ai_enrichment": (
        "ai_runs",
        "map_attributes_with_ai",
        "resolve_category_with_ai",
        "start_ai_run",
    ),
    "services.catalog_intelligence.feed": (
        "build_kaufland_product_payload",
        "build_mirakl_product_payload",
        "prepare_product_feed",
    ),
    "services.catalog_intelligence.normalization": ("normalize_dataframe", "persist_saved_view"),
    "services.catalog_intelligence.repository": (
        "category_assignments_for_source",
        "create_marketplace_import",
        "create_publication_job",
        "ensure_publication_runtime",
        "feed_preparations_for_source",
        "latest_taxonomy_snapshot",
        "marketplace_imports_for_job",
        "publication_artifacts",
        "publication_events",
        "publication_item",
        "publication_items",
        "record_validation_run",
        "save_taxonomy_bundle",
        "taxonomy_category",
        "update_publication_job_settings",
    ),
    "services.catalog_intelligence.publication": (
        "build_mirakl_offer_csv",
        "build_mirakl_product_csv",
        "plan_publication_job",
        "publication_configuration_options",
        "refresh_offers",
        "refresh_products",
        "retry_failed_items",
        "run_publication_cycle",
        "simulate_publication_job",
        "submit_offers",
        "submit_products",
    ),
    "services.catalog_intelligence.marketplaces.mirakl": (
        "MiraklCatalogClient",
        "MiraklCatalogError",
    ),
    "services.catalog_intelligence.taxonomy": (
        "ensure_account_taxonomy",
        "sync_account_taxonomy",
        "taxonomy_scope_key",
    ),
    "services.catalog_intelligence.validation": ("validate_canonical_product",),
    "services.catalog_intelligence.workflow": (
        "approve_category_assignment",
        "classify_source_products",
        "prepare_assigned_product_feeds",
        "resolve_review_categories_with_ai",
    ),
}


DYNAMIC_CONTRACTS = {
    "_REQUIRED_ORDER_SERVICE_SYMBOLS": "services.cecotec_orders",
    "_REQUIRED_PACKLINK_SERVICE_SYMBOLS": "services.packlink",
    "_REQUIRED_PACKLINK_CSV_SYMBOLS": "services.packlink_csv",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def module_path(module: str) -> Path | None:
    path = ROOT.joinpath(*module.split(".")).with_suffix(".py")
    if path.is_file():
        return path
    package_dir = ROOT.joinpath(*module.split("."))
    init = package_dir / "__init__.py"
    if init.is_file():
        return init
    # Marketplace Hub uses Python namespace packages (services/, tools/) without
    # __init__.py. The directory itself therefore represents a valid module root.
    return package_dir if package_dir.is_dir() else None


def parse(path: Path) -> ast.Module:
    try:
        return ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    except SyntaxError as exc:
        raise RuntimeError(f"Sintassi Python non valida in {path.relative_to(ROOT)}: {exc}") from exc


def assigned_names(target: ast.AST) -> set[str]:
    if isinstance(target, ast.Name):
        return {target.id}
    if isinstance(target, (ast.Tuple, ast.List)):
        out: set[str] = set()
        for item in target.elts:
            out |= assigned_names(item)
        return out
    return set()


def collect_module_symbols(tree: ast.Module) -> set[str]:
    symbols: set[str] = set()

    def visit_statements(statements: Iterable[ast.stmt]) -> None:
        for stmt in statements:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                symbols.add(stmt.name)
                continue
            if isinstance(stmt, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
                for target in targets:
                    symbols.update(assigned_names(target))
                continue
            if isinstance(stmt, ast.Import):
                for alias in stmt.names:
                    symbols.add(alias.asname or alias.name.split(".")[0])
                continue
            if isinstance(stmt, ast.ImportFrom):
                for alias in stmt.names:
                    if alias.name != "*":
                        symbols.add(alias.asname or alias.name)
                continue
            if isinstance(stmt, ast.If):
                visit_statements(stmt.body)
                visit_statements(stmt.orelse)
            elif isinstance(stmt, ast.Try):
                visit_statements(stmt.body)
                visit_statements(stmt.orelse)
                visit_statements(stmt.finalbody)
                for handler in stmt.handlers:
                    visit_statements(handler.body)
            elif isinstance(stmt, (ast.With, ast.AsyncWith, ast.For, ast.AsyncFor, ast.While)):
                visit_statements(stmt.body)
                visit_statements(getattr(stmt, "orelse", []))

    visit_statements(tree.body)
    return symbols


def iter_python_files() -> Iterable[Path]:
    yield ROOT / "app.py"
    yield ROOT / "launcher.py"
    for folder in ("pages", "services", "tools"):
        base = ROOT / folder
        if base.is_dir():
            yield from sorted(p for p in base.rglob("*.py") if "__pycache__" not in p.parts)


def verify_local_imports(errors: list[str]) -> None:
    symbol_cache: dict[str, set[str]] = {}
    for path in iter_python_files():
        if not path.is_file():
            errors.append(f"File Python atteso assente: {path.relative_to(ROOT)}")
            continue
        tree = parse(path)
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                if not node.module.startswith(LOCAL_PREFIXES):
                    continue
                target = module_path(node.module)
                if target is None:
                    errors.append(
                        f"{path.relative_to(ROOT)}:{node.lineno}: modulo locale inesistente {node.module}"
                    )
                    continue
                if any(alias.name == "*" for alias in node.names):
                    continue
                if target.is_dir():
                    # `from services import db` on a namespace package imports a
                    # submodule, not an attribute from __init__.py.
                    for alias in node.names:
                        if module_path(f"{node.module}.{alias.name}") is None:
                            errors.append(
                                f"{path.relative_to(ROOT)}:{node.lineno}: sott modulo locale {node.module}.{alias.name} inesistente"
                            )
                    continue
                symbols = symbol_cache.setdefault(node.module, collect_module_symbols(parse(target)))
                for alias in node.names:
                    if alias.name not in symbols:
                        errors.append(
                            f"{path.relative_to(ROOT)}:{node.lineno}: {node.module}.{alias.name} non esiste"
                        )
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.startswith(LOCAL_PREFIXES) and module_path(alias.name) is None:
                        errors.append(
                            f"{path.relative_to(ROOT)}:{node.lineno}: modulo locale inesistente {alias.name}"
                        )


def literal_string_tuple(node: ast.AST) -> tuple[str, ...] | None:
    if not isinstance(node, (ast.Tuple, ast.List)):
        return None
    values: list[str] = []
    for item in node.elts:
        if not isinstance(item, ast.Constant) or not isinstance(item.value, str):
            return None
        values.append(item.value)
    return tuple(values)


def verify_dynamic_packlink_contracts(errors: list[str]) -> None:
    page = ROOT / "pages/4_Packlink_PRO.py"
    tree = parse(page)
    found: dict[str, tuple[str, ...]] = {}
    required_assignments: set[str] = set()

    for stmt in tree.body:
        if not isinstance(stmt, ast.Assign) or len(stmt.targets) != 1 or not isinstance(stmt.targets[0], ast.Name):
            continue
        name = stmt.targets[0].id
        if re.fullmatch(r"_REQUIRED_[A-Z0-9_]+_SYMBOLS", name):
            required_assignments.add(name)
            values = literal_string_tuple(stmt.value)
            if values is None:
                errors.append(f"{page.relative_to(ROOT)}: il contratto {name} non è una tupla/lista letterale")
            else:
                found[name] = values

    unmapped = sorted(required_assignments - set(DYNAMIC_CONTRACTS))
    if unmapped:
        errors.append(
            "Nuovi contratti dinamici senza mapping nel gate di release: " + ", ".join(unmapped)
        )

    for contract_name, module in DYNAMIC_CONTRACTS.items():
        values = found.get(contract_name)
        if values is None:
            errors.append(f"Contratto richiesto non trovato nella pagina Packlink: {contract_name}")
            continue
        target = module_path(module)
        if target is None:
            errors.append(f"Modulo del contratto inesistente: {module}")
            continue
        symbols = collect_module_symbols(parse(target))
        missing = [name for name in values if name not in symbols]
        if missing:
            errors.append(
                f"{module} non soddisfa {contract_name}; simboli mancanti: {', '.join(missing)}"
            )


def verify_catalog_intelligence_contract(errors: list[str]) -> None:
    page = ROOT / "pages/3_Creazione_Prodotti.py"
    if not page.is_file():
        errors.append("Pagina Creazione Prodotti assente: pages/3_Creazione_Prodotti.py")
        return

    for module, required in CATALOG_INTELLIGENCE_CONTRACTS.items():
        target = module_path(module)
        if target is None or target.is_dir():
            errors.append(f"Modulo Catalog Intelligence inesistente: {module}")
            continue
        symbols = collect_module_symbols(parse(target))
        missing = [name for name in required if name not in symbols]
        if missing:
            errors.append(
                f"{module} non soddisfa il contratto Catalog Intelligence; "
                f"simboli mancanti: {', '.join(missing)}"
            )

    try:
        release_version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
    except Exception:
        return
    init_path = ROOT / "services/catalog_intelligence/__init__.py"
    init_tree = parse(init_path)
    catalog_version = None
    for stmt in init_tree.body:
        if not isinstance(stmt, (ast.Assign, ast.AnnAssign)):
            continue
        targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
        if not any(isinstance(target, ast.Name) and target.id == "CATALOG_INTELLIGENCE_VERSION" for target in targets):
            continue
        value = stmt.value
        if isinstance(value, ast.Constant) and isinstance(value.value, int):
            catalog_version = value.value
            break
    if catalog_version != release_version:
        errors.append(
            "Versione Catalog Intelligence non allineata a VERSION.txt: "
            f"{catalog_version!r} != {release_version}"
        )


def verify_release_payload(errors: list[str]) -> None:
    payload = ROOT / "_release_payload"
    if not payload.is_dir():
        errors.append("Cartella _release_payload assente")
        return

    # VERSION.txt fa parte del contratto di auto-riparazione. Se il payload ha una
    # versione differente, il launcher potrebbe sovrascrivere la release live prima
    # del gate (regressione intercettata nella v268).
    live_version = ROOT / "VERSION.txt"
    payload_version = payload / "VERSION.txt"
    if not payload_version.is_file():
        errors.append("Copia auto-riparazione assente: _release_payload/VERSION.txt")
    elif not live_version.is_file():
        errors.append("VERSION.txt live assente")
    else:
        try:
            live_value = int(live_version.read_text(encoding="utf-8-sig").strip())
            payload_value = int(payload_version.read_text(encoding="utf-8-sig").strip())
        except Exception:
            errors.append("VERSION.txt live/payload non contiene un intero valido")
        else:
            if payload_value != live_value:
                errors.append(
                    "Versione payload auto-riparante non allineata a VERSION.txt: "
                    f"{payload_value} != {live_value}"
                )

    # Ogni file Python applicativo deve avere una copia auto-riparante identica.
    # Nessuna nuova pagina o service può quindi essere distribuito senza il suo
    # gemello nel payload di avvio.
    for live in iter_python_files():
        if not live.is_file():
            continue
        relative = live.relative_to(ROOT)
        bundled = payload / relative
        if not bundled.is_file():
            errors.append(f"Copia auto-riparazione assente: _release_payload/{relative}")
            continue
        if sha256(live) != sha256(bundled):
            errors.append(f"Copia _release_payload non allineata al file live: {relative}")



def verify_sqlite_concurrency_contract(errors: list[str]) -> None:
    """Block releases that can re-run schema DDL on every Streamlit rerun."""
    db_path = ROOT / "services" / "db.py"
    schema_path = ROOT / "services" / "catalog_intelligence" / "schema.py"
    page_path = ROOT / "pages" / "3_Creazione_Prodotti.py"
    contracts = {
        db_path: (
            "_DB_INITIALIZED_KEYS",
            "_DB_INIT_LOCK",
            "timeout=60.0",
            'PRAGMA busy_timeout=60000',
            "_retry_locked(_init_db_once",
        ),
        schema_path: (
            "CATALOG_SCHEMA_REVISION = 258",
            "_SCHEMA_READY",
            "_SCHEMA_LOCK",
            "_retry_locked(migrate",
        ),
    }
    for path, markers in contracts.items():
        if not path.is_file():
            errors.append(f"Contratto concorrenza SQLite: manca {path.relative_to(ROOT)}")
            continue
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        for required in markers:
            if required not in text:
                errors.append(
                    f"Contratto concorrenza SQLite incompleto in {path.relative_to(ROOT)}: {required}"
                )
    if page_path.is_file():
        page = page_path.read_text(encoding="utf-8-sig", errors="replace")
        if "bootstrap()\nensure_schema()" in page:
            errors.append(
                "Creazione Prodotti ripete ensure_schema() dopo bootstrap: rischio database locked"
            )

def verify_navigation(errors: list[str]) -> None:
    app = ROOT / "app.py"
    text = app.read_text(encoding="utf-8-sig")
    refs = sorted(set(re.findall(r"['\"](pages/[A-Za-z0-9_./-]+\.py)['\"]", text)))
    for relative in refs:
        if not (ROOT / relative).is_file():
            errors.append(f"Navigazione app.py punta a una pagina inesistente: {relative}")
    if "pages/4_Packlink_PRO.py" not in refs:
        errors.append("Packlink PRO non è presente nella navigazione app.py")
    if "pages/3_Creazione_Prodotti.py" not in refs:
        errors.append("Creazione Prodotti non è presente nella navigazione app.py")


def verify_kaufland_category_schema_contract(errors: list[str]) -> None:
    """Prevent the category-schema HTTP 400 regression fixed in v247.

    Kaufland expects multiple ``embedded`` query parameters, not one
    comma-separated value.  The URL encoder must therefore use ``doseq=True``
    and the category request must keep the attribute options as a sequence.
    This static release gate complements the executable tests and blocks mixed
    or incomplete packages before they reach the user.
    """
    path = ROOT / "services" / "kaufland.py"
    if not path.is_file():
        errors.append("Client Kaufland assente: services/kaufland.py")
        return
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    required_markers = (
        "urlencode(params,doseq=True)",
        '"optional_attributes",',
        '"required_attributes",',
        '"conditional_attributes",',
    )
    for marker in required_markers:
        if marker not in text:
            errors.append(
                "Contratto schema categorie Kaufland incompleto; "
                f"marker mancante: {marker}"
            )
    forbidden = (
        '"required_attributes,optional_attributes',
        '"optional_attributes,required_attributes',
    )
    for marker in forbidden:
        if marker in text:
            errors.append(
                "Schema categorie Kaufland usa ancora embedded separati da virgola: "
                f"{marker}"
            )


def verify_kaufland_category_decision_contract(errors: list[str]) -> None:
    """Prevent low-confidence category proposals from becoming technical blocks.

    Kaufland's official ``/categories/decide/`` endpoint is the primary ranking
    signal for new Kaufland products.  Local taxonomy matching remains a
    fallback/review aid, while BLOCKED is reserved for deterministic feed
    validation after a category has been selected.
    """
    classifier_path = ROOT / "services/catalog_intelligence/category_classifier.py"
    workflow_path = ROOT / "services/catalog_intelligence/workflow.py"
    page_path = ROOT / "pages/3_Creazione_Prodotti.py"
    client_path = ROOT / "services/kaufland.py"
    schema_path = ROOT / "services/catalog_intelligence/schema.py"
    for path in (classifier_path, workflow_path, page_path, client_path, schema_path):
        if not path.is_file():
            errors.append(f"Contratto categoria Kaufland v248: file assente {path.relative_to(ROOT)}")
            return

    classifier = classifier_path.read_text(encoding="utf-8-sig", errors="replace")
    workflow = workflow_path.read_text(encoding="utf-8-sig", errors="replace")
    page = page_path.read_text(encoding="utf-8-sig", errors="replace")
    client = client_path.read_text(encoding="utf-8-sig", errors="replace")
    schema = schema_path.read_text(encoding="utf-8-sig", errors="replace")

    for marker in (
        "KAUFLAND_DECIDE_API",
        "official_rank == 1",
        '"status": "REVIEW"',
        "taxonomy_snapshot_match",
    ):
        if marker not in classifier:
            errors.append(f"Contratto categoria Kaufland v248 incompleto nel classifier: {marker}")

    try:
        decision_block = classifier.split("def category_decision", 1)[1].split(
            "def candidates_as_dicts", 1
        )[0]
    except Exception:
        decision_block = ""
    if not decision_block:
        errors.append("Funzione category_decision non individuata nel classifier")
    elif 'status = "BLOCKED"' in decision_block or '"status": "BLOCKED"' in decision_block:
        errors.append("La sola incertezza di categoria torna ancora BLOCKED")

    for marker in (
        "use_official_kaufland_suggestions: bool = True",
        'status = "REVIEW"',
    ):
        if marker not in workflow:
            errors.append(f"Workflow categoria Kaufland v248 incompleto: {marker}")
    if 'use_official = marketplace == "kaufland"' not in page:
        errors.append("La pagina non abilita automaticamente /categories/decide per Kaufland")
    for marker in (
        '"/categories/decide/"',
        'attempts=[{"storefront":storefront_value}]',
    ):
        if marker not in client:
            errors.append(f"Client category decide Kaufland incompleto: {marker}")
    for marker in (
        "UPDATE product_category_assignments",
        "SET status='REVIEW'",
        "WHERE status='BLOCKED'",
    ):
        if marker not in schema:
            errors.append(f"Migrazione categorie legacy v248 assente: {marker}")


def verify_catalog_normalization_v249_contract(errors: list[str]) -> None:
    """Block regressions in the v249 high-volume/full-feed normalizer.

    The supplier feed must remain complete (producer/brand, long and short
    descriptions, every image URL, documents and nested technical parameters),
    while large catalogues are persisted in bounded durable batches and expose
    measurable progress to the user.
    """
    paths = {
        "normalization": ROOT / "services/catalog_intelligence/normalization.py",
        "mapping": ROOT / "services/catalog_intelligence/mapping.py",
        "feed": ROOT / "services/catalog_intelligence/feed.py",
        "lists": ROOT / "services/lists.py",
        "repository": ROOT / "services/catalog_intelligence/repository.py",
        "page": ROOT / "pages/3_Creazione_Prodotti.py",
        "normalization_test": ROOT / "tests/test_catalog_normalization_v249.py",
        "innpro_test": ROOT / "tests/test_innpro_full_feed_v249.py",
        "feed_test": ROOT / "tests/test_catalog_feed_completeness_v249.py",
    }
    for path in paths.values():
        if not path.is_file():
            errors.append(f"Contratto Catalog Intelligence v249: file assente {path.relative_to(ROOT)}")
    if any(not path.is_file() for path in paths.values()):
        return

    source = {
        name: path.read_text(encoding="utf-8-sig", errors="replace")
        for name, path in paths.items()
    }

    version_match = re.search(
        r"NORMALIZATION_ENGINE_VERSION\s*=\s*(\d+)", source["normalization"]
    )
    engine_version = int(version_match.group(1)) if version_match else 0
    if engine_version < 249:
        errors.append(
            f"Normalizzazione Catalog Intelligence troppo vecchia: {engine_version} < 249"
        )
    for marker in (
        '"producer", "producer_name", "producent"',
        '"long_desc"',
        '"short_desc"',
        'normalized["source_attributes"] = raw',
        "progress_callback",
        "products_per_second",
        "source_snapshot_normalization_cache",
    ):
        if marker not in source["normalization"]:
            errors.append(f"Normalizzazione v249+ incompleta: {marker}")

    for marker in (
        "def _iof_multilingual_text",
        "def _iof_ordered_urls",
        "def _iof_product_parameters",
        '"producer": producer_name',
        '"description": long_description or short_description',
        '"short_description": short_description',
        '"image_urls": image_urls',
        '"documents": document_urls',
        '"parameters": parameters',
    ):
        if marker not in source["lists"]:
            errors.append(f"Parser completo Innpro v249 incompleto: {marker}")

    for marker in (
        'for container_name in ("parameters", "technical_attributes", "attributes", "specifications")',
        "source_attributes.{container_name}",
    ):
        if marker not in source["mapping"]:
            errors.append(f"Mapping parametri feed completo v249 incompleto: {marker}")

    for marker in (
        '"description": clean_text(product.get("description")',
        '"manufacturer": clean_text(product.get("brand")',
        '"picture": list(normalized.get("images") or [])',
        '"documents": list(normalized.get("documents") or [])',
        'fields[f"image-{index}"] = url',
        '"manual", "manuals", "datasheet"',
    ):
        if marker not in source["feed"]:
            errors.append(f"Feed marketplace completo v249 incompleto: {marker}")

    for marker in (
        "with connect() as con",
        "con.executemany(upsert_sql",
        '"_persist_marker"',
        "source_snapshot_normalization_cache",
        "mark_source_snapshot_normalized",
    ):
        if marker not in source["repository"]:
            errors.append(f"Persistenza batch v249 incompleta: {marker}")

    for marker in (
        "Prodotti letti",
        "Normalizzati",
        "Memorizzati",
        "products_per_second",
        "Tempo residuo stimato",
        "Rigenera anche se questa stessa vista è già stata normalizzata",
        '"Marca"',
        '"Descrizione"',
        '"Immagine principale"',
        '"N. immagini"',
        '"Documenti"',
        "feed completo del fornitore",
    ):
        if marker not in source["page"]:
            errors.append(f"UI avanzamento/feed v249 incompleta: {marker}")

    required_tests = (
        ("normalization_test", "test_innpro_producer_populates_brand_and_provenance"),
        ("normalization_test", "test_explicit_brand_has_priority_over_producer"),
        ("normalization_test", "test_bulk_persistence_uses_one_database_transaction"),
        ("normalization_test", "test_progress_reports_percentage_and_products_read"),
        ("innpro_test", "test_innpro_full_iof_keeps_descriptions_all_images_brand_documents_and_parameters"),
        ("innpro_test", "test_complete_innpro_feed_reaches_canonical_product_and_marketplace_payloads"),
        ("innpro_test", "test_nested_iof_parameter_maps_to_official_marketplace_attribute"),
        ("feed_test", "test_marketplace_payloads_keep_brand_description_and_all_image_urls"),
        ("feed_test", "test_documents_and_product_url_are_mapped_when_official_schema_accepts_them"),
    )
    for source_name, marker in required_tests:
        if marker not in source[source_name]:
            errors.append(f"Test regressione v249 assente: {marker}")



def verify_catalog_ingest_v252_contract(errors: list[str]) -> None:
    paths = {
        "normalization": ROOT / "services" / "catalog_intelligence" / "normalization.py",
        "repository": ROOT / "services" / "catalog_intelligence" / "repository.py",
        "page": ROOT / "pages" / "3_Creazione_Prodotti.py",
        "test": ROOT / "tests" / "test_catalog_normalization_v252.py",
    }
    source = {name: path.read_text(encoding="utf-8-sig", errors="replace") for name, path in paths.items()}
    contracts = {
        "normalization": (
            "NORMALIZATION_ENGINE_VERSION = 252",
            "enrich_saved_view_from_price_list",
            "full_feed_enrichment",
            'normalized["_provenance"]',
        ),
        "repository": (
            'compact_normalized.pop("source_attributes", None)',
            '"_persist_marker"',
            "low-write bulk path",
        ),
        "page": (
            'batch_size=1200',
            '"Immagine principale"',
            '"Marca": item["brand"]',
        ),
        "test": (
            "test_v252_enriches_legacy_saved_view_from_current_full_feed",
            "test_v252_fast_ingest_keeps_only_lightweight_marker_rows",
            "test_v252_lazy_provenance_reconstructs_brand_from_raw",
        ),
    }
    for name, markers in contracts.items():
        for marker in markers:
            if marker not in source[name]:
                errors.append(f"Contratto ingest Catalog Intelligence v252 incompleto in {paths[name].relative_to(ROOT)}: {marker}")

def verify_launcher_contract(errors: list[str]) -> None:
    path = ROOT / "AVVIA_MARKETPLACE_HUB.ps1"
    text = path.read_text(encoding="utf-8-sig")
    required_markers = (
        "Get-ApplicationCodeFiles",
        "Test-ApplicationCodeAligned",
        '"pages", "services", "tools"',
        "Get-LivePythonApplicationFiles",
        "Remove-StaleApplicationCode",
        "Remove-StaleApplicationCode $Root $payloadRoot",
        "Get-ChildItem -Path $payloadRoot -File -Recurse",
    )
    for marker in required_markers:
        if marker not in text:
            errors.append(f"Auto-sincronizzazione release incompleta; marker mancante in AVVIA_MARKETPLACE_HUB.ps1: {marker}")


def verify_version(errors: list[str]) -> None:
    path = ROOT / "VERSION.txt"
    try:
        version = int(path.read_text(encoding="utf-8-sig").strip())
    except Exception:
        errors.append("VERSION.txt non contiene un intero valido")
        return
    if version <= 0:
        errors.append("VERSION.txt deve essere > 0")


def verify() -> list[str]:
    errors: list[str] = []
    verify_version(errors)
    verify_navigation(errors)
    verify_local_imports(errors)
    verify_dynamic_packlink_contracts(errors)
    verify_catalog_intelligence_contract(errors)
    verify_kaufland_category_schema_contract(errors)
    verify_kaufland_category_decision_contract(errors)
    verify_catalog_normalization_v249_contract(errors)
    verify_catalog_ingest_v252_contract(errors)
    verify_release_payload(errors)
    verify_sqlite_concurrency_contract(errors)
    verify_launcher_contract(errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Verifica coerenza release Marketplace Hub")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    try:
        errors = verify()
    except Exception as exc:
        errors = [f"Gate di release non eseguibile: {exc}"]
    if errors:
        print("RELEASE NON DISTRIBUIBILE", file=sys.stderr)
        for item in errors:
            print(f"- {item}", file=sys.stderr)
        return 1
    if not args.quiet:
        print("RELEASE CONSISTENCY: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
