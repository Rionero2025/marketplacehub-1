from __future__ import annotations

import ast
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
required = [
    "app.py", "launcher.py", "VERSION.txt",
    "pages/4_Packlink_PRO.py", "services/packlink.py",
    "AGGIORNA_INSTALLAZIONE_ESISTENTE_v231_WINDOWS.bat",
    "AGGIORNA_INSTALLAZIONE_ESISTENTE_v231.ps1",
    "AGGIORNAMENTO_v231.md", "LEGGIMI_INSTALLAZIONE_COMPLETA_v231.txt",
    "tests/test_packlink_v231_existing_shipping_scope.py",
    "MANIFESTO_SHA256_v231.txt",
]
for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f"manca {rel}")

if (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip() != "231":
    errors.append("VERSION.txt non è 231")

page = (ROOT / "pages/4_Packlink_PRO.py").read_text(encoding="utf-8")
service = (ROOT / "services/packlink.py").read_text(encoding="utf-8")

m = re.search(r"PACKLINK_SERVICE_VERSION\s*=\s*(\d+)", service)
if not m or int(m.group(1)) < 230:
    errors.append("services/packlink.py deve essere compatibile v230+")
if "PACKLINK_REQUIRED_SERVICE_VERSION = 230" not in page:
    errors.append("pagina Packlink non richiede il servizio compatibile v230")

for marker in [
    "def packlink_destination_address",
    "def validate_packlink_destination_against_order",
    "clients/warehouses", "selectedWarehouseId",
]:
    if marker not in service:
        errors.append(f"manca logica service Packlink: {marker}")

for marker in [
    "packlink_batch_candidate_v230_",
    "current_order_by_key.get(order_key_now)",
    'draft_payload["to"] = packlink_destination_address(current_order)',
    "validate_packlink_destination_against_order",
    "Destinazione che verrà inviata a Packlink",
    "organized_orders = [item for item in selected_orders if _existing_shipping(item)]",
]:
    if marker not in page:
        errors.append(f"manca logica pagina Packlink: {marker}")

# Exact v231 regression: _existing_shipping must not load current_order.
try:
    tree = ast.parse(page)
    functions = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == "_existing_shipping"]
    if len(functions) != 1:
        errors.append(f"_existing_shipping attesa una volta, trovate {len(functions)}")
    else:
        fn = functions[0]
        loaded = {n.id for n in ast.walk(fn) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
        if "current_order" in loaded:
            errors.append("_existing_shipping usa ancora current_order fuori scope")
        if "order" not in loaded:
            errors.append("_existing_shipping non usa il parametro order")
except SyntaxError as exc:
    errors.append(f"pagina Packlink non parsabile: {exc}")

manifest = ROOT / "MANIFESTO_SHA256_v231.txt"
if manifest.exists():
    for line in manifest.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, rel = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:80]}")
            continue
        target = ROOT / rel
        if not target.is_file():
            errors.append(f"manifesto: manca {rel}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {rel}")

print("Marketplace Hub release v231 - verifica pacchetto")
if errors:
    for err in errors:
        print("[ERRORE]", err)
    sys.exit(1)
print("[OK] struttura completa")
print("[OK] fix NameError _existing_shipping/current_order")
print("[OK] destinatario v230 ricostruito dall'ordine corrente")
print("[OK] memoria tariffa/pacco e rigenerazione preservate")
