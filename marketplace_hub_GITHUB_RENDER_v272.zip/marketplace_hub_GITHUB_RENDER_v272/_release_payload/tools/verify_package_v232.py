from __future__ import annotations

import ast
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
required = [
    "app.py", "launcher.py", "VERSION.txt", "AVVIA_WINDOWS.bat", "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/4_Packlink_PRO.py", "services/packlink.py",
    "AGGIORNAMENTO_v232.md", "LEGGIMI_AVVIO_SEMPLICE_v232.txt",
    "tests/test_startup_auto_update_v232.py", "tests/test_packlink_v231_existing_shipping_scope.py",
    "MANIFESTO_SHA256_v232.txt",
]
for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f"manca {rel}")

if (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip() != "232":
    errors.append("VERSION.txt non è 232")

bat = (ROOT / "AVVIA_WINDOWS.bat").read_text(encoding="utf-8", errors="ignore")
bootstrap = (ROOT / "AVVIA_MARKETPLACE_HUB.ps1").read_text(encoding="utf-8", errors="ignore")
page = (ROOT / "pages/4_Packlink_PRO.py").read_text(encoding="utf-8")
service = (ROOT / "services/packlink.py").read_text(encoding="utf-8")

if "AVVIA_MARKETPLACE_HUB.ps1" not in bat:
    errors.append("AVVIA_WINDOWS.bat non richiama il bootstrap automatico")
if "AGGIORNA_INSTALLAZIONE_ESISTENTE" in bat:
    errors.append("AVVIA_WINDOWS.bat dipende ancora dall'aggiornamento manuale")
for marker in [
    "Sync-ApplicationCode $Source $Target",
    "Verify-SynchronizedCode $Source $Target",
    '$targetVersion -gt $sourceVersion',
    'Join-Path $From "data"',
    'Join-Path $From ".venv"',
    '"secrets.toml"',
    "pre_auto_update_v232_",
    "INSTALLA_MARKETPLACE_HUB.ps1",
]:
    if marker not in bootstrap:
        errors.append(f"bootstrap v232 incompleto: {marker}")

m = re.search(r"PACKLINK_SERVICE_VERSION\s*=\s*(\d+)", service)
if not m or int(m.group(1)) < 230:
    errors.append("services/packlink.py deve restare compatibile v230+")
if "PACKLINK_REQUIRED_SERVICE_VERSION = 230" not in page:
    errors.append("pagina Packlink non richiede il servizio v230")

try:
    tree = ast.parse(page)
    functions = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == "_existing_shipping"]
    if len(functions) != 1:
        errors.append(f"_existing_shipping attesa una volta, trovate {len(functions)}")
    else:
        loaded = {n.id for n in ast.walk(functions[0]) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
        if "current_order" in loaded:
            errors.append("regressione v231: _existing_shipping usa current_order fuori scope")
except SyntaxError as exc:
    errors.append(f"pagina Packlink non parsabile: {exc}")

manifest = ROOT / "MANIFESTO_SHA256_v232.txt"
if manifest.exists():
    for line in manifest.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, rel = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:80]}")
            continue
        target = ROOT / rel
        if not target.is_file():
            errors.append(f"manifesto: manca {rel}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {rel}")

print("Marketplace Hub release v232 - verifica pacchetto")
if errors:
    for err in errors:
        print("[ERRORE]", err)
    sys.exit(1)
print("[OK] pacchetto completo")
print("[OK] AVVIA_WINDOWS.bat gestisce aggiornamento automatico")
print("[OK] dati/DB/secrets/.venv preservati")
print("[OK] protezione downgrade presente")
print("[OK] correzioni Packlink fino a v231 preservate")
