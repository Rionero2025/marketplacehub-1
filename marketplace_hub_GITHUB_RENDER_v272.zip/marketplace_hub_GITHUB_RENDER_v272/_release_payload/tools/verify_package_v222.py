from __future__ import annotations
import ast
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
required = [
    'app.py','launcher.py','requirements.txt','requirements-installer.txt','AVVIA_WINDOWS.bat',
    'INSTALLA_TUTTO_WINDOWS.bat','INSTALLA_MARKETPLACE_HUB.ps1',
    'pages/4_Packlink_PRO.py','services/packlink.py','services/db.py',
    'tests/test_packlink_v221.py','AGGIORNAMENTO_v222.md','VERSION.txt'
]
errors=[]
for rel in required:
    if not (ROOT/rel).is_file(): errors.append(f'manca {rel}')
for rel in ('pages/4_Packlink_PRO.py','services/packlink.py'):
    p=ROOT/rel
    if p.exists():
        try: ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
        except Exception as exc: errors.append(f'{rel} non compilabile: {exc}')
packlink = ROOT/'services/packlink.py'
if packlink.exists():
    text=packlink.read_text(encoding='utf-8')
    if 'def last_order_draft_configuration(' not in text:
        errors.append('services/packlink.py non contiene last_order_draft_configuration')
    m = __import__('re').search(r'PACKLINK_SERVICE_VERSION\s*=\s*(\d+)', text)
    if not m or int(m.group(1)) < 221:
        errors.append('PACKLINK_SERVICE_VERSION è precedente alla v221')
page=ROOT/'pages/4_Packlink_PRO.py'
if page.exists() and 'last_order_draft_configuration' not in page.read_text(encoding='utf-8'):
    errors.append('pagina Packlink non usa last_order_draft_configuration')
pycs=list(ROOT.rglob('*.pyc'))
caches=[p for p in ROOT.rglob('__pycache__') if p.is_dir()]
if pycs or caches:
    errors.append('sono presenti cache Python nel pacchetto')
print('Marketplace Hub v222 - verifica pacchetto')
print('File:', sum(1 for p in ROOT.rglob('*') if p.is_file()))
print('Pagine Python:', len(list((ROOT/'pages').glob('*.py'))))
print('Servizi Python:', len(list((ROOT/'services').glob('*.py'))))
print('Test Python:', len(list((ROOT/'tests').glob('test_*.py'))))
if errors:
    for e in errors: print('[ERRORE]', e)
    raise SystemExit(1)
print('[OK] struttura completa')
print('[OK] Packlink pagina/servizio allineati')
print('[OK] memoria rigenerazione presente')
