from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/4_Ordini_INNPRO.py",
    "services/innpro_orders.py",
    "tests/test_innpro_orders_v262.py",
    "AGGIORNAMENTO_v262.md",
    "STRUTTURA_COMPLETA_v262.md",
    "VALIDAZIONE_v262.txt",
    "MANIFESTO_SHA256_v262.txt",
    "tools/verify_release_consistency.py",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 262:
    errors.append(f"VERSION.txt non è 262: {version!r}")

contracts = {
    "app.py": (
        'pages/4_Ordini_INNPRO.py',
        'title="Creazione Ordini INNPRO"',
    ),
    "services/innpro_orders.py": (
        "def parse_innpro_composite_sku(",
        "def is_valid_ean13(",
        "def aggregate_innpro_order_lines(",
        "def export_innpro_csv_bytes(",
        '"\\r\\n".join(rows)',
    ),
    "pages/4_Ordini_INNPRO.py": (
        'st.title("Creazione Ordini INNPRO")',
        '"Mostra solo SKU INNPRO"',
        '"Scarica file ordini INNPRO"',
        "aggregate_innpro_order_lines",
        "export_innpro_csv_bytes",
    ),
    "services/catalog_intelligence/__init__.py": (
        "CATALOG_INTELLIGENCE_VERSION = 262",
    ),
    "services/data_transfer.py": (
        "TRANSFER_SERVICE_VERSION = 261",
        "TRANSFER_FORMAT_VERSION = 2",
    ),
    "services/accounting.py": (
        "def computed_profit_values(",
        "def save_accounting_inline_edits(",
    ),
    "services/packlink.py": (
        "PACKLINK_SERVICE_VERSION = 255",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in text:
            errors.append(f"contratto v262 incompleto in {relative}: {marker}")

for relative in (
    "app.py",
    "pages/4_Ordini_INNPRO.py",
    "services/innpro_orders.py",
    "services/catalog_intelligence/__init__.py",
    "tools/verify_package_v262.py",
):
    live = ROOT / relative
    bundled = ROOT / "_release_payload" / relative
    if not bundled.is_file():
        errors.append(f"payload v262 mancante: {relative}")
    elif live.read_bytes() != bundled.read_bytes():
        errors.append(f"payload v262 non allineato: {relative}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        p for p in (ROOT / folder).rglob("*.py") if "__pycache__" not in p.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

verify_env = dict(os.environ)
verify_env["PYTHONDONTWRITEBYTECODE"] = "1"

gate = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if gate.returncode != 0:
    errors.append("gate release fallito: " + (gate.stderr or gate.stdout).strip())

specific = subprocess.run(
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_innpro_orders_v262.py",
        "tests/test_app_navigation_v236.py",
        "tests/test_cecotec_orders.py",
        "tests/test_data_transfer_v261.py",
        "tests/test_accounting_live_manual_v259.py",
        "tests/test_packlink_v255_order_cache.py",
    ],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
    env=verify_env,
)
if specific.returncode != 0:
    errors.append("test v262/compatibilità falliti: " + (specific.stderr or specific.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v262.txt"
if manifest.is_file():
    for raw in manifest.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != expected:
            errors.append(f"manifesto: hash non valido {relative}")

if errors:
    for error in errors:
        print("ERRORE:", error)
    raise SystemExit(1)
print("Marketplace Hub v262 verificato: OK")
