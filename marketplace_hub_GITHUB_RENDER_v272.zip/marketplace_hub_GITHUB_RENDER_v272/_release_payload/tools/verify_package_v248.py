from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/3_Creazione_Prodotti.py",
    "services/kaufland.py",
    "services/catalog_intelligence/__init__.py",
    "services/catalog_intelligence/schema.py",
    "services/catalog_intelligence/normalization.py",
    "services/catalog_intelligence/category_classifier.py",
    "services/catalog_intelligence/category_schema.py",
    "services/catalog_intelligence/feed.py",
    "services/catalog_intelligence/workflow.py",
    "services/catalog_intelligence/repository.py",
    "services/catalog_intelligence/publication.py",
    "services/catalog_intelligence/taxonomy.py",
    "services/catalog_intelligence/validation.py",
    "tests/test_catalog_intelligence_v244.py",
    "tests/test_catalog_intelligence_v245.py",
    "tests/test_catalog_publication_v246.py",
    "tests/test_kaufland_category_schema_v247.py",
    "tests/test_kaufland_category_decide_v248.py",
    "tools/verify_release_consistency.py",
    "AGGIORNAMENTO_v248.md",
    "STRUTTURA_COMPLETA_v248.md",
    "VALIDAZIONE_v248.txt",
    "MANIFESTO_SHA256_v248.txt",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 248:
    errors.append(f"VERSION.txt non è 248: {version!r}")

init_text = (ROOT / "services/catalog_intelligence/__init__.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
if "CATALOG_INTELLIGENCE_VERSION = 248" not in init_text:
    errors.append("Catalog Intelligence non è allineato alla v248")

app_text = (ROOT / "app.py").read_text(encoding="utf-8-sig", errors="replace")
if "pages/3_Creazione_Prodotti.py" not in app_text:
    errors.append("Creazione Prodotti non è presente nella navigazione")

page_text = (ROOT / "pages/3_Creazione_Prodotti.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
for marker in (
    "Catalog Intelligence",
    "Determina categorie dal feed completo",
    'use_official = marketplace == "kaufland"',
    "POST /categories/decide",
    "Prepara feed prodotti completi",
    "Pubblicazione reale controllata",
):
    if marker not in page_text:
        errors.append(f"pagina Creazione Prodotti v248 incompleta: {marker}")

classifier_text = (
    ROOT / "services/catalog_intelligence/category_classifier.py"
).read_text(encoding="utf-8-sig", errors="replace")
for marker in (
    "def kaufland_decide_payload(",
    "def parse_kaufland_suggestions(",
    "def category_decision(",
    "official_rank == 1",
    "taxonomy_snapshot_match",
    '"status": "REVIEW"',
    "ORDERED_RANK_WEIGHT_NOT_API_PROBABILITY",
):
    if marker not in classifier_text:
        errors.append(f"classifier Kaufland v248 incompleto: {marker}")
try:
    decision_block = classifier_text.split("def category_decision", 1)[1].split(
        "def candidates_as_dicts", 1
    )[0]
except Exception:
    decision_block = ""
if not decision_block:
    errors.append("category_decision non individuata")
elif 'status = "BLOCKED"' in decision_block or '"status": "BLOCKED"' in decision_block:
    errors.append("category_decision usa ancora BLOCKED per l'incertezza di categoria")

workflow_text = (ROOT / "services/catalog_intelligence/workflow.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
for marker in (
    "use_official_kaufland_suggestions: bool = True",
    'status = "REVIEW"',
    "blocked_count = 0",
):
    if marker not in workflow_text:
        errors.append(f"workflow categorie v248 incompleto: {marker}")

kaufland_text = (ROOT / "services/kaufland.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
for marker in (
    '"/categories/decide/"',
    'attempts=[{"storefront":storefront_value}]',
    "urlencode(params,doseq=True)",
    '"optional_attributes",',
    '"required_attributes",',
    '"conditional_attributes",',
):
    if marker not in kaufland_text:
        errors.append(f"client Kaufland v248 incompleto: {marker}")

schema_text = (ROOT / "services/catalog_intelligence/schema.py").read_text(
    encoding="utf-8-sig", errors="replace"
)
for marker in (
    "UPDATE product_category_assignments",
    "SET status='REVIEW'",
    "WHERE status='BLOCKED'",
):
    if marker not in schema_text:
        errors.append(f"migrazione categorie v248 incompleta: {marker}")

normalization_text = (
    ROOT / "services/catalog_intelligence/normalization.py"
).read_text(encoding="utf-8-sig", errors="replace")
for marker in ("TITLE_ALIASES", "product_title", "designation", "bezeichnung"):
    if marker not in normalization_text:
        errors.append(f"normalizzazione titolo v248 incompleta: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        path for path in (ROOT / folder).rglob("*.py") if "__pycache__" not in path.parts
    )
for path in python_files:
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

completed = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
)
if completed.returncode != 0:
    errors.append("gate release fallito: " + (completed.stderr or completed.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v248.txt"
if manifest.is_file():
    for raw_line in manifest.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    path
    for path in ROOT.rglob("*")
    if "__pycache__" in path.parts or path.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti nel pacchetto: {len(cache_files)}")

print("Marketplace Hub v248 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] release consistency gate")
print("[OK] classificazione ufficiale Kaufland abilitata automaticamente")
print("[OK] primo suggerimento ufficiale verificato contro la tassonomia cached")
print("[OK] bassa confidenza e nessun candidato restano in REVIEW")
print("[OK] BLOCKED riservato alla validazione tecnica del feed")
print("[OK] migrazione assegnazioni storiche BLOCKED -> REVIEW")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
