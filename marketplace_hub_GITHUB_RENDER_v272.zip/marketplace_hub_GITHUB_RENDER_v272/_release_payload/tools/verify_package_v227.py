from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=[
    'app.py','launcher.py','VERSION.txt','pages/4_Packlink_PRO.py','services/packlink.py',
    'AGGIORNA_INSTALLAZIONE_ESISTENTE_v227_WINDOWS.bat','AGGIORNA_INSTALLAZIONE_ESISTENTE_v227.ps1',
    'AGGIORNAMENTO_v227.md','LEGGIMI_INSTALLAZIONE_COMPLETA_v227.txt',
    'tests/test_packlink_v227_regeneration_tariffs.py','MANIFESTO_SHA256_v227.txt'
]
for rel in required:
    if not (ROOT/rel).exists(): errors.append(f'manca {rel}')
if (ROOT/'VERSION.txt').exists() and (ROOT/'VERSION.txt').read_text(encoding='utf-8').strip()!='227':
    errors.append('VERSION.txt non è 227')
page=(ROOT/'pages/4_Packlink_PRO.py').read_text(encoding='utf-8')
service=(ROOT/'services/packlink.py').read_text(encoding='utf-8')
m=re.search(r'PACKLINK_SERVICE_VERSION\s*=\s*(\d+)', service)
if not m or int(m.group(1))<226: errors.append('services/packlink.py deve essere v226+')
for marker in ['def _restorable_historical_service','def _effective_services','pending_orders = [','enumerate(pending_orders, 1)','disabled=not bool(pending_orders)']:
    if marker not in page: errors.append(f'manca logica v227: {marker}')
if 'Calcola / aggiorna tariffe per tutti gli ordini selezionati' in page:
    errors.append('presente ancora ricalcolo indiscriminato tariffe')
if 'Confermo la creazione della spedizione pronta per il pagamento su Packlink PRO' in page:
    errors.append('presente ancora conferma ridondante')
if 'shipping_address_lookup' not in service or 'def _coalesced_order_address' not in service:
    errors.append('mancano correzioni destinatario v226')
if 'def last_order_draft_configuration' not in service:
    errors.append('manca memoria configurazione Packlink')
print('Marketplace Hub v227 - verifica pacchetto')
if errors:
    for e in errors: print('[ERRORE]',e)
    sys.exit(1)
print('[OK] struttura completa')
print('[OK] rigenerazione usa tariffe storiche come valide')
print('[OK] ricalcolo massivo limitato agli ordini senza tariffa')
print('[OK] memoria tariffa/pacco e indirizzi v226 preservati')
