from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = (
    "VERSION.txt",
    "app.py",
    "launcher.py",
    "AVVIA_WINDOWS.bat",
    "AVVIA_MARKETPLACE_HUB.ps1",
    "pages/3_Creazione_Prodotti.py",
    "services/lists.py",
    "services/catalog_intelligence/__init__.py",
    "services/catalog_intelligence/normalization.py",
    "services/catalog_intelligence/mapping.py",
    "services/catalog_intelligence/feed.py",
    "services/catalog_intelligence/repository.py",
    "tests/test_catalog_normalization_v249.py",
    "tests/test_catalog_normalization_v250.py",
    "tests/test_innpro_full_feed_v249.py",
    "tests/test_catalog_feed_completeness_v249.py",
    "tools/verify_release_consistency.py",
    "AGGIORNAMENTO_v250.md",
    "STRUTTURA_COMPLETA_v250.md",
    "VALIDAZIONE_v250.txt",
    "MANIFESTO_SHA256_v250.txt",
)
for relative in required:
    if not (ROOT / relative).is_file():
        errors.append(f"manca {relative}")

try:
    version = int((ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").strip())
except Exception:
    version = 0
if version != 250:
    errors.append(f"VERSION.txt non è 250: {version!r}")

init_path = ROOT / "services/catalog_intelligence/__init__.py"
if init_path.is_file():
    init_text = init_path.read_text(encoding="utf-8-sig", errors="replace")
    if "CATALOG_INTELLIGENCE_VERSION = 250" not in init_text:
        errors.append("Catalog Intelligence non è allineato alla v250")

contracts = {
    "services/catalog_intelligence/normalization.py": (
        "NORMALIZATION_ENGINE_VERSION = 250",
        '"producer", "producer_name", "producent"',
        'normalized["source_attributes"] = raw',
        "progress_callback",
        "products_per_second",
        "source_snapshot_normalization_cache",
    ),
    "services/lists.py": (
        "def _iof_multilingual_text",
        "def _iof_ordered_urls",
        "def _iof_product_parameters",
        '"producer": producer_name',
        '"description": long_description or short_description',
        '"short_description": short_description',
        '"image_urls": image_urls',
        '"documents": document_urls',
        '"parameters": parameters',
    ),
    "services/catalog_intelligence/mapping.py": (
        'for container_name in ("parameters", "technical_attributes", "attributes", "specifications")',
        "source_attributes.{container_name}",
    ),
    "services/catalog_intelligence/feed.py": (
        '"description": clean_text(product.get("description")',
        '"manufacturer": clean_text(product.get("brand")',
        '"picture": list(normalized.get("images") or [])',
        '"documents": list(normalized.get("documents") or [])',
        'fields[f"image-{index}"] = url',
    ),
    "services/catalog_intelligence/repository.py": (
        "with connect() as con",
        "con.executemany(upsert_sql",
        "con.executemany(evidence_sql",
        "con.executemany(value_sql",
        "con.commit()",
        'if field_name == "source_attributes"',
        "source_snapshot_normalization_cache",
    ),
    "pages/3_Creazione_Prodotti.py": (
        "Prodotti letti",
        "Normalizzati",
        "Memorizzati",
        "products_per_second",
        "Tempo residuo stimato",
        '"Marca"',
        '"Descrizione"',
        '"URL immagini"',
        '"Documenti"',
        "feed completo del fornitore",
    ),
}
for relative, markers in contracts.items():
    path = ROOT / relative
    if not path.is_file():
        continue
    source = path.read_text(encoding="utf-8-sig", errors="replace")
    for marker in markers:
        if marker not in source:
            errors.append(f"contratto v250 incompleto in {relative}: {marker}")

python_files = [ROOT / "app.py", ROOT / "launcher.py"]
for folder in ("pages", "services", "tools"):
    python_files.extend(
        path for path in (ROOT / folder).rglob("*.py") if "__pycache__" not in path.parts
    )
for path in python_files:
    if not path.is_file():
        continue
    try:
        compile(path.read_text(encoding="utf-8-sig"), str(path), "exec")
    except Exception as exc:
        errors.append(f"compilazione fallita {path.relative_to(ROOT)}: {exc}")

completed = subprocess.run(
    [sys.executable, str(ROOT / "tools" / "verify_release_consistency.py"), "--quiet"],
    cwd=ROOT,
    check=False,
    capture_output=True,
    text=True,
)
if completed.returncode != 0:
    errors.append("gate release fallito: " + (completed.stderr or completed.stdout).strip())

manifest = ROOT / "MANIFESTO_SHA256_v250.txt"
if manifest.is_file():
    for raw_line in manifest.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"riga manifesto non valida: {line[:100]}")
            continue
        target = ROOT / relative
        if not target.is_file():
            errors.append(f"manifesto: manca {relative}")
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual.lower() != expected.lower():
            errors.append(f"manifesto: hash diverso {relative}")

cache_files = [
    path for path in ROOT.rglob("*")
    if "__pycache__" in path.parts or path.suffix.lower() in {".pyc", ".pyo"}
]
if cache_files:
    errors.append(f"cache Python presenti nel pacchetto: {len(cache_files)}")

print("Marketplace Hub v250 - verifica pacchetto")
if errors:
    for error in errors:
        print("[ERRORE]", error)
    raise SystemExit(1)
print(f"[OK] compilazione Python: {len(python_files)} file")
print("[OK] release consistency gate")
print("[OK] avanzamento percentuale, prodotti letti, velocità ed ETA")
print("[OK] persistenza durabile a blocchi, avanzamento continuo e cache persistente")
print("[OK] producer Innpro -> brand/marchio con provenienza")
print("[OK] descrizione breve/lunga, tutte le immagini, documenti e parametri tecnici")
print("[OK] feed Kaufland e Mirakl con contenuti completi supportati dallo schema")
print("[OK] manifesto SHA-256")
print("[OK] nessuna cache Python")
