# Marketplace Hub v263 — struttura e garanzie

Release: **263**

## File aggiornati
- `pages/4_Ordini_INNPRO.py` — avvisi duplicati, archivio storico, rigenerazione controllata e download dei file memorizzati;
- `services/innpro_orders.py` — schema storico, salvataggio CSV persistente, lookup per numero ordine marketplace e rilettura file;
- `services/data_transfer.py` — inclusione selettiva degli archivi INNPRO nei backup compatti;
- `services/catalog_intelligence/__init__.py` — allineamento versione release;
- `VERSION.txt` — release 263.

## Nuove tabelle persistenti
- `innpro_order_exports` — un record per ogni file INNPRO generato;
- `innpro_order_export_orders` — collegamento tra export e numeri ordine marketplace.

## Contratto storico
- chiave logica duplicato: `seller + account marketplace + marketplace + numero ordine`;
- il warning riporta data/ora e file dell'ultima generazione di quell'ordine;
- il file originario resta riscaricabile;
- una rigenerazione volontaria crea un nuovo record, mentre il warning successivo punta alla generazione più recente;
- gli ordini già generati sono esclusi per impostazione predefinita.

## Persistenza file
I CSV sono memorizzati sotto `data/innpro_orders/<seller>/<marketplace>/<account>/<export_id>/` e il database conserva il riferimento portabile. Il backup compatto include solo i file effettivamente referenziati.

## Regole release preservate
- ZIP finale sempre `marketplace_hub.zip`;
- avvio esclusivamente con `AVVIA_WINDOWS.bat` dopo estrazione;
- `_release_payload` allineato al codice live;
- protezione anti-downgrade;
- database, `data`, Seller, ordini, credenziali, configurazioni e `.venv` preservati durante gli aggiornamenti ordinari.
