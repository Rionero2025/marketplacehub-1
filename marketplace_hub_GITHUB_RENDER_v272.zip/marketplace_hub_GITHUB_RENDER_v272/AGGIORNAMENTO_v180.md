# Marketplace Hub v180

## Verifica Kaufland accurata per ordini Cecotec

La generazione degli ordini Cecotec legge ora, per ogni unità Kaufland selezionata:

- stato live dell'unità;
- dettaglio live dell'ordine quando l'unità risulta `open`;
- storefront/nazione del marketplace (`de`, `at`, `pl`, `cz`, `sk`, `fr`, `it`);
- indirizzo e Paese di consegna tramite l'endpoint ufficiale `/shipping-addresses`;
- stato distinto per creazione dell'ordine fornitore e aggiornamento spedizione.

Una unità `open` non viene più esclusa automaticamente con la dicitura generica
"finestra cancellazione". Il programma ricontrolla il dettaglio live:

- se nel frattempo è passata a `need_to_be_sent`, viene trattata come pronta;
- se è ancora `open` ma Kaufland restituisce l'indirizzo completo, può essere inserita
  nel file Cecotec, ma non può ancora essere marcata come spedita su Kaufland;
- se è `open` e l'indirizzo non è disponibile, resta bloccata fino al passaggio di stato.

La tabella di verifica mostra ora marketplace, nazione marketplace, Paese di
consegna, disponibilità dell'indirizzo, stato API, autorizzazione Cecotec e
autorizzazione all'aggiornamento spedizione.

Gli indirizzi e il Paese recuperati live vengono riportati nella riga Cecotec e
salvati nella cache locale. Lo storefront viene memorizzato nel database con una
migrazione automatica compatibile con le installazioni precedenti.

La stessa classificazione live continua a essere utilizzata anche nella sezione
Ticket e messaggi, affinché IA e operatore vedano lo stato reale dell'ordine.
