# Aggiornamento v130 — Correzione rendering Dashboard

- Corretto il problema per cui il codice HTML dei riquadri Seller veniva mostrato come testo.
- Il markup della Dashboard viene ora generato senza indentazione Markdown.
- Restano invariati la griglia a due colonne, i valori di vendita e guadagno e le regole economiche della Contabilità.
