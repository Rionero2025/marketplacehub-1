# Marketplace Hub v172

## Configurazione IA direttamente nei Ticket

Nella sezione **Impostazioni IA e SLA** della console Ticket è ora possibile:

- scegliere il provider tramite checkbox;
- aprire automaticamente il riquadro delle credenziali del provider selezionato;
- inserire API key, modello, endpoint e parametri specifici;
- salvare la configurazione cifrata;
- usare **Salva e verifica connessione** per controllare immediatamente credenziali, provider e modello;
- mantenere più provider collegati e scegliere successivamente principale e fallback.

Sono supportati OpenAI, Anthropic Claude, Google Gemini, Mistral, xAI Grok,
DeepSeek, Groq, OpenRouter, Azure OpenAI, Amazon Bedrock, Ollama ed endpoint
compatibili OpenAI.

## Editor WYSIWYG completo

L'editor delle risposte Ticket include una barra strumenti con:

- titoli;
- grassetto, corsivo, sottolineato e barrato;
- colore del testo e sfondo;
- apice e pedice;
- elenchi numerati e puntati;
- rientri;
- allineamento;
- citazioni e blocchi di codice;
- collegamenti;
- rimozione della formattazione.

La bozza resta modificabile in formato ricco. Prima dell'invio il contenuto viene
convertito in testo pulito compatibile con le API Kaufland e Worten.
