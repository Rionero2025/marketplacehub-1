# Marketplace Hub v164

## Creazione ordini Cecotec: selezione stabile e filtri avanzati

- La griglia ordini usa la modalità manuale di AgGrid: è possibile selezionare più righe senza provocare un rerun a ogni click. La selezione viene trasferita al programma premendo **Applica** nel componente.
- Le selezioni restano memorizzate anche cambiando filtro, stato o pagina.
- Rimangono disponibili i comandi **Seleziona tutti filtrati**, **Deseleziona tutti filtrati** e **Azzera selezione**.
- Aggiunti filtri per stato API dettagliato, macro-stato, nazione, fornitore, ricerca libera, quantità minima/massima, righe già generate/non generate, completezza dati cliente, telefono, email, validità SKU, solo ordini operativi e duplicati ordine/SKU.
- Aggiunta una legenda completa degli stati ufficiali Worten/Mirakl e Kaufland.
