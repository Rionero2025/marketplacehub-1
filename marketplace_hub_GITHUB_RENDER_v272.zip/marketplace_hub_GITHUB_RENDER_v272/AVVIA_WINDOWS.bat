@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - Avvio automatico
rem Il bootstrap usa in priorita .venv\Scripts\python.exe quando presente e avvia launcher.py.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AVVIA_MARKETPLACE_HUB.ps1"
if errorlevel 1 (
  echo.
  echo Avvio non completato. Leggi il messaggio sopra.
  pause
  exit /b 1
)
exit /b 0
