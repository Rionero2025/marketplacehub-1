# Marketplace Hub v222 — struttura completa

- File totali: **265**
- Pagine Python: **23**
- Servizi Python: **44**
- Test Python: **59**
- Tool Python: **3**

## Componenti principali
- applicazione Streamlit completa;
- gestione Seller, marketplace, fornitori e listini;
- Kaufland e Worten;
- ordini, Buy Box, cancellazioni e pubblicazione;
- Cecotec;
- Packlink PRO con memoria rigenerazione per ordine;
- contabilità e tracciabilità;
- SQLite/PostgreSQL e strumenti di migrazione;
- installer, riparazione e diagnostica Windows;
- test automatici.
