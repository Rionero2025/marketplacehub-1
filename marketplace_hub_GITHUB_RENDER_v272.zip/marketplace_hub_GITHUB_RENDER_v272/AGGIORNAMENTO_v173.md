# Marketplace Hub v173

## Toolbar WYSIWYG Ticket ripristinata

La toolbar non appariva perché il progetto dichiarava la vecchia dipendenza
`streamlit-quill`, mentre l'installazione corrente utilizza Python/Streamlit più
recenti e il codice passava silenziosamente a una normale textarea.

Correzioni:

- dipendenza aggiornata a `streamlit-quill2==0.0.5`;
- il launcher installa/aggiorna automaticamente tutte le dipendenze prima di
  avviare Streamlit;
- aggiunto `RIPARA_DIPENDENZE_WINDOWS.bat` per la riparazione manuale;
- la toolbar Quill mostra titoli, grassetto, corsivo, sottolineato, barrato,
  colori, evidenziazione, apice/pedice, elenchi, rientri, allineamento,
  citazioni, codice, link e pulizia formato;
- gli errori del componente non vengono più nascosti: il programma indica
  esplicitamente come riparare l'installazione.
