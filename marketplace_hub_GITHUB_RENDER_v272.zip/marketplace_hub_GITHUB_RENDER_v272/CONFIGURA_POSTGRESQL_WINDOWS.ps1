$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $Root "data\database.toml"

if (Test-Path $ConfigPath) {
    $ExistingConfig = Get-Content $ConfigPath -Raw
    if ($ExistingConfig -match '(?m)^engine\s*=\s*"postgresql"\s*$') {
        Write-Host "PostgreSQL risulta gia attivo in Marketplace Hub." -ForegroundColor Yellow
        Write-Host "Per evitare modifiche accidentali alle credenziali, configurazione interrotta."
        Write-Host "Usa la pagina Database per verificarne lo stato."
        exit 3
    }
}

function Find-Psql {
    $cmd = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $base = "C:\Program Files\PostgreSQL"
    if (Test-Path $base) {
        $candidates = Get-ChildItem $base -Directory | Sort-Object Name -Descending | ForEach-Object {
            Join-Path $_.FullName "bin\psql.exe"
        } | Where-Object { Test-Path $_ }
        if ($candidates) { return $candidates[0] }
    }
    return $null
}

$Psql = Find-Psql
if (-not $Psql) {
    Write-Host "PostgreSQL non risulta installato sul PC." -ForegroundColor Red
    Write-Host "Installa PostgreSQL per Windows dal sito ufficiale e poi riesegui questo script."
    Write-Host "https://www.postgresql.org/download/windows/"
    exit 2
}

Write-Host "PostgreSQL trovato: $Psql" -ForegroundColor Green
$PortInput = Read-Host "Porta PostgreSQL [5432]"
$Port = if ([string]::IsNullOrWhiteSpace($PortInput)) { "5432" } else { $PortInput.Trim() }
$AdminUserInput = Read-Host "Utente amministratore PostgreSQL [postgres]"
$AdminUser = if ([string]::IsNullOrWhiteSpace($AdminUserInput)) { "postgres" } else { $AdminUserInput.Trim() }
$SecureAdminPassword = Read-Host "Password dell'utente $AdminUser" -AsSecureString
$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureAdminPassword)
try {
    $AdminPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($BSTR)
} finally {
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
}

$bytes = New-Object byte[] 30
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
$AppPassword = ([Convert]::ToBase64String($bytes)).Replace("=", "")
$DbName = "marketplace_hub"
$AppUser = "marketplace_hub"

$env:PGPASSWORD = $AdminPassword
try {
    & $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -v ON_ERROR_STOP=1 -c "SELECT version();" | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "Connessione PostgreSQL amministrativa non riuscita." }

    $roleExists = (& $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='$AppUser';").Trim()
    if ($roleExists -ne "1") {
        & $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -v ON_ERROR_STOP=1 -c "CREATE ROLE $AppUser LOGIN PASSWORD '$AppPassword';" | Out-Host
    } else {
        & $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -v ON_ERROR_STOP=1 -c "ALTER ROLE $AppUser WITH LOGIN PASSWORD '$AppPassword';" | Out-Host
    }
    if ($LASTEXITCODE -ne 0) { throw "Creazione/aggiornamento utente Marketplace Hub non riuscita." }

    $dbExists = (& $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DbName';").Trim()
    if ($dbExists -ne "1") {
        & $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE $DbName OWNER $AppUser ENCODING 'UTF8';" | Out-Host
    } else {
        & $Psql -h 127.0.0.1 -p $Port -U $AdminUser -d postgres -v ON_ERROR_STOP=1 -c "ALTER DATABASE $DbName OWNER TO $AppUser;" | Out-Host
    }
    if ($LASTEXITCODE -ne 0) { throw "Creazione/aggiornamento database Marketplace Hub non riuscita." }
} finally {
    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
    $AdminPassword = $null
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $ConfigPath) | Out-Null
$Config = @"
# Marketplace Hub database configuration
# SQLite rimane attivo finché la migrazione non è verificata.
engine = "sqlite"
postgresql_host = "127.0.0.1"
postgresql_port = $Port
postgresql_database = "$DbName"
postgresql_user = "$AppUser"
postgresql_password = "$AppPassword"
postgresql_sslmode = "prefer"
postgresql_pool_min = 2
postgresql_pool_max = 12
postgresql_connect_timeout = 10
"@
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($ConfigPath, $Config, $Utf8NoBom)
Write-Host "" 
Write-Host "Database PostgreSQL configurato. SQLite è ancora attivo fino alla migrazione." -ForegroundColor Green
Write-Host "Configurazione: $ConfigPath"
