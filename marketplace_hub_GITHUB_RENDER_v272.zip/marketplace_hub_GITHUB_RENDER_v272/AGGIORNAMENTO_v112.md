# Aggiornamento v112 — selezione stabile degli ordini

## Correzione

Il normale aggiornamento automatico di Streamlit poteva ricostruire la tabella
con uno stato precedente subito dopo il clic su un quadratino, impedendo di
selezionare o deselezionare le singole righe.

## Nuovo comportamento

- Ogni clic viene salvato prima del rerun della pagina.
- La selezione è associata all'ID reale dell'unità ordine, non alla sola
  posizione visibile della riga.
- Le spunte successive si aggiungono a quelle già memorizzate.
- Deselezionare una riga non modifica le altre.
- I comandi per selezionare o deselezionare tutti i risultati filtrati
  continuano ad azzerare correttamente lo stato della griglia.
- Totali, date di pagamento, costi, guadagni e CSV seguono immediatamente la
  selezione aggiornata.

## Verifica

Compilazione completata e 151 test automatici superati.
