@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\verify_package_v250.py
) else (
  python tools\verify_package_v250.py
)
if errorlevel 1 (
  echo.
  echo VERIFICA V250 FALLITA.
  pause
  exit /b 1
)
echo.
echo VERIFICA V250 COMPLETATA.
pause
