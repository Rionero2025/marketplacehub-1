# Marketplace Hub v168

## Ripristino selezione multipla dei listini Cecotec

Nella pagina **Creazione Ordini Cecotec** è nuovamente possibile utilizzare contemporaneamente tutti i listini e tutte le versioni Cecotec accessibili al Seller.

- al primo accesso vengono selezionati automaticamente tutti i listini;
- sono disponibili i pulsanti **Seleziona tutti i listini** e **Deseleziona tutti i listini**;
- il match EAN → SKU viene eseguito su un catalogo unificato;
- in caso di EAN duplicato prevale il listino con priorità maggiore;
- i conflitti tra lo stesso EAN e SKU Cecotec differenti vengono mostrati in una tabella di controllo;
- il dettaglio riporta listino, versione, vista, righe ed EAN indicizzati.
