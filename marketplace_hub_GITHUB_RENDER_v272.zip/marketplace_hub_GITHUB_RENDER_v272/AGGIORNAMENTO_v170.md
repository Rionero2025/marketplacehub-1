# Marketplace Hub v170

## Correzione JSON strutturato per i suggerimenti IA Ticket

- OpenAI Responses API usa ora Structured Outputs con `text.format.type = json_schema`.
- Il suggerimento Ticket è vincolato a uno schema JSON rigoroso con tutti i campi richiesti.
- Non viene più affidata la validità del JSON soltanto alle istruzioni testuali del prompt.
- Restano attivi i provider di fallback quando un provider non risponde o non rispetta il formato.
