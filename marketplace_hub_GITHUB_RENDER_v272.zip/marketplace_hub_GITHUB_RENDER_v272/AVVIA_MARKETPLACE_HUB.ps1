﻿param(
    [string]$Target = "$env:USERPROFILE\Documents\marketplace_hub"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$Source = [System.IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path)).TrimEnd('\')
$Target = [System.IO.Path]::GetFullPath($Target).TrimEnd('\')
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host ("=" * 76) -ForegroundColor DarkCyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host ("=" * 76) -ForegroundColor DarkCyan
}
function Write-Ok([string]$Message) { Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-Warn([string]$Message) { Write-Host "[AVVISO] $Message" -ForegroundColor Yellow }
function Fail([string]$Message) { throw $Message }

function Read-PackageVersion([string]$Root) {
    $path = Join-Path $Root "VERSION.txt"
    if (-not (Test-Path $path)) { return 0 }
    try {
        $text = (Get-Content $path -Raw).Trim()
        if ($text -match '^\d+$') { return [int]$text }
    } catch {}
    return 0
}

function Same-FileHash([string]$A, [string]$B) {
    if (-not (Test-Path $A) -or -not (Test-Path $B)) { return $false }
    try {
        return (Get-FileHash -Algorithm SHA256 $A).Hash -eq (Get-FileHash -Algorithm SHA256 $B).Hash
    } catch { return $false }
}

function Get-ApplicationCodeFiles([string]$Root) {
    $relativeFiles = New-Object System.Collections.Generic.List[string]

    foreach ($relative in @(
        "app.py",
        "launcher.py",
        "requirements.txt",
        "AVVIA_WINDOWS.bat",
        "AVVIA_MARKETPLACE_HUB.ps1"
    )) {
        if (Test-Path (Join-Path $Root $relative)) {
            $relativeFiles.Add($relative)
        }
    }

    foreach ($folder in @("pages", "services", "tools")) {
        $base = Join-Path $Root $folder
        if (-not (Test-Path $base)) { continue }
        Get-ChildItem -Path $base -File -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in @(".py", ".ps1", ".bat") } |
            ForEach-Object {
                $relative = $_.FullName.Substring($Root.Length).TrimStart('\')
                $relativeFiles.Add($relative)
            }
    }

    return @($relativeFiles | Sort-Object -Unique)
}

function Test-ApplicationCodeAligned([string]$From, [string]$To) {
    foreach ($relative in @(Get-ApplicationCodeFiles $From)) {
        $sourceFile = Join-Path $From $relative
        $targetFile = Join-Path $To $relative
        if (-not (Same-FileHash $sourceFile $targetFile)) {
            Write-Host "Disallineamento codice rilevato: $relative" -ForegroundColor DarkYellow
            return $false
        }
    }
    return $true
}

function Get-LivePythonApplicationFiles([string]$Root) {
    $relativeFiles = New-Object System.Collections.Generic.List[string]

    foreach ($relative in @("app.py", "launcher.py")) {
        if (Test-Path (Join-Path $Root $relative)) {
            $relativeFiles.Add($relative)
        }
    }

    foreach ($folder in @("pages", "services", "tools")) {
        $base = Join-Path $Root $folder
        if (-not (Test-Path $base)) { continue }
        Get-ChildItem -Path $base -File -Filter "*.py" -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -notlike '*\__pycache__\*' } |
            ForEach-Object {
                $relative = $_.FullName.Substring($Root.Length).TrimStart('\')
                $relativeFiles.Add($relative)
            }
    }

    return @($relativeFiles | Sort-Object -Unique)
}

function Remove-StaleApplicationCode([string]$Root, [string]$PayloadRoot) {
    # Quando un nuovo ZIP viene estratto sopra una release precedente, Windows non
    # elimina i vecchi .py. Quei file orfani facevano fallire il gate di coerenza
    # (es. services\accounting_costs.py / services\marketplace_deletion.py).
    # _release_payload e' la fonte autorevole del codice Python distribuibile:
    # i .py applicativi che non hanno piu' il gemello nel payload sono obsoleti.
    $removed = @()
    foreach ($relative in @(Get-LivePythonApplicationFiles $Root)) {
        $bundled = Join-Path $PayloadRoot $relative
        if (Test-Path $bundled) { continue }
        $live = Join-Path $Root $relative
        try {
            Remove-Item -LiteralPath $live -Force -ErrorAction Stop
        } catch {
            Fail "Impossibile rimuovere il file applicativo obsoleto $relative. Chiudi eventuali editor/antivirus che lo bloccano e riprova."
        }
        if (Test-Path $live) {
            Fail "Pulizia file applicativo obsoleto non riuscita: $relative."
        }
        $removed += $relative
    }
    if ($removed.Count -gt 0) {
        Write-Ok ("Rimossi file applicativi obsoleti: " + ($removed -join ", "))
    }
}

function Repair-ReleasePayload([string]$Root) {
    $payloadRoot = Join-Path $Root "_release_payload"
    if (-not (Test-Path $payloadRoot)) { return }

    # Il payload non deve mai poter cambiare VERSION.txt a una release diversa.
    # Controlliamo la versione PRIMA di copiare qualsiasi file: in questo modo un
    # pacchetto costruito male viene bloccato senza trasformare una v268 in v266.
    $rootVersion = Read-PackageVersion $Root
    $payloadVersion = Read-PackageVersion $payloadRoot
    if ($rootVersion -le 0) { Fail "VERSION.txt della release non valido in $Root." }
    if ($payloadVersion -le 0) { Fail "VERSION.txt del payload auto-riparante non valido o assente." }
    if ($payloadVersion -ne $rootVersion) {
        Fail "Pacchetto release non coerente: VERSION.txt=$rootVersion ma _release_payload\VERSION.txt=$payloadVersion. Nessun file e' stato sincronizzato."
    }

    # Regola release v242+: la copia auto-riparante contiene TUTTO il codice Python
    # applicativo. Prima si eliminano eventuali .py rimasti da release precedenti,
    # poi si riallineano i file distribuiti. In questo modo l'estrazione sopra una
    # cartella esistente non produce installazioni miste.
    Remove-StaleApplicationCode $Root $payloadRoot

    $repaired = @()
    Get-ChildItem -Path $payloadRoot -File -Recurse -Force -ErrorAction SilentlyContinue |
        ForEach-Object {
            $relative = $_.FullName.Substring($payloadRoot.Length).TrimStart('\')
            $sourceFile = $_.FullName
            $liveFile = Join-Path $Root $relative
            if (-not (Same-FileHash $sourceFile $liveFile)) {
                $parent = Split-Path -Parent $liveFile
                New-Item -ItemType Directory -Force -Path $parent | Out-Null
                Copy-Item $sourceFile -Destination $liveFile -Force
                if (-not (Same-FileHash $sourceFile $liveFile)) {
                    Fail "Auto-riparazione non riuscita per $relative."
                }
                $repaired += $relative
            }
        }
    if ($repaired.Count -gt 0) {
        Write-Ok ("Auto-riparati file applicativi: " + ($repaired -join ", "))
    }

    Get-ChildItem -Path $Root -Directory -Filter "__pycache__" -Recurse -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Get-ChildItem -Path $Root -File -Include "*.pyc","*.pyo" -Recurse -Force -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

function Stop-TargetProcesses([string]$Root) {
    try {
        $running = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -and $_.CommandLine.Contains($Root)
        }
        foreach ($proc in $running) {
            try {
                Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop
                Write-Host "Chiuso Marketplace Hub precedente (PID $($proc.ProcessId))." -ForegroundColor DarkGray
            } catch {
                Write-Warn "Impossibile chiudere il processo $($proc.ProcessId): $($_.Exception.Message)"
            }
        }
    } catch {
        Write-Warn "Controllo processi non disponibile: $($_.Exception.Message)"
    }
}

function Backup-CriticalData([string]$Root) {
    if (-not (Test-Path $Root)) { return }
    $backupRoot = Join-Path $Root "data\backups\pre_auto_update_v242_$Stamp"
    $candidates = @(
        "data\marketplace_hub.db",
        "data\marketplace_hub.db-wal",
        "data\marketplace_hub.db-shm",
        "data\marketplace_hub.db-journal",
        "data\database.toml",
        ".streamlit\secrets.toml"
    )
    $present = @($candidates | Where-Object { Test-Path (Join-Path $Root $_) })
    if ($present.Count -eq 0) { return }
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    foreach ($relative in $present) {
        Copy-Item (Join-Path $Root $relative) -Destination $backupRoot -Force
    }
    Write-Ok "Backup preventivo dati critici: $backupRoot"
}

function Sync-ApplicationCode([string]$From, [string]$To) {
    New-Item -ItemType Directory -Force -Path $To | Out-Null
    $args = @(
        $From, $To,
        "/E", "/COPY:DAT", "/DCOPY:DAT", "/R:2", "/W:1", "/NFL", "/NDL", "/NP",
        "/XD", (Join-Path $From "data"), (Join-Path $From ".venv"), (Join-Path $From ".runtime"), (Join-Path $From "logs"), (Join-Path $From ".pytest_cache"),
        "/XF", "secrets.toml", "*.pyc", "*.pyo"
    )
    & robocopy @args | Out-Host
    $rc = $LASTEXITCODE
    if ($rc -ge 8) { Fail "Sincronizzazione automatica non riuscita (robocopy $rc)." }

    Get-ChildItem -Path $To -Directory -Filter "__pycache__" -Recurse -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Get-ChildItem -Path $To -File -Include "*.pyc","*.pyo" -Recurse -Force -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

function Verify-SynchronizedCode([string]$From, [string]$To) {
    $missing = @()
    foreach ($relative in @(Get-ApplicationCodeFiles $From)) {
        if (-not (Same-FileHash (Join-Path $From $relative) (Join-Path $To $relative))) {
            $missing += $relative
        }
    }
    if ($missing.Count -gt 0) {
        Fail ("Verifica automatica fallita. File applicativi non sincronizzati: " + ($missing -join ", "))
    }
}

function Test-PythonRuntime([string]$PythonExe) {
    if (-not $PythonExe -or -not (Test-Path $PythonExe)) { return $false }
    try {
        & $PythonExe -c "import sys, streamlit; print(sys.executable)" *> $null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

function Resolve-PythonFromLauncher([string]$Launcher, [string[]]$Arguments) {
    if (-not $Launcher -or -not (Test-Path $Launcher)) { return $null }
    try {
        $out = & $Launcher @Arguments -c "import sys, streamlit; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        $candidate = @($out | Where-Object { $_ -and $_.Trim() })[-1].Trim()
        if (Test-PythonRuntime $candidate) { return $candidate }
    } catch {}
    return $null
}

function Find-ExistingPython([string]$Root) {
    # 1) Riutilizza l'ambiente locale, se esiste gia'.
    $venvPython = Join-Path $Root ".venv\Scripts\python.exe"
    if (Test-PythonRuntime $venvPython) { return $venvPython }

    # 2) Preferisce il Python gia' installato sul PC. Marketplace Hub funzionava
    #    storicamente anche con il runtime utente/globale e non deve creare una
    #    nuova .venv solo perche' e' stato estratto un nuovo ZIP.
    foreach ($name in @("python.exe", "python3.exe")) {
        try {
            $cmd = Get-Command $name -ErrorAction SilentlyContinue
            if ($cmd -and (Test-PythonRuntime $cmd.Source)) { return $cmd.Source }
        } catch {}
    }

    # 3) Python Launcher for Windows: ricava il vero python.exe e poi lo usa
    #    direttamente, cosi' il resto dell'avvio non necessita argomenti speciali.
    try {
        $py = Get-Command "py.exe" -ErrorAction SilentlyContinue
        if ($py) {
            foreach ($args in @(@("-3.13"), @("-3"))) {
                $resolved = Resolve-PythonFromLauncher $py.Source $args
                if ($resolved) { return $resolved }
            }
        }
    } catch {}

    # 4) Percorsi Windows comuni, inclusa Python 3.13 usata dal progetto.
    $common = @(
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
        "C:\Python313\python.exe",
        "C:\Python312\python.exe",
        "C:\Program Files\Python313\python.exe",
        "C:\Program Files\Python312\python.exe"
    )
    foreach ($candidate in $common) {
        if (Test-PythonRuntime $candidate) { return $candidate }
    }
    return $null
}

function Ensure-Runtime([string]$Root) {
    $existing = Find-ExistingPython $Root
    if ($existing) {
        Write-Ok "Runtime Python gia' disponibile: $existing"
        return $existing
    }

    # Solo un PC che non possiede davvero un Python con Streamlit arriva qui.
    Write-Step "Prima configurazione automatica"
    Write-Host "Python/Streamlit non risultano installati sul PC. Marketplace Hub prepara il runtime una sola volta."
    $installer = Join-Path $Root "INSTALLA_MARKETPLACE_HUB.ps1"
    if (-not (Test-Path $installer)) { Fail "Installer completo non presente: $installer" }
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -NoLaunch
    if ($LASTEXITCODE -ne 0) { Fail "Preparazione automatica dell'ambiente non riuscita." }

    $prepared = Find-ExistingPython $Root
    if (-not $prepared) { Fail "L'installer e' terminato ma non e' disponibile alcun runtime Python con Streamlit." }
    return $prepared
}

try {
    $sourceVersion = Read-PackageVersion $Source
    if ($sourceVersion -le 0) { Fail "VERSION.txt del pacchetto non valido." }

    # Always repair the code of the folder being launched, even when Source == Target.
    # This prevents a mixed installation (new Packlink page + old packlink.py).
    Repair-ReleasePayload $Source

    $sameRoot = $Source.Equals($Target, [System.StringComparison]::OrdinalIgnoreCase)
    $launchRoot = $Source

    if (-not $sameRoot) {
        $targetVersion = Read-PackageVersion $Target
        $needsSync = $false

        if (-not (Test-Path $Target)) {
            $needsSync = $true
        } elseif ($targetVersion -lt $sourceVersion) {
            $needsSync = $true
        } elseif ($targetVersion -eq $sourceVersion) {
            # Regola di base release: a parita' di VERSION.txt non ci fidiamo del
            # numero versione. Confrontiamo TUTTO il codice applicativo. Questo
            # impedisce installazioni miste, ad esempio pagina Packlink nuova +
            # services\packlink_csv.py vecchio, anche quando entrambe risultano v240/v241.
            if (-not (Test-ApplicationCodeAligned $Source $Target)) {
                $needsSync = $true
            }
            if (-not $needsSync) {
                $targetApp = Join-Path $Target "app.py"
                if (-not (Test-Path $targetApp)) {
                    $needsSync = $true
                } else {
                    try {
                        $appText = Get-Content $targetApp -Raw
                        if ($appText -notmatch 'pages/4_Packlink_PRO\.py') { $needsSync = $true }
                    } catch {
                        $needsSync = $true
                    }
                }
            }
        }

        if ($targetVersion -gt $sourceVersion) {
            Write-Warn "Nel PC e' gia' installata una versione piu' recente (v$targetVersion). Non viene eseguito alcun downgrade."
        } elseif ($needsSync) {
            Write-Step "Aggiornamento automatico Marketplace Hub v$sourceVersion"
            Write-Host "Non devi eseguire alcun file di aggiornamento separato."
            Write-Host "Installazione: $Target"
            Stop-TargetProcesses $Target
            Backup-CriticalData $Target
            Sync-ApplicationCode $Source $Target
            Repair-ReleasePayload $Target
            Verify-SynchronizedCode $Source $Target
            Write-Ok "Codice aggiornato automaticamente alla v$sourceVersion"
            Write-Ok "data, database, Seller, ordini, tariffe, configurazioni e secrets.toml preservati"
        } else {
            Write-Ok "Marketplace Hub v$sourceVersion e' gia' allineato: nessun aggiornamento necessario"
        }
        $launchRoot = $Target
    }

    Repair-ReleasePayload $launchRoot
    New-Item -ItemType Directory -Force -Path (Join-Path $launchRoot "data") | Out-Null
    try { attrib -R (Join-Path $launchRoot "data\*") /S /D 2>$null | Out-Null } catch {}

    $python = Ensure-Runtime $launchRoot
    Write-Step "Avvio Marketplace Hub v$(Read-PackageVersion $launchRoot)"
    Push-Location $launchRoot
    try {
        & $python (Join-Path $launchRoot "launcher.py")
        $exitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    if ($exitCode -ne 0) { exit $exitCode }
    exit 0
} catch {
    Write-Host ""
    Write-Host "ERRORE AVVIO MARKETPLACE HUB" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "I dati dell'installazione non sono stati cancellati." -ForegroundColor Yellow
    exit 1
}
