# Marketplace Hub v242 — struttura pacchetto completo

Release gate: `tools/verify_release_consistency.py`.

## Conteggi
- `pages/`: 23 file
- `services/`: 47 file
- `tests/`: 78 file
- `tools/`: 13 file
- `_release_payload/`: 84 file Python auto-riparanti

## Funzione principale v242

- Inventario Kaufland persistente: le offerte già scaricate vengono caricate dal database.
- Stato Buy Box precedente visibile immediatamente nella griglia.
- Check rapido con una sola richiesta `/buybox` per offerta.
- Il controllo completo resta separato per costi, commissioni, logistica e prima inizializzazione.
- Il download inventario è secondario e non è richiesto per il normale check Buy Box.

## Regola di coerenza

`_release_payload` replica tutto il codice Python applicativo e il gate verifica gli hash prima della distribuzione.
