# Aggiornamento v107 — Kaufland e Worten

## Correzione della data di pagamento Kaufland

- La data di ricezione viene ora letta dal campo API dedicato
  `order_received_timestamp_iso`.
- Il programma non usa più `ts_updated_iso` come data di ricezione: questo
  timestamp può cambiare quando il ricavato è già stato reso disponibile.
- Il pagamento previsto viene calcolato una sola volta:
  `order_received_timestamp_iso + 14 giorni`.
- Esempio verificato: ricezione 07-07-2026, ricavato disponibile 21-07-2026.
  Il programma mostra 21-07-2026 e non aggiunge erroneamente altri 14 giorni
  fino al 04-08-2026.
- Le date errate salvate dalle versioni precedenti vengono corrette usando il
  payload API archiviato; alla successiva sincronizzazione vengono sostituite
  definitivamente nel database.
- Se Kaufland non restituisce la data di ricezione dedicata, la pagina indica
  che la data non è determinabile invece di usare un aggiornamento generico.

## Date di pagamento degli ordini selezionati

- Sotto i totali compare una riga per ogni unità selezionata con ordine,
  nazione, stato, data di ricezione, data prevista di pagamento, giorni
  rimanenti, netto da pagare e stato del pagamento.
- Le date sono mostrate nel formato italiano `gg-mm-aaaa`.
- Per gli ordini ricevuti la previsione resta fissata a 14 giorni dopo la data
  di ricezione memorizzata.
- Quando tutte le unità attive hanno una data nota, la pagina mostra:
  **Il blocco degli ordini selezionati sarà pagato del tutto entro la data
  gg-mm-aaaa.**
- La data finale del blocco è la più tarda tra le date previste degli ordini
  selezionati.
- Se almeno una data non è ancora calcolabile, la pagina indica quante unità
  sono in attesa e mostra separatamente l'ultima data già nota.
- Gli ordini cancellati vengono visualizzati come non dovuti e non incidono
  sulla data finale del blocco.

## Correzioni Ordini Kaufland

- Tutti gli importi originariamente in PLN e CZK vengono convertiti in EUR
  prima di essere mostrati nella tabella.
- Prezzo prodotto, spedizione, totale venduto, commissione e netto da ricevere
  sono sempre visualizzati ed esportati in euro.
- La valuta originaria resta disponibile in una colonna separata e nel relativo
  filtro.
- Anche il filtro per fascia di importo lavora sui valori già convertiti in
  euro.
- Selezione, totali e CSV sono limitati esclusivamente agli ordini compresi
  nell'intervallo di date e negli altri filtri correnti.
- Cambiando intervallo viene creata una nuova selezione del solo blocco visibile:
  gli ordini nascosti non continuano più a incidere sui totali.

## Funzioni confermate dalla v104

## Commissioni Worten per categoria

- Ogni offerta viene letta tramite OF21 con codice e nome della categoria
  effettivamente assegnata da Worten.
- Le tariffe correnti vengono richieste all'endpoint
  `platform-setting/commission/category`.
- La categoria dell'offerta viene collegata alla relativa percentuale; sono
  supportate sia griglie piatte sia alberi con commissione ereditata dalla
  categoria superiore.
- Priorità applicata: tariffa corrente della categoria, commissione effettiva
  ricavata dall'ordine, percentuale configurata come ultima riserva.
- La tabella Buy Box mostra codice categoria, nome categoria, percentuale e
  fonte usata nel calcolo.
- Gli ordini OR11 vengono interrogati soltanto per le offerte che non hanno una
  tariffa di categoria disponibile.

## Altre funzioni confermate

## Filtri e selezione ordini

- Selezione degli ordini per intervallo di date Da–A.
- Selezione per uno o più stati ordine e una o più nazioni.
- Nuovi filtri per stato pagamento, presenza tracking, commissione rilevata,
  valuta, corriere e fascia del totale venduto.
- Ricerca combinata per ordine, unità ordine, SKU, EAN, prodotto, corriere e
  tracking.
- Pulsanti per selezionare o deselezionare tutto il blocco filtrato.
- Totali e CSV restano sempre limitati al blocco attualmente filtrato.

## Correzione compatibilità

- Risolto `KeyError: 'commission_pct'` nella pagina Ordini Marketplace.
- Le righe archiviate con versioni precedenti vengono completate
  automaticamente con percentuale commissione, fonte, data di ricezione e
  conteggio pagamento.
- La pagina applica anche una protezione aggiuntiva quando su Windows sono
  presenti file aggiornati insieme a un vecchio database o a moduli non ancora
  ricaricati.

## Ordini

- Commissione effettiva letta dalla riga ordine Kaufland.
- Se il tenant non restituisce un campo commissione dedicato, il valore viene
  ricavato da `price - revenue_gross`, conservando la fonte del calcolo.
- Percentuale commissione calcolata sul totale pagato dal cliente, spedizione
  inclusa.
- Netto previsto calcolato come totale venduto meno commissione.
- Per lo stato `received` viene memorizzata la data di ricezione e calcolata la
  disponibilità stimata dopo 14 giorni.
- La tabella mostra data ricevuto, pagamento previsto, giorni rimanenti, stato
  pagamento, netto disponibile stimato e netto ancora in attesa.
- Corriere e tracking continuano a essere cercati nei dettagli API, importabili
  da CSV/XLSX e correggibili manualmente senza essere cancellati dal sync.

## Buy Box Kaufland

- Ultimo stato Buy Box sempre disponibile.
- Salvataggio di visioni nominate con data e ora.
- Selettore per riaprire qualsiasi visione salvata.
- Filtri, statistiche ed esportazione CSV disponibili anche sulle visioni
  storiche.
- Le visioni storiche sono in sola lettura per impedire aggiornamenti basati su
  prezzi non più attuali.
- Restano attive selezione multipla, colori verde/rosso/giallo, posizione senza
  decimali, modifica del solo `minimum_price`, aggiornamento del tempo di
  gestione e protezioni su perdita o margine inferiore al 10%.

## Aggiornamento

1. Chiudere il programma.
2. Conservare la cartella `data` dell'installazione in uso.
3. Sostituire i file del programma con quelli di questa versione.
4. Riavviare tramite `AVVIA_WINDOWS.bat`.

Il database viene aggiornato automaticamente al primo avvio senza cancellare i
dati esistenti.

## Verifica

La versione è stata controllata con compilazione completa e 135 test
automatici superati.
