# Marketplace Hub v265 — Prodotti più venduti e Top 10 Dashboard

## Nuova voce “Prodotti più venduti”
Nel menu laterale è stata aggiunta la pagina **Prodotti più venduti**, subito dopo **Ordini Marketplace**.

La pagina usa esclusivamente gli ordini già memorizzati in `accounting_order_lines`: non effettua nuove chiamate alle API dei marketplace e mantiene quindi la stessa velocità e la stessa base dati della Dashboard/Contabilità.

## Classifica e statistiche
La classifica può essere calcolata per:
- **Più venduti (quantità)**;
- **Maggior fatturato**;
- **Maggior margine**.

La quantità è la somma reale dei pezzi venduti: un ordine con quantità 4 vale **4 unità**, non 1 ordine.

Per ogni prodotto vengono mostrati, quando disponibili:
- posizione;
- nome prodotto, EAN e SKU composito;
- fornitore;
- unità vendute e numero ordini;
- fatturato e prezzo medio;
- costo acquisto;
- commissioni;
- importo da ricevere;
- costi extra;
- margine utile e margine percentuale;
- quota BEBOL e quota Seller;
- Seller, marketplace e Paesi coinvolti;
- confronto con il periodo precedente di pari durata su quantità, vendite e margine.

## Filtri
Sono disponibili filtri per:
- periodo: Giorno, Settimana corrente, Mese corrente, Intervallo personalizzato;
- Seller;
- Marketplace;
- Paese;
- Fornitore;
- ricerca libera per prodotto, EAN, SKU o fornitore.

## Dettaglio prodotto
Selezionando una riga si apre il dettaglio completo del prodotto con:
- KPI del prodotto;
- andamento giornaliero delle unità;
- andamento economico di vendite e margine;
- ripartizione per Seller;
- ripartizione per Marketplace;
- ripartizione per Paese;
- ripartizione per Fornitore;
- elenco degli ordini che contengono il prodotto.

La classifica è esportabile in CSV.

## Top 10 nella Dashboard
Nella Home/Dashboard è stato aggiunto un riquadro cliccabile **Top 10 prodotti più venduti**.

Il riquadro:
- segue esattamente il periodo selezionato nella Dashboard;
- mostra i primi 10 prodotti per quantità;
- mostra per ogni riga quantità, fatturato e margine;
- apre la nuova pagina **Prodotti più venduti** mantenendo il periodo selezionato.

## Coerenza economica
La nuova analisi riusa le stesse righe già elaborate dalla Dashboard, quindi mantiene:
- override manuali della Contabilità;
- trattamento economico di cancellati/rimborsati/no-stock;
- formule di margine;
- ripartizione BEBOL/Seller.

Le righe con vendita economicamente azzerata non aumentano le unità vendute. Se il margine non è determinabile per una o più righe, il prodotto viene indicato come **Da verificare** invece di mostrare falsamente margine zero.
