# Aggiornamento v195

## Correzione tabella operativa Buy Box con molti risultati

- Risolto l'errore Streamlit/Pandas Styler che bloccava la tabella quando il numero complessivo di celle superava `styler.render.max_elements`.
- La tabella Buy Box utilizza AgGrid, quando disponibile, con virtualizzazione, paginazione da 250 righe, filtri, ordinamento e selezione multipla.
- I colori restano applicati senza generare una cella HTML Pandas per ogni valore:
  - verde per Buy Box vinta o margine positivo;
  - rosso per Buy Box persa o risultato negativo;
  - giallo per margini bassi o situazioni da controllare.
- Il quadratino nell'intestazione seleziona tutte le righe filtrate nella griglia; le azioni continuano a lavorare sulle righe realmente selezionate.
- Quando AgGrid non è installato, Marketplace Hub usa automaticamente un fallback sicuro:
  - Styler soltanto sotto 250.000 celle;
  - DataFrame Streamlit non stilizzato oltre tale soglia, evitando l'eccezione.
- L'esportazione CSV continua a comprendere tutte le righe filtrate, non soltanto la pagina visualizzata.

## Compatibilità

La modifica non altera controlli API, calcoli Buy Box, prezzi, commissioni, margini o dati salvati. Cambia esclusivamente il rendering della tabella operativa.
