# Marketplace Hub v243 — struttura pacchetto completo

Release completa con cancellazione Kaufland basata sul set già scaricato e verificato, senza secondo download automatico.

## Struttura
- `pages/`: 24 file
- `services/`: 91 file
- `tests/`: 160 file
- `tools/`: 13 file
- `_release_payload/`: 84 file auto-riparanti

## Cancellazione Kaufland v243
- Il catalogo viene scaricato/verificato una sola volta su richiesta dell'utente.
- `Cancella tutto` usa direttamente gli `id_unit` dell'ultima fotografia persistente nel database.
- Nessun `_sync_selected()` viene eseguito nel blocco di cancellazione.
- Nessuna risincronizzazione automatica viene lanciata dopo i DELETE.
- I `404` sono trattati come unità già assenti e vengono rimossi dalla cache locale.
- Le cancellazioni restano parallele fino a 8 worker; Kaufland richiede comunque un DELETE per unità.

## Regola release
Il gate `tools/verify_release_consistency.py` deve risultare OK prima della distribuzione.
