# Aggiornamento v193 — Force Top BTP

- Riconoscimento dei nomi colonna reali dell'InventoryReport Force Top:
  `ERPID`, `ItemPartNumber`, `ItemEAN`, `Name`, `PriceNett`, `PriceSRP`,
  `AvailableQty`, `StockQty`, `ScheduledQty`.
- `ItemPartNumber` viene usato come SKU e `ItemEAN` come EAN.
- `PriceNett` viene usato come costo di acquisto netto.
- `AvailableQty` viene usato come disponibilità vendibile; `ScheduledQty` non
  viene sommato allo stock corrente.
- Normalizzazione CamelCase generalizzata per i feed BTP.
- Mantenuto il fallback su `ERPID`, `StockQty` e sugli alias già supportati.
- Aggiunti test con le intestazioni effettivamente restituite dal feed.

Verifica: 361 test e 6 subtest superati.
