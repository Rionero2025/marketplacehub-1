# Marketplace Hub v266 — Margine sempre visibile e verifica ordini dalla classifica prodotti

## Margine sempre visibile
Nella pagina **Prodotti più venduti** il margine non viene più sostituito da **Da verificare** quando soltanto alcune righe del periodo sono incomplete.

Da questa versione:
- il valore **Margine utile** mostra sempre la somma delle righe per cui il margine è già determinabile;
- le righe ancora incomplete restano escluse dalla somma finché non vengono corrette;
- l'avviso rimane visibile e specifica quanti **ordini** e quante **righe** devono ancora essere verificati;
- la percentuale di margine resta **Da verificare** finché il prodotto non è completamente valorizzato, perché calcolare una percentuale sul fatturato totale con costi mancanti sarebbe fuorviante;
- il ranking **Maggior margine** usa il margine attualmente determinabile invece di nascondere i prodotti incompleti.

La stessa logica viene usata anche dal riquadro **Top 10 prodotti più venduti** della Dashboard. Quando un prodotto contiene righe incomplete, il margine visibile è contrassegnato come parziale.

## Avviso cliccabile verso Contabilità
L'avviso della pagina **Prodotti più venduti** ora offre il pulsante:

**Apri X ordini da verificare in Contabilità →**

Il numero X conta gli ordini unici, non le singole righe prodotto.

Premendo il pulsante Marketplace Hub:
1. salva una coda di verifica con Seller, marketplace, account, numero ordine e righe interessate;
2. apre direttamente **Contabilità**;
3. seleziona automaticamente il Seller, il marketplace e l'account corretti;
4. mantiene lo stesso intervallo temporale della pagina Prodotti più venduti;
5. mostra in alto un editor rapido con gli ordini interessati;
6. consente di modificare direttamente Vendita, Acquisto, Commissione, Da ricevere, Costo extra, Fornitore, Prodotto ed EAN;
7. salva le modifiche con lo stesso motore di override manuale già usato dalla Contabilità;
8. ricalcola automaticamente il margine dopo il salvataggio.

Se gli ordini da verificare appartengono a più Seller/account, sono disponibili **Account precedente** e **Account successivo** per scorrere tutta la coda senza tornare alla classifica.

## Coerenza e sicurezza dati
- nessuna nuova chiamata API viene effettuata per costruire il margine o la coda di verifica;
- i dati continuano a provenire dalla cache `accounting_order_lines` già usata da Dashboard e Contabilità;
- le modifiche effettuate nell'editor rapido vengono salvate tramite `save_accounting_inline_edits` e restano persistenti;
- cancellati, rimborsati e righe economicamente azzerate continuano a non entrare nella classifica né nella coda di verifica.
