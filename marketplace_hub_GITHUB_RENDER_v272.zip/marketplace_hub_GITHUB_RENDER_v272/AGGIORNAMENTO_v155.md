# Marketplace Hub v155

## Tracciabilità: ordini già spediti separati e scadenze Worten esatte

### Tabella operativa

- Gli ordini già spediti non compaiono più nella tabella selezionabile.
- Sono considerati già spediti sia gli ordini con stato marketplace finale
  (`SHIPPED`, `RECEIVED`, `DELIVERED`, `CLOSED`) sia quelli già trasmessi con
  successo da Marketplace Hub.
- Gli ordini già spediti rimangono consultabili in una tabella separata e
  sola lettura denominata **Ordini già spediti**.
- Le vecchie selezioni Streamlit vengono ripulite automaticamente quando un
  ordine passa allo stato spedito.

### Scadenze Worten

- La pagina interroga OR11 soltanto per gli ordini presenti nel documento di
  tracking e legge il valore esatto `shipping_deadline`.
- La data viene visualizzata nel fuso operativo Worten `Europe/Lisbon`, con
  indicazione `WEST` o `WET`, come nel portale marketplace.
- Le stime calcolate da `leadtime_to_ship` non vengono più mostrate nella
  tabella operativa: se l'API non restituisce una scadenza esatta, viene
  indicato **Non disponibile**.
- Il valore dell'ordine (`raw_json.order.shipping_deadline`) ha priorità su
  eventuali campi omonimi presenti nelle righe prodotto.
- La stessa lettura aggiorna lo stato marketplace corrente, così un ordine già
  spedito viene spostato subito nella tabella storica.

### Prestazioni

La lettura OR11 è eseguita in blocchi fino a 100 ordini ed è memorizzata nella
sessione Streamlit. I rerun causati da filtri e selezioni non ripetono la
chiamata API.
