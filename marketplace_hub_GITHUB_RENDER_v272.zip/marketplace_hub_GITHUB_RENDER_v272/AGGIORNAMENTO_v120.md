# Aggiornamento v120 — Stati API e SKU Cecotec alfanumerici

- Corretto il filtro degli stati usando i codici reali restituiti dalle API dei marketplace.
- Worten/Mirakl:
  - `SHIPPING` = **In attesa di spedizione**;
  - `SHIPPED` = **Spedito**;
  - il filtro iniziale della pagina Cecotec seleziona `SHIPPING`.
- Kaufland:
  - `need_to_be_sent` = **In attesa di spedizione**;
  - `sent` e `sent_and_autopaid` = **Spedito**;
  - il filtro iniziale seleziona `need_to_be_sent`.
- La tabella mostra sia il label italiano sia il codice stato API, così è possibile verificare la corrispondenza.
- La cache ordini viene rimappata a ogni apertura: non è obbligatorio riscaricare gli ordini per vedere i label corretti.
- Corretto lo SKU Cecotec esportato:
  - SKU interamente numerico: viene garantito un solo zero iniziale (`1531` → `01531`);
  - SKU con una o più lettere: viene mantenuto identico, senza aggiungere lo zero (`A1234` → `A1234`, `12B34` → `12B34`).
- Aggiunti test specifici per SKU alfanumerici e generazione Excel.
