# Marketplace Hub v269 — struttura e garanzie

Release: **269**

## File modificati

- `pages/4_Packlink_PRO.py` — editor contatti destinatario, email/telefono predefiniti e applicazione alle bozze/CSV;
- `services/catalog_intelligence/__init__.py` — versione release allineata a 269;
- `tests/test_packlink_recipient_contacts_v269.py` — regressioni della nuova gestione contatti;
- `VERSION.txt` — release 269;
- `_release_payload/VERSION.txt` — payload auto-riparante allineato a 269.

## Garanzie

- un ordine con email mancante può essere completato direttamente nella pagina Packlink;
- email e telefono predefiniti possono essere applicati in massa soltanto ai dati mancanti;
- il contatto specifico del singolo ordine ha priorità sul valore predefinito;
- i contatti effettivi vengono usati sia dal CSV sia dalla creazione bozza;
- il fallback del telefono mittente rimane disponibile quando nessun telefono destinatario/default è stato inserito;
- nessuna cancellazione o riscrittura dei dati ordine originali nel database marketplace.
