# Marketplace Hub v258 — struttura e garanzie

Release: **258**

## Evoluzione principale
Catalog Intelligence dispone ora di un livello AI vincolato alla tassonomia e ai dati sorgente reali. L'AI supporta categorie in REVIEW e attributi obbligatori mancanti, ma il validatore deterministico resta l'autorità finale prima della pubblicazione.

## File applicativi principali modificati
- `app.py`
- `pages/2_Provider_IA.py`
- `pages/3_Creazione_Prodotti.py`
- `services/ai_providers.py`
- `services/catalog_intelligence/__init__.py`
- `services/catalog_intelligence/schema.py`
- `services/catalog_intelligence/feed.py`
- `services/catalog_intelligence/workflow.py`
- `services/catalog_intelligence/ai_enrichment.py` (nuovo)
- `tools/verify_release_consistency.py`

## Nuovo servizio AI Catalog Intelligence
`services/catalog_intelligence/ai_enrichment.py` contiene:
- estrazione di evidence path addressable dal record sorgente;
- schema strutturato per scelta categoria;
- schema strutturato per mapping attributi;
- allow-list categorie candidate ufficiali;
- verifica obbligatoria dell'evidence path;
- persistenza run/risultati/mapping;
- riuso dei mapping accettati.

## Database
Nuove tabelle, compatibili con il layer SQLite/PostgreSQL esistente:
- `catalog_ai_runs`
- `catalog_ai_product_results`
- `product_ai_attribute_mappings`

Nuova revisione schema Catalog Intelligence: **258**.

## Creazione Prodotti
Flusso operativo:
1. sincronizzazione tassonomia ufficiale;
2. normalizzazione e snapshot del catalogo fornitore;
3. classificazione deterministica per prodotto;
4. AI opzionale per le sole categorie rimaste in REVIEW;
5. caricamento attributi ufficiali della categoria;
6. mapping deterministico;
7. AI opzionale per soli attributi obbligatori ancora mancanti;
8. validazione deterministica completa;
9. anteprima/preparazione persistente;
10. pubblicazione controllata prodotto + offerta.

## Provider IA
La pagina `Provider IA` è inclusa in `app.py`. I profili sono legati al Seller e riutilizzano il sistema di cifratura delle credenziali. Catalog Intelligence non memorizza chiavi in chiaro nei propri run.

## Test specifici v258
- `tests/test_catalog_ai_v258.py`
  - creazione schema AI;
  - rifiuto categoria inventata/fuori allow-list;
  - auto-approvazione categoria ufficiale ad alta confidence;
  - mapping attributo solo con evidence path reale;
  - persistenza del mapping AI;
  - passaggio finale attraverso il validatore deterministico.

Sono inoltre rieseguiti i test Catalog Intelligence v244-v252 e i test `ai_providers`.

## Contratti preservati
- distribuzione: `marketplace_hub.zip`
- avvio: estrai → `AVVIA_WINDOWS.bat`
- auto-riparazione dal `_release_payload`
- protezione anti-downgrade
- preservazione `data`, database, Seller, ordini, storico e configurazioni
- preservazione credenziali e `.streamlit/secrets.toml`
- riuso `.venv`/Python esistenti quando disponibili
- Packlink v255 e Contabilità v257 non alterati
