# Marketplace Hub v209 — Rubrica indirizzi mittente Packlink PRO

## Nuova funzione
La pagina **Packlink PRO** dispone ora di una rubrica persistente degli indirizzi mittente per ogni Seller.

### Registra indirizzo mittente
Nella sezione **1. Configurazione Packlink PRO → Indirizzo mittente** è presente la voce **Registra indirizzo mittente**.

Per ogni sede vengono memorizzati nel database:

- nome/alias della sede;
- nome e cognome del contatto;
- società;
- indirizzo e indirizzo aggiuntivo;
- CAP;
- città;
- Paese ISO 2;
- telefono;
- email.

Gli indirizzi sono separati per Seller e non vengono salvati nella sessione del browser.

### Più indirizzi e scelta con radio button
È possibile registrare più sedi di partenza. Le sedi attive vengono mostrate con un **radio button** e una sola sede viene usata come origine per le tariffe e per la bozza Packlink dell'ordine.

La pagina ricorda anche l'ultima sede selezionata. È inoltre possibile indicare una sede come **predefinita**.

### Gestione indirizzi
Per l'indirizzo selezionato sono disponibili:

- **Imposta come predefinito**;
- **Modifica indirizzo mittente selezionato**;
- **Elimina indirizzo selezionato**, con conferma.

La cancellazione è logica: lo storico resta preservato nel database.

### Tariffe sempre coerenti con il mittente
La cache delle tariffe Packlink è ora separata per:

- indirizzo mittente selezionato;
- pacco selezionato.

Cambiando mittente o pacco, Marketplace Hub non riutilizza quindi tariffe calcolate per un'origine diversa.

## Database
Viene creata automaticamente la tabella `packlink_sender_addresses`, compatibile con SQLite e PostgreSQL. Non è richiesta alcuna migrazione manuale.

## Compatibilità
Se non è stato ancora registrato un indirizzo locale, resta disponibile temporaneamente il vecchio fallback ai magazzini restituiti da Packlink o ai campi manuali. Per la creazione affidabile delle bozze è consigliato registrare la sede completa nella nuova rubrica.

## Verifiche
- compilazione Python completa;
- test specifici della rubrica mittenti;
- test completo del progetto: **401 test superati + 6 subtest**;
- prova CRUD SQLite: creazione di più sedi, cambio predefinita e cancellazione con riassegnazione automatica della sede predefinita.
