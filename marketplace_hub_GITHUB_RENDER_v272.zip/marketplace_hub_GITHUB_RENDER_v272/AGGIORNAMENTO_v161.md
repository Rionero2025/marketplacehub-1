# Marketplace Hub v161

## Cecotec WAITING LABEL con tracking già assegnato

Per le spedizioni Cecotec, una riga nello stato **WAITING LABEL** o **CREATED**
può ora essere inviata al marketplace quando sono già presenti entrambi:

- numero di tracking;
- corriere.

La regola vale sugli ordini ancora spedibili del marketplace, ad esempio
`SHIPPING` su Worten e `NEED_TO_BE_SENT` su Kaufland.

La tabella mostra:

- stato file: `WAITING LABEL · tracking disponibile`;
- stato operativo: `Pronta per l'invio`;
- invio consentito: `Sì`.

Restano bloccati:

- WAITING LABEL senza tracking;
- WAITING LABEL senza corriere;
- più tracking differenti sullo stesso ordine;
- ordini annullati, rimborsati o già spediti;
- WAITING LABEL di fornitori diversi da Cecotec, salvo future regole dedicate.
