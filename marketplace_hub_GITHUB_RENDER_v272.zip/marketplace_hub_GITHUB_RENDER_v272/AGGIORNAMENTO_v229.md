# Marketplace Hub v229 — Packlink PRO: warehouse ufficiale e Paese correttamente selezionato

## Problema corretto
Le bozze create via API potevano comparire in Packlink PRO come **INCOMPLETE** anche quando il testo del Paese (es. `Italia`) e la località erano visibili. Il portale mostrava il campo Paese in rosso perché il mittente non era collegato al vero warehouse Packlink usato dal flusso e-commerce ufficiale.

## Allineamento al core ufficiale Packlink
La v229 segue il flusso del `OrderService` Packlink:

- gli indirizzi Packlink vengono letti da `GET /v1/clients/warehouses`;
- il mittente usa i campi canonici del warehouse Packlink;
- `additional_data.selectedWarehouseId` contiene il vero ID del warehouse restituito da Packlink;
- `from.country` e `to.country` restano codici ISO-2 (`IT`, `DE`, `FR`, ...);
- `from.zip_code`, `from.city`, `to.zip_code` e `to.city` vengono inviati nel normale Address DTO;
- non vengono più forzati `postal_zone_id_*` / `zip_code_id_*` prima del POST.

## Mittente Marketplace Hub
Se il mittente registrato localmente coincide con un warehouse Packlink (Paese, CAP e indirizzo/località), il collegamento è automatico. Il programma memorizza il warehouse ID associato.

Se non esiste una corrispondenza affidabile, la creazione viene bloccata prima del POST. È disponibile una selezione una-tantum del warehouse Packlink corretto; l'associazione viene poi ricordata.

## Funzioni preservate
Restano attive tutte le funzioni precedenti, incluse:

- memoria pacco/peso/dimensioni per ordine;
- memoria tariffa/corriere/servizio/service_id/costo storico;
- rigenerazione massiva senza riquotare gli ordini con tariffa storica valida;
- recupero completo indirizzi Kaufland/Worten;
- nessuna checkbox di conferma ridondante prima della creazione.
