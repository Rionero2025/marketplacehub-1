@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - Verifica installazione
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv assente. Avvio l'installazione completa...
  call "%~dp0INSTALLA_TUTTO_WINDOWS.bat"
  exit /b %errorlevel%
)
set "PATH=C:\Program Files\Tesseract-OCR;%PATH%"
".venv\Scripts\python.exe" "tools\verify_runtime.py"
set RC=%errorlevel%
echo.
if not "%RC%"=="0" echo Verifica NON superata. Esegui RIPARA_INSTALLAZIONE_WINDOWS.bat
if "%RC%"=="0" echo Verifica superata: Marketplace Hub e' pronto.
pause
exit /b %RC%
