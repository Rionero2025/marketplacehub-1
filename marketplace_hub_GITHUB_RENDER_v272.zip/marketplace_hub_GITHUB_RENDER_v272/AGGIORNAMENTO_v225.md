# Marketplace Hub v225 — Packlink senza conferma ridondante

## Modifica operativa
La pagina Packlink PRO non richiede più la checkbox aggiuntiva di conferma prima di creare una spedizione pronta per il pagamento.

Dopo aver scelto il corriere/servizio, il pulsante **Crea spedizione pronta per pagamento Packlink** è immediatamente utilizzabile.

La stessa semplificazione vale per la creazione massiva: se gli ordini hanno già una tariffa valida (scelta manualmente o ripristinata dalla memoria di rigenerazione), il pulsante massivo è subito disponibile.

## Controlli che restano attivi
Restano invariati i controlli tecnici necessari: servizio/tariffa presente, dati ordine, pacco, peso/dimensioni, validazione payload e risposta API Packlink.

## Memoria rigenerazione
Restano memorizzati per singolo ordine pacco, peso/dimensioni, corriere, servizio, service_id, costo tariffa e valore dichiarato. La rigenerazione massiva continua a ripristinare automaticamente le scelte precedenti.
