# Marketplace Hub v262 — struttura e garanzie

Release: **262**

## File nuovi
- `pages/4_Ordini_INNPRO.py` — UI selezione/sincronizzazione/esportazione ordini INNPRO;
- `services/innpro_orders.py` — parsing SKU, validazione EAN-13, aggregazione quantità e CSV;
- `tests/test_innpro_orders_v262.py` — test del nuovo flusso;
- `AGGIORNAMENTO_v262.md`.

## File aggiornati
- `app.py` — nuova voce **Creazione Ordini INNPRO**;
- `VERSION.txt` — release 262;
- `services/catalog_intelligence/__init__.py` — allineamento release.

## Contratto file INNPRO
- CSV senza intestazione;
- separatore `;`;
- terminatore riga CRLF;
- prima colonna EAN-13;
- seconda colonna quantità intera;
- EAN duplicati accorpati con somma quantità;
- righe non INNPRO o EAN non validi escluse con motivazione visibile.

## Regole release preservate
- ZIP finale sempre `marketplace_hub.zip`;
- avvio esclusivamente con `AVVIA_WINDOWS.bat` dopo estrazione;
- `_release_payload` allineato al codice live;
- protezione anti-downgrade;
- dati, credenziali e `.venv` preservati durante gli aggiornamenti ordinari.
