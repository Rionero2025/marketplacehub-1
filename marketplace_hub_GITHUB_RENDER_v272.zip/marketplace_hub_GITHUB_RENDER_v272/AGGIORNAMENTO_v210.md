# Marketplace Hub v210 — Packlink PRO Draft API

## Motivo dell'aggiornamento

La creazione della bozza Packlink poteva restituire HTTP 400 `Bad Request` anche dopo la selezione corretta di mittente, pacco e servizio.

La v210 riallinea il payload di `POST /v1/shipments` al DTO `Draft` utilizzato dal core ufficiale Packlink per le integrazioni e-commerce.

## Correzioni API

1. `content` viene inviato come stringa, non come array JSON.
   - Le descrizioni dei prodotti vengono unite con `, `.
   - Vengono rimossi i caratteri vietati dal DTO Packlink.
   - Il contenuto viene limitato a 60 caratteri.

2. `collection_date` e `collection_time` non vengono più inventati.
   - Il core ufficiale Packlink può creare il Draft lasciando questi campi null.
   - Rimane disponibile la normalizzazione delle finestre `available_dates` per diagnostica/UI (`[09:00 , 18:00]` -> `09:00-18:00`).

3. `additional_data.selectedWarehouseId` non riceve più l'ID locale Marketplace Hub.
   - Packlink usa questo campo per l'ID di un warehouse Packlink.
   - Gli indirizzi mittente registrati localmente continuano a essere inviati nel blocco `from`.
   - `additional_data` viene omesso finché non esiste un vero ID warehouse Packlink associato.

4. `user_id` e `client_id` non vengono più ricavati dal generico campo `id` restituito da `/clients`.
   - Sono valorizzati solo se esistono identificatori espliciti.
   - In caso contrario restano null, come consentito dal DTO ufficiale.

5. La valuta del contenuto segue la valuta del servizio selezionato (con fallback all'ordine/EUR).

6. Migliorato il parsing degli errori Packlink.
   - `{"messages":[{"message":"Bad Request"}]}` viene mostrato come `Bad Request` anziché come JSON grezzo.

7. In caso di errore API viene mostrata una diagnostica privacy-safe della richiesta:
   - service_id, carrier, servizio;
   - source/platform;
   - presenza di user/client id;
   - paese/CAP e completezza dei campi indirizzo senza mostrare PII complete;
   - pacco;
   - tipo/lunghezza contenuto;
   - valuta e valore dichiarato;
   - presenza/assenza additional_data.

## Compatibilità

- SQLite: invariata.
- PostgreSQL: invariata.
- Rubrica mittenti v209: mantenuta.
- Selezione ordini/tariffe/bozze v207-v209: mantenuta.
- Nessuna modifica o cancellazione della cartella `data` o delle credenziali.

## Verifiche

Suite completa: 405 test superati + 6 subtest.
Compilazione Python completa: OK.

La chiamata reale a Packlink deve essere verificata con la API key dell'account del Seller; Marketplace Hub non memorizza o include chiavi API nei pacchetti distribuiti.
