# Marketplace Hub v157

## Visualizzazione completa degli ordini nella Tracciabilità

La pagina **Tracciabilità ordini** mostra ora anche gli ordini che non hanno ancora
un numero di tracking quando viene selezionato **Visualizza tutti gli ordini**.

La tabella operativa contiene quindi, per il fornitore selezionato e nel periodo
scelto:

- ordini con tracking e corriere pronti per l'invio API;
- ordini presenti nel file del fornitore ma ancora in `WAITING LABEL`, `CREATED`
  o altro stato di attesa;
- ordini presenti sul marketplace ma non ancora comparsi in alcun file spedizioni;
- ordini con tracking incompleto o ancora da verificare.

Gli ordini senza tracking sono indicati come **In attesa di tracciabilità**, non
sono selezionati come inviabili e riportano il motivo del blocco. Le scadenze di
spedizione continuano a essere lette dall'API e restano utilizzabili per i filtri
urgenti, scaduti e per intervallo date.

È stato aggiunto anche il filtro dedicato **In attesa di tracciabilità**.
Gli ordini già spediti continuano a non comparire nella tabella operativa e
restano consultabili soltanto nella tabella storica separata.
