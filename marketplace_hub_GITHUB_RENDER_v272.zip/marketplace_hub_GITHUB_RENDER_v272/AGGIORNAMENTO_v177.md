# Marketplace Hub v177

## Correzione HTTP 429 e verifica live degli ordini nei Ticket

### Ordini Cecotec e Tracciabilità

- Le verifiche Kaufland non eseguono più una raffica di una richiesta per ogni riga selezionata.
- Le unità operative vengono prima risolte in blocco tramite gli elenchi paginati `need_to_be_sent` e `open`.
- Le richieste di dettaglio vengono effettuate soltanto per le unità non risolte in blocco.
- Gli stati restano memorizzati per cinque minuti durante i rerun di Streamlit.
- Un limitatore condiviso distribuisce le richieste di tutti i client Kaufland dello stesso Seller.
- In caso di HTTP 429 il programma applica un backoff più lungo, interrompe la raffica e non continua a richiamare inutilmente tutte le righe successive.
- Il pulsante di aggiornamento manuale forza comunque una nuova lettura API.

### Ticket e messaggi

- I dati dell'ordine collegato al ticket vengono verificati live tramite API.
- La console mostra stato API attuale, macro-stato, spedito, cancellato, reso e motivazione.
- La verifica utilizza anche le order unit salvate dal sincronizzatore ticket Kaufland quando l'ordine non è ancora presente in Contabilità.
- Il suggerimento IA riceve gli stati live dell'ordine.
- Prima delle risposte automatiche IA viene eseguita una nuova verifica dell'ordine.
- Se la verifica live non riesce, la risposta automatica viene bloccata e rimane soltanto la bozza per il controllo umano.
