# Dipendenze runtime Marketplace Hub v222

## Python

- Runtime previsto: **Python 3.13 x64** (ARM64 gestito dal bootstrap quando necessario).
- Ambiente applicativo: `.venv` locale alla cartella Marketplace Hub.
- Il sistema Python globale non viene usato per l'avvio normale dopo l'installazione.

## Pacchetti Python applicativi

L'installer legge `requirements-installer.txt`, che include `requirements.txt` e `pytest` per la diagnostica.

| Pacchetto | Funzione principale nel progetto |
|---|---|
| Streamlit | interfaccia web locale |
| pandas | tabelle, ordini, listini, contabilità |
| openpyxl / XlsxWriter / xlrd / xlwt | Excel XLSX/XLS |
| lxml | parsing XML fornitori |
| cryptography | cifratura credenziali |
| requests | API HTTP marketplace/fornitori |
| streamlit-aggrid | griglie con selezione multipla |
| Pillow | immagini e screenshot |
| pytesseract | binding Python OCR |
| PyMuPDF / pypdf | PDF, testo e rendering pagine |
| openai | connettore AI opzionale |
| streamlit-quill2 | editor WYSIWYG |
| boto3 | integrazioni AWS/S3 dove configurate |
| truststore | trust store TLS Windows |
| reportlab | generazione PDF contabili |
| psycopg[binary,pool] | PostgreSQL e pool connessioni |
| pytest | test/diagnostica del pacchetto |

## Componenti di sistema

### Tesseract OCR
Necessario per leggere screenshot e PDF scansiti. L'installer prova prima WinGet e poi verifica l'eseguibile. Sono installati/verificati i language pack ENG; ITA e POR sono aggiunti automaticamente quando possibile.

### Microsoft Visual C++ Runtime
Su Windows x64 l'installer tenta di verificare/installare il runtime 2015-2022 tramite WinGet. È un prerequisito comune di componenti Python binari su Windows.

### PostgreSQL
Opzionale. Marketplace Hub continua a funzionare con SQLite. Se il Seller decide di usare PostgreSQL, restano disponibili gli script di configurazione e migrazione del progetto.

## Diagnostica

`tools/verify_runtime.py` controlla:

- Python 3.13;
- import di tutte le librerie fondamentali;
- scrittura nella cartella `data`;
- disponibilità del database configurato;
- Tesseract e language pack OCR;
- compilazione dei moduli `services` e `pages`.

`ESEGUI_TEST_COMPLETI_WINDOWS.bat` esegue l'intera suite di test del progetto con `PYTHONPATH` corretto.
