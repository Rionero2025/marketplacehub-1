# Marketplace Hub v252 — Catalog Intelligence: ingest rapido e full feed reale

- Ripristino automatico dei campi completi del listino fornitore nelle vecchie viste salvate: brand/producer, descrizioni, immagini, documenti e parametri.
- Salvataggio Catalog Intelligence a basso numero di scritture: raw supplier record una sola volta, canonical JSON compatto e marker cache leggero.
- Provenienza compatta ricostruibile on-demand.
- Batch di salvataggio da 1200 prodotti e progressione reale.
- Griglia Catalogo sorgente con Marca, Descrizione, URL immagine principale e numero immagini.
- Mantiene WAL/busy timeout/guard schema della v251.
