@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\verify_package_v248.py
) else (
  python tools\verify_package_v248.py
)
if errorlevel 1 (
  echo.
  echo VERIFICA V248 FALLITA.
  pause
  exit /b 1
)
echo.
echo VERIFICA V248 COMPLETATA.
pause
