# Marketplace Hub v251 — struttura e garanzie

Release incrementale completa costruita sulla baseline v243 e sulle funzioni Catalog Intelligence v244-v250.

## Componenti
- pagine Streamlit: 24
- servizi Python: 65
- strumenti Python: 20
- file Python applicativi principali (app + launcher + pagine + servizi + tools): 112
- test automatici: 90+

## Correzione v251
La v251 introduce un modello di inizializzazione schema process-scoped per evitare DDL ripetuto durante i rerun Streamlit. Il database SQLite rimane in WAL e le letture possono proseguire mentre Catalog Intelligence salva batch; il bootstrap non compete più per il writer lock dopo la prima inizializzazione riuscita.

## Auto-riparazione
Tutto il codice Python applicativo rimane duplicato in `_release_payload` e viene verificato dal gate di coerenza prima della distribuzione.

## Distribuzione
Il file distribuito deve chiamarsi sempre `marketplace_hub.zip`.
Flusso utente: estrai -> `AVVIA_WINDOWS.bat`.
Nessuna installazione/aggiornamento manuale separato.
