# Marketplace Hub v247 — correzione schema categorie Kaufland

## Problema corretto

Durante **Creazione Prodotti → Prepara feed**, il caricamento degli attributi ufficiali della categoria Kaufland poteva terminare con:

`CATEGORY_SCHEMA_LOAD_FAILED` / `HTTP 400 validation-error`

Il prodotto rimaneva quindi con payload prodotto e offerta vuoti, anche quando la categoria assegnata era valida e presente nella tassonomia memorizzata.

## Causa

L'endpoint Kaufland `GET /categories/{id_category}` richiede ogni opzione `embedded` come parametro query ripetuto:

```text
?embedded=optional_attributes
&embedded=required_attributes
&embedded=conditional_attributes
&storefront=de
```

La versione precedente inviava invece un unico valore separato da virgole. Il server interpretava tale valore come un'opzione inesistente e rispondeva HTTP 400.

## Correzione

La v247:

1. codifica le query multi-valore con `urlencode(..., doseq=True)`;
2. invia `optional_attributes`, `required_attributes` e `conditional_attributes` come tre parametri `embedded` distinti;
3. non aggiunge il parametro `locale` al dettaglio categoria, perché lo schema è richiesto per storefront;
4. mantiene un retry compatibile senza `conditional_attributes` esclusivamente dopo un HTTP 400, per eventuali ambienti playground o varianti endpoint meno recenti;
5. continua a salvare gli attributi nel database dopo il primo caricamento riuscito, senza riscaricarli per i prodotti successivi della stessa categoria e dello stesso snapshot;
6. lascia in stato bloccato il prodotto solo quando anche la richiesta ufficiale corretta fallisce realmente.

## Prevenzione della regressione

Sono stati aggiunti:

- test sulla categoria reale di esempio `16651`;
- test dell'URL finale con tre parametri `embedded` distinti;
- test del fallback compatibile;
- controllo statico nel gate obbligatorio della release;
- verifica che la vecchia forma separata da virgole non possa essere distribuita;
- copia auto-riparante allineata in `_release_payload`.

## Dati preservati

La correzione non modifica né elimina:

- tassonomie già sincronizzate;
- categorie assegnate;
- feed sorgente;
- job di pubblicazione;
- Seller e account;
- credenziali;
- listini;
- database SQLite/PostgreSQL;
- funzioni consolidate dalla pietra miliare v243.

Gli enrichment precedentemente salvati come `FAILED` vengono riprovati automaticamente con la richiesta corretta alla successiva preparazione del feed.
