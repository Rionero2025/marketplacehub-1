# Marketplace Hub v246 — struttura del pacchetto completo

La v246 parte dalla pietra miliare v243, preserva Catalog Intelligence v244/v245 e aggiunge la pubblicazione reale controllata, persistente e idempotente su Kaufland e Worten/Mirakl.

## Struttura Python

- `pages/`: 24 file Python
- `services/`: 65 file Python
- `services/catalog_intelligence/`: 19 file Python
- `tests/`: 82 file Python
- `tools/`: 16 file Python
- `_release_payload/`: 107 file Python auto-riparanti
- codice applicativo controllato dal gate: 107 file Python

## Pagina dedicata

- `pages/3_Creazione_Prodotti.py`

La pagina è divisa in:

1. Account e tassonomia;
2. Catalogo sorgente;
3. Determina categorie;
4. Prepara feed;
5. Pubblicazione;
6. Storico.

## Servizi Catalog Intelligence

### Fondazione e preparazione preservate

- `services/catalog_intelligence/schema.py`
- `services/catalog_intelligence/models.py`
- `services/catalog_intelligence/utils.py`
- `services/catalog_intelligence/accounts.py`
- `services/catalog_intelligence/capabilities.py`
- `services/catalog_intelligence/taxonomy.py`
- `services/catalog_intelligence/normalization.py`
- `services/catalog_intelligence/mapping.py`
- `services/catalog_intelligence/validation.py`
- `services/catalog_intelligence/repository.py`
- `services/catalog_intelligence/category_classifier.py`
- `services/catalog_intelligence/category_schema.py`
- `services/catalog_intelligence/feed.py`
- `services/catalog_intelligence/workflow.py`
- `services/catalog_intelligence/marketplaces/kaufland.py`
- `services/catalog_intelligence/marketplaces/mirakl.py`

### Nuovo motore v246

- `services/catalog_intelligence/publication.py`

## Funzioni v246

1. controllo anti-duplicato EAN/SKU e stato locale già memorizzato;
2. pianificazione per singolo prodotto;
3. idempotenza basata su account, canale, prodotto, payload e operazione;
4. modalità Simulazione senza scritture remote;
5. modalità Reale sbloccata esplicitamente per ciascun ciclo;
6. scrittura delle credenziali vietata nelle impostazioni del job;
7. creazione/aggiornamento product data Kaufland;
8. polling dello stato prodotto Kaufland;
9. creazione unit/offerta Kaufland dopo l'accettazione del prodotto;
10. aggiornamento offerta esistente Kaufland tramite PATCH;
11. generazione CSV prodotto Mirakl UTF-8 BOM;
12. import prodotto P41 e polling P42;
13. acquisizione dei report Mirakl disponibili;
14. generazione CSV offerta separato;
15. import offerta OF01, polling e report errori;
16. artefatti e payload scaricabili;
17. eventi persistenti per prodotto;
18. retry selettivo degli errori temporanei;
19. riapertura del solo item quando cambia l'hash del feed;
20. nessun refresh implicito della tassonomia durante la pubblicazione;
21. ripresa del job dopo la chiusura del programma;
22. aggiornamento dello stato prodotto/offerta per canale.

## Nuove tabelle v246

- `publication_item_runtime`
- `publication_item_events`
- `product_channel_states`
- `publication_artifacts`

Le tabelle estendono le strutture `publication_jobs`, `publication_items` e `marketplace_imports` già introdotte dalla fondazione Catalog Intelligence. Le migrazioni sono additive e idempotenti.

## Client marketplace estesi

### Kaufland

`services/kaufland.py` include ora:

- ricerca prodotto tollerante all'assenza;
- lettura VAT indicator;
- aggiornamento unit tramite PATCH con rimozione dei campi immutabili.

### Worten/Mirakl

`services/catalog_intelligence/marketplaces/mirakl.py` include ora:

- richieste JSON e byte generiche;
- controllo prodotto/offerta;
- import prodotto e offerta;
- polling;
- download report;
- gestione esplicita dello status HTTP;
- compatibilità controllata con due forme di import soltanto in caso di rifiuto 400/422.

## Compatibilità e preservazione

- SQLite: sì;
- PostgreSQL: coperto dalla suite automatica e dal layer DDL esistente;
- tabelle precedenti: non eliminate;
- `data`, database, Seller, account, ordini, storico, credenziali e configurazioni: preservati;
- avvio: soltanto `AVVIA_WINDOWS.bat`;
- anti-downgrade e auto-riparazione codice: mantenuti;
- Packlink, Buy Box, cancellazione, Cecotec, ordini, contabilità e tracciabilità v243: preservati;
- tassonomia cached-first e feed completi v245: preservati.

## Gate della release

La distribuzione viene bloccata se manca o non è allineato:

- un import locale;
- un simbolo pagina-servizio;
- il motore `publication.py`;
- una funzione richiesta dalla pagina;
- la voce Creazione Prodotti nel menu;
- la versione Catalog Intelligence rispetto a `VERSION.txt`;
- la copia identica del codice in `_release_payload`;
- il manifesto SHA-256;
- l'assenza di cache Python.
