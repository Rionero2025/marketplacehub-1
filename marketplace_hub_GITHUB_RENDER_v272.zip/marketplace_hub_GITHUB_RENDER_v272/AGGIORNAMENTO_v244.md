# Marketplace Hub v244 — Catalog Intelligence: prima fondazione operativa

## Obiettivo
La v244 avvia lo sviluppo della nuova area **Creazione Prodotti** senza modificare o rimuovere le funzioni consolidate della pietra miliare v243.

La nuova area prepara il catalogo del fornitore secondo la tassonomia ufficiale dell'account marketplace selezionato. In questa prima tranche la scrittura remota è deliberatamente disabilitata: Marketplace Hub sincronizza, normalizza, conserva la provenienza, valida e crea job persistenti, ma non può ancora pubblicare un prodotto senza i successivi moduli payload/pubblicazione specifici del canale.

## Nuova voce di menu
È stata aggiunta la pagina:

- `pages/3_Creazione_Prodotti.py`

La pagina consente di scegliere:

1. Seller;
2. account Kaufland o Worten collegato;
3. ambiente/storefront/locale o gerarchia;
4. tassonomia ufficiale;
5. fornitore, listino e vista salvata;
6. categoria foglia di destinazione.

## Funzioni operative introdotte

### Capability discovery in sola lettura
- verifica credenziali e capacità dell'account;
- non crea prodotti, offerte o import durante il controllo;
- memorizza l'esito per Seller, account e ambiente.

### Taxonomy Engine
- Kaufland: storefront, locale, categorie, attributi generali e attributi di categoria;
- Worten/Mirakl: gerarchie, attributi prodotto e value list;
- snapshot immutabili con hash;
- riutilizzo dello snapshot quando il contenuto non cambia;
- categorie, attributi, valori ammessi, condizioni e locali salvati nel database.

### Modello prodotto normalizzato
- normalizzazione di EAN, SKU, marca, modello, titolo e descrizione;
- conversione di potenza, capacità, peso e dimensioni;
- immagini e documenti;
- prezzo di acquisto e stock;
- conservazione integrale dei campi sorgente non riconosciuti.

### Provenienza
Ogni valore normalizzato conserva:
- campo e valore sorgente;
- file/listino;
- riga;
- percorso logico;
- hash della prova;
- data di elaborazione.

### Mapping e validazione deterministica
- mapping automatico soltanto per alias conosciuti o campi realmente presenti;
- nessuna invenzione di caratteristiche;
- controllo EAN, titolo, categoria foglia e attributi obbligatori;
- readiness score e separazione tra errori bloccanti e avvisi.

### Job persistenti
- creazione idempotente di job di preparazione prodotti;
- prodotti e stato conservati nel database;
- nessun invio remoto in questa fase;
- storico sincronizzazioni e job consultabile dalla pagina.

## Database
Sono state aggiunte, in modo idempotente e compatibile con SQLite/PostgreSQL, le strutture per:
- capacità marketplace;
- snapshot tassonomie;
- categorie, attributi, valori e condizioni;
- snapshot cataloghi sorgente;
- prodotti canonici e prove di provenienza;
- mapping;
- validazioni;
- job e item di pubblicazione;
- import marketplace e audit.

Le tabelle e i dati precedenti non vengono eliminati o riscritti.

## Protezioni della release
Il gate di distribuzione verifica ora anche:
- presenza della pagina Creazione Prodotti nel menu;
- presenza dei servizi Catalog Intelligence;
- simboli obbligatori pagina/servizi;
- allineamento tra `CATALOG_INTELLIGENCE_VERSION` e `VERSION.txt`;
- copia auto-riparante di tutto il codice Python.

## Limite intenzionale della v244
La v244 costituisce la **prima tranche programmata** del progetto. Sono operativi fondazione, tassonomie, normalizzazione, provenienza, validazione e job. La scrittura reale dei product data e delle offerte verrà abilitata soltanto nelle tranche successive, dopo la costruzione dei payload specifici Kaufland/Worten e dei relativi test di idempotenza, report errori e reinvio.
