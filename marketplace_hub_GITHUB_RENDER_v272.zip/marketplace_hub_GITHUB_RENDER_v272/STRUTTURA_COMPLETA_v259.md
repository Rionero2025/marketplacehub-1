# Marketplace Hub v259 — struttura e garanzie

Release: **259**

## Evoluzione principale
La pagina **Contabilità** ricalcola nella stessa interazione i valori derivati quando l'utente inserisce un dato economico manuale. Non è più necessario effettuare un'altra modifica, cambiare filtro o ricaricare manualmente la pagina per vedere margine e quote aggiornati.

## File applicativi modificati
- `pages/4_Contabilita.py`
- `services/accounting.py`
- `services/catalog_intelligence/__init__.py` (allineamento release)

## Nuovo contratto contabile
`services.accounting.computed_profit_values()` centralizza il calcolo per singola riga di:
- margine lordo;
- margine utile;
- percentuale di ricavo;
- quota BEBOL;
- quota Seller.

Le formule restano derivate dai campi economici autorevoli e non vengono duplicate come valori calcolati persistenti nel database.

## Griglia Contabilità
La griglia AgGrid usa formule client-side protette per mostrare immediatamente Margine utile e quote dopo la modifica di una cella. Subito dopo il salvataggio, la pagina rilegge la sola cache SQLite/PostgreSQL locale per riallineare i totali superiori e tutti i dati downstream.

Il fallback `st.data_editor`, usato solo quando AgGrid non è disponibile, esegue un breve rerun dopo il salvataggio per ottenere lo stesso risultato corretto.

## Test specifici v259
- `tests/test_accounting_live_manual_v259.py`
  - costo di acquisto manuale da valore mancante;
  - ricalcolo margine;
  - ripartizione 35/65;
  - persistenza della fonte manuale;
  - presenza delle formule live e del refresh locale nella pagina.

## Contratti preservati
- distribuzione: `marketplace_hub.zip`;
- avvio: estrai → `AVVIA_WINDOWS.bat`;
- auto-riparazione dal `_release_payload`;
- protezione anti-downgrade;
- preservazione `data`, database, Seller, ordini, storico e configurazioni;
- preservazione credenziali e `.streamlit/secrets.toml`;
- riuso `.venv`/Python esistenti quando disponibili;
- Contabilità v256-v257, Catalog Intelligence v258 e Packlink v255 preservati.
