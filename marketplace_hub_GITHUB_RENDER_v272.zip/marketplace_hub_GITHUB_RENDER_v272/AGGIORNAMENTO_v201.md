# Marketplace Hub v201

## Correzione API Buy Box Worten

- OF01 usa `import_mode=NORMAL`, unico modo sicuro per aggiornamenti selettivi insieme a `REPLACE`.
- `import_mode` viene inviato nel corpo `multipart/form-data` come stringa JSON, secondo la documentazione Mirakl.
- Le azioni riga del CSV usano `update-delete=update` e `update-delete=delete`.
- Rimosso il valore non valido `UPDATE` dal parametro `import_mode`.
- Aggiunti test specifici sul multipart OF01 e sui valori CSV.
