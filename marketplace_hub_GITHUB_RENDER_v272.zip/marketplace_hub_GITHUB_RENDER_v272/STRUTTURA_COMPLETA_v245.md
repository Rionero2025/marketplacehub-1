# Marketplace Hub v245 — struttura del pacchetto completo

La v245 parte dalla pietra miliare v243, preserva la fondazione Catalog Intelligence v244 e aggiunge la classificazione per singolo prodotto e la preparazione del feed completo.

## Struttura Python

- `pages/`: 24 file Python
- `services/`: 64 file Python
- `services/catalog_intelligence/`: 18 file Python
- `tests/`: 81 file Python
- `tools/`: 15 file Python
- `_release_payload/`: 105 file Python auto-riparanti
- codice applicativo controllato dal gate: 105 file Python

## Pagina dedicata

- `pages/3_Creazione_Prodotti.py`

La pagina è divisa in:

1. Account e tassonomia;
2. Catalogo sorgente;
3. Determina categorie;
4. Prepara feed;
5. Storico.

## Servizi Catalog Intelligence

### Fondazione v244 preservata

- `services/catalog_intelligence/schema.py`
- `services/catalog_intelligence/models.py`
- `services/catalog_intelligence/utils.py`
- `services/catalog_intelligence/accounts.py`
- `services/catalog_intelligence/capabilities.py`
- `services/catalog_intelligence/taxonomy.py`
- `services/catalog_intelligence/normalization.py`
- `services/catalog_intelligence/mapping.py`
- `services/catalog_intelligence/validation.py`
- `services/catalog_intelligence/repository.py`
- `services/catalog_intelligence/marketplaces/kaufland.py`
- `services/catalog_intelligence/marketplaces/mirakl.py`

### Nuovi moduli v245

- `services/catalog_intelligence/category_classifier.py`
- `services/catalog_intelligence/category_schema.py`
- `services/catalog_intelligence/feed.py`
- `services/catalog_intelligence/workflow.py`

## Funzioni v245

1. tassonomia cached-first: lettura database prima di qualunque decifratura credenziali/chiamata API;
2. snapshot ufficiale versionato per account, ambiente, storefront/canale e locale;
3. classificazione separata per ogni prodotto nuovo;
4. utilizzo di titolo, descrizione, marca, modello, caratteristiche, immagini e dati sorgente;
5. categorie candidate limitate alle categorie foglia ufficiali;
6. suggerimenti Kaufland ufficiali opzionali e subordinati allo snapshot locale;
7. Knowledge Base delle categorie approvate;
8. approvazione manuale e riutilizzo del mapping;
9. lazy-cache degli attributi specifici della categoria Kaufland;
10. riutilizzo locale degli attributi Mirakl/Worten già sincronizzati;
11. feed Kaufland completo con EAN e attributi;
12. record prodotto dinamico Worten/Mirakl completo;
13. immagini tramite URL e caratteristiche tecniche normalizzate;
14. validazione deterministica di obbligatorietà, tipi, valori, unità, regex e limiti;
15. nessuna invenzione dei dati tecnici mancanti;
16. payload, errori, readiness e storico salvati nel database;
17. protezione multi-Seller su tassonomia e catalogo sorgente;
18. job persistenti con scrittura remota ancora disabilitata.

## Nuove tabelle v245

- `taxonomy_category_enrichments`
- `category_classification_runs`
- `product_category_candidates`
- `product_category_assignments`
- `category_mapping_rules`
- `product_feed_preparations`

Le migrazioni sono additive e idempotenti.

## Compatibilità e preservazione

- SQLite: sì;
- PostgreSQL: coperto dalla suite automatica e dal layer DDL esistente;
- tabelle precedenti: non eliminate;
- `data`, database, Seller, account, ordini, storico, credenziali e configurazioni: preservati;
- avvio: soltanto `AVVIA_WINDOWS.bat`;
- anti-downgrade e auto-riparazione codice: mantenuti;
- Packlink, Buy Box, cancellazione, Cecotec, ordini, contabilità e tracciabilità v243: preservati.

## Gate della release

La distribuzione viene bloccata se manca o non è allineato:

- un import locale;
- un simbolo pagina-servizio;
- uno dei nuovi moduli v245;
- la voce Creazione Prodotti nel menu;
- la versione Catalog Intelligence rispetto a `VERSION.txt`;
- la copia identica del codice in `_release_payload`;
- il manifesto SHA-256;
- l'assenza di cache Python.
