# Aggiornamento v113 — ramo Buy Box Worten completo

## Selezione e filtri

- Filtri Buy Box: **Tutte**, **Vinte**, **Perse** e **Non trovate**.
- Filtro per esito economico e intervallo del margine potenziale.
- Selezione singola, multipla, di tutte le righe filtrate o deselezione del
  solo blocco filtrato.
- Le spunte restano memorizzate cambiando filtro o ricerca.
- È quindi possibile mostrare `Perse` e selezionarle tutte con un solo comando.

## Gestione prezzi

- Colonna modificabile **Prezzo da inviare** per ogni offerta.
- Comando **Allinea selezionate alla Buy Box**, calcolato sul totale cliente e
  sulla nostra spedizione.
- Ripristino del prezzo corrente per le righe selezionate.
- Ricalcolo immediato di totale, commissione, guadagno e margine.
- CSV ufficiale OF01 che aggiorna soltanto il prezzo del canale
  `WRT_PT_ONLINE`.
- Anteprima, download CSV e conferma esplicita prima dell'invio.
- Blocco dei prezzi in perdita o privi di costo calcolabile.
- Conferma aggiuntiva per margini inferiori al 10%.
- Salvataggio nello storico dell'ID import e di ogni prezzo inviato.

## Commissioni

Il calcolo mantiene la priorità già concordata:

1. tariffa corrente della categoria effettiva;
2. commissione reale ricavata dall'ordine;
3. percentuale configurata soltanto come ultima riserva.

## Verifica

Compilazione completata e 156 test automatici superati.
