@echo off
setlocal
cd /d "%~dp0"
echo Aggiornamento delle dipendenze di Marketplace Hub...
python -m pip install --disable-pip-version-check --upgrade -r requirements.txt
if errorlevel 1 (
  echo.
  echo Installazione non riuscita. Verifica Internet e Python.
  pause
  exit /b 1
)
echo.
echo Verifica del componente WYSIWYG...
python -c "import streamlit_quill; print('streamlit_quill trovato in:', streamlit_quill.__file__)"
if errorlevel 1 (
  echo.
  echo Il modulo streamlit_quill non risulta disponibile nello stesso Python.
  echo Controlla che AVVIA_WINDOWS.bat e questo file usino la stessa installazione Python.
  pause
  exit /b 1
)
echo.
echo Dipendenze installate e verificate correttamente.
pause
endlocal
