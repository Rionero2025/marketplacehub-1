# Marketplace Hub v152

## Correzione definitiva invio tracking Worten

Il portale Worten mostra una risorsa separata denominata **Spedizione 1**. Per
questi ordini il tenant Mirakl utilizza il flusso delle spedizioni multiple e
non l'endpoint storico riferito direttamente all'ordine.

La versione v152:

1. cerca tramite ST11 la spedizione collegata al numero ordine;
2. invia tracking e corriere tramite ST23 (`POST /api/shipments/tracking`);
3. conferma la spedizione tramite ST24 (`PUT /api/shipments/ship`);
4. usa OR23/OR24 soltanto come fallback per gli account Mirakl precedenti che
   non espongono una risorsa spedizione;
5. se il `shop_id` configurato produce 404, ripete in sicurezza la ricerca con
   lo shop predefinito associato alla API key;
6. blocca l'invio quando un ordine contiene più spedizioni ancora aperte, per
   evitare di associare lo stesso tracking alla spedizione sbagliata.

Il pulsante resta **Invia aggiornamento spedizione** e non richiede conferme
testuali.

## Cache permanente e sincronizzazione incrementale degli ordini

Gli ordini scaricati rimangono nel database e non vengono eliminati dalle
sincronizzazioni successive. Nelle pagine Contabilità e Tracciabilità sono ora
mostrati:

- data e ora dell'ultimo aggiornamento riuscito;
- data e ora dell'ultimo ordine scaricato;
- numero totale di ordini e righe conservati nel database.

Il pulsante **Aggiorna ordini mancanti** scarica soltanto la finestra recente di
sicurezza e ricontrolla gli ordini non ancora conclusi. Il pulsante
**Risincronizzazione completa** resta disponibile per ricostruire l'intero
intervallo selezionato. In caso di errore API, lo storico già presente non viene
cancellato e resta visibile.
