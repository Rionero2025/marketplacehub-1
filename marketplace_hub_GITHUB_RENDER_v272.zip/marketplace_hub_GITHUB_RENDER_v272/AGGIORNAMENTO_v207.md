# Marketplace Hub v207 — Packlink PRO: ordini → tariffe → bozza spedizione

## Obiettivo
La pagina Packlink PRO è stata trasformata in un flusso operativo simile a **Creazione Ordini Cecotec**: si parte dagli ordini dei marketplace del Seller, si selezionano uno o più ordini senza refresh a ogni checkbox, si confrontano le tariffe Packlink e si crea la bozza della spedizione scelta.

## 1. Marketplace del Seller
La pagina legge gli account marketplace attivi del Seller.

- con un solo account disponibile viene mantenuto selezionato automaticamente;
- con più account Kaufland/Worten è possibile selezionarne uno o più tramite checkbox;
- il download degli ordini viene eseguito solo sugli account selezionati.

## 2. Download e cache ordini
La sincronizzazione usa lo stesso motore/cache della pagina **Creazione Ordini Cecotec**, così sono disponibili anche i dati necessari per la spedizione:

- numero ordine;
- data e stato;
- marketplace/account;
- fornitore;
- SKU/prodotti e quantità;
- cliente;
- indirizzo, CAP, città, Paese;
- telefono ed email.

Una nuova sincronizzazione sostituisce soltanto l'intervallo richiesto e non cancella la cache storica fuori intervallo.

## 3. Filtri e selezione persistente
Gli ordini possono essere filtrati per:

- marketplace;
- fornitore;
- stato ordine;
- ricerca libera.

La tabella usa AgGrid in modalità **MANUAL** quando disponibile:

- checkbox per singolo ordine;
- selezione multipla;
- seleziona/deseleziona tutto il filtrato;
- la selezione non provoca refresh a ogni click;
- la selezione resta in `st.session_state` anche cambiando filtro, pagina o ricerca;
- il pulsante **Applica** della griglia trasferisce la selezione al flusso Packlink.

## 4. Configurazione mittente e pacco
Packlink PRO tenta di leggere automaticamente:

- magazzini configurati (`clients/warehouses`);
- pacchi predefiniti (`users/parcels`).

Se non sono disponibili, mittente e dimensioni possono essere inseriti manualmente. La scelta può essere salvata come predefinita per il singolo Seller.

## 5. Ricerca tariffe Packlink
Per ogni ordine selezionato Marketplace Hub interroga Packlink con:

- Paese/CAP mittente;
- Paese/CAP destinatario dell'ordine;
- peso e dimensioni del pacco.

Le offerte vengono ordinate per prezzo e mostrano, quando Packlink li restituisce:

- corriere;
- nome servizio;
- categoria;
- prezzo totale, base e imposte;
- valuta;
- tempi di transito;
- consegna stimata;
- drop-off / consegna a punto;
- necessità etichetta;
- informazioni/tag del servizio.

## 6. Una riga ordine → offerte sotto la riga operativa
Gli ordini selezionati vengono riproposti nella sezione operativa come blocchi consecutivi. Sotto ogni riga/intestazione ordine appaiono immediatamente le relative offerte di spedizione.

Per ciascun ordine:

1. si vede il riepilogo ordine/fornitore/cliente/destinazione;
2. si vedono le tariffe Packlink;
3. si sceglie **una sola tariffa con radio button**;
4. si verifica/modifica il valore dichiarato;
5. si conferma;
6. si preme **Crea bozza spedizione Packlink**.

## 7. Creazione bozza, non pagamento
Il programma invia a Packlink la bozza con il servizio selezionato e conserva il riferimento restituito.

La spedizione resta da completare/pagare nel sito Packlink PRO. La generazione definitiva dell'etichetta avviene dopo il completamento/pagamento previsto da Packlink; Marketplace Hub non memorizza dati di pagamento.

La relazione tra bozza Packlink e ordine marketplace viene salvata immediatamente, così in seguito tracking e corriere possono essere riutilizzati nella pagina Tracciabilità.

## 8. Database
Viene aggiunta automaticamente la tabella:

- `packlink_order_drafts`

Compatibile con SQLite e con il layer PostgreSQL introdotto nelle versioni precedenti.

## 9. Protezione configurazione
La verifica/riattivazione della API key Packlink non cancella più:

- magazzino predefinito;
- pacco predefinito;
- parametri API avanzati per la creazione delle bozze.

## Test
- compilazione Python: OK;
- test Packlink specifici: **8 superati**;
- suite completa Marketplace Hub: **397 test superati + 6 subtest**.

La ricerca tariffe e la creazione reale della bozza richiedono la API key Packlink PRO del Seller e vengono quindi verificate definitivamente sul PC dell'utente.
