# Marketplace Hub v237 — auto-riparazione Packlink

- Corretto il caso di installazione mista con pagina Packlink nuova e `services/packlink.py` vecchio.
- `AVVIA_WINDOWS.bat` ripristina automaticamente i file critici dalla copia `_release_payload` prima dell’avvio.
- La pagina Packlink esegue un secondo auto-ripristino del servizio prima dell’import.
- `PACKLINK_SERVICE_VERSION` e requisito pagina portati a 237.
- Conservata la logica v235 per Paese e Città/codice postale del destinatario tramite gli endpoint locations Packlink.
- Nessuna installazione o aggiornamento separato richiesto.
