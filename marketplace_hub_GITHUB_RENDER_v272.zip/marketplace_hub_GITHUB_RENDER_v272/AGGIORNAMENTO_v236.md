# Marketplace Hub v236 — ripristino automatico Packlink PRO nel menu

- Mantiene tutte le correzioni Packlink v235 su Paese e Città/codice postale.
- `AVVIA_WINDOWS.bat` continua a essere l’unico comando da usare.
- L’avvio automatico verifica ora anche `app.py`, che contiene la navigazione Streamlit.
- Se l’installazione in `Documents\marketplace_hub` ha la stessa versione ma un `app.py` vecchio o privo di Packlink PRO, il codice viene riallineato automaticamente.
- Verifica esplicita della voce `pages/4_Packlink_PRO.py` prima dell’avvio.
- Nessun dato utente viene cancellato: `data`, database, Seller, ordini, tariffe e `secrets.toml` restano esclusi dalla sincronizzazione.
