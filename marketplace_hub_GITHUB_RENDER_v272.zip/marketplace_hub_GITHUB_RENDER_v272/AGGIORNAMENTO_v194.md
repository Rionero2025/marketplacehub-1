# Aggiornamento v194

## Correzione database in sola lettura durante il controllo Buy Box

- Marketplace Hub verifica che `data/marketplace_hub.db` sia realmente scrivibile prima di iniziare il controllo Buy Box.
- Su Windows vengono rimossi automaticamente gli attributi di sola lettura lasciati da estrazione ZIP, copia cartelle o ripristino backup.
- La riparazione riguarda la cartella `data`, il database e gli eventuali file SQLite `-wal`, `-shm` e `-journal`, senza cancellare o ricreare i dati.
- Se SQLite restituisce `attempt to write a readonly database`, il servizio ripara i permessi e ripete una volta l'operazione.
- I risultati Buy Box vengono salvati in blocchi da 25 righe, riducendo aperture, commit e checkpoint del database.
- Se il database diventa non scrivibile durante il controllo, l'operazione viene interrotta in sicurezza: i risultati dell'ultimo blocco restano nella sessione e possono essere salvati con il pulsante di recupero.
- Lo storico operazioni conserva un riepilogo compatto e al massimo 100 errori, evitando di duplicare nel database tutte le risposte già presenti in `buybox_checks`.
- Il launcher Windows esegue la riparazione dei permessi prima dell'avvio di Streamlit.

## Sicurezza dei dati

La riparazione non elimina, sostituisce o inizializza il database esistente. La cartella `data` e `.streamlit/secrets.toml` devono continuare a essere conservati durante gli aggiornamenti.
