# Marketplace Hub v134

## Correzione costi Innpro in Contabilità

Il match dei costi continua a essere esclusivamente per EAN/GTIN esatto, ma ora
riconosce il barcode anche quando un listino Innpro lo conserva nel campo
`code_producer` o nella colonna SKU numerica.

Sono gestiti inoltre EAN importati da Excel come numeri, con decimali finali o in
notazione scientifica. Gli SKU alfanumerici non vengono mai usati come EAN.

La correzione funziona sia sui feed XML Innpro riletti dal programma sia sui PKL o
sulle viste salvate generate da versioni precedenti. Per aggiornare le righe già
presenti in Contabilità utilizzare **Ricalcola costi da tutti i listini**.
