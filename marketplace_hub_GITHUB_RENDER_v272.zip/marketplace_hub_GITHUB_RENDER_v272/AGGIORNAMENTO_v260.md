# Marketplace Hub v260 — Backup e trasferimento dati tra PC

## Obiettivo
Aggiungere una funzione semplice e sicura per prendere **tutti i dati già memorizzati** in Marketplace Hub su un PC e portarli su un'altra installazione del programma, senza ricreare Seller, account, ordini, listini, configurazioni o storico.

## Nuova voce di menu
Nel menu principale è disponibile **Backup e trasferimento**.

La pagina contiene due flussi separati:
- **Esporta dati** sul PC sorgente;
- **Importa su questo PC** sul PC di destinazione.

## Backup completo `.mhubbackup`
L'esportazione genera un singolo file con estensione `.mhubbackup`, cifrato con una password scelta dall'utente.

Il pacchetto comprende:
- database e tabelle applicative;
- Seller e percentuali configurate;
- account marketplace e credenziali cifrate;
- fornitori e listini;
- ordini, storico, Buy Box, ticket e messaggi memorizzati;
- Contabilità, override manuali ed export registrati;
- dati Packlink, tracciabilità e ordini Cecotec;
- tassonomie, prodotti, mapping e job di Catalog Intelligence;
- viste salvate, file listino e altri file persistenti presenti in `data/`;
- configurazione database attiva;
- `.streamlit/secrets.toml` oppure la chiave master attiva, necessaria per poter decifrare sul nuovo PC le credenziali già salvate.

La password del backup **non viene memorizzata** da Marketplace Hub.

## SQLite: snapshot consistente
Con SQLite il file `marketplace_hub.db` non viene copiato a caldo come un normale file. Viene creato uno **snapshot consistente tramite la SQLite Backup API**, quindi il backup resta valido anche quando il database usa WAL mode.

Prima di chiudere il pacchetto viene eseguito anche `PRAGMA integrity_check` sulla copia SQLite.

I file transitori `-wal`, `-shm`, `-journal`, `.tmp` e `.part` non vengono trasferiti.

## PostgreSQL
Se Marketplace Hub usa PostgreSQL, i dati centrali restano sul server PostgreSQL e quindi non devono essere duplicati sul PC. Il backup trasferisce:
- tutti i file locali persistenti;
- la configurazione PostgreSQL **effettivamente attiva**, anche se originariamente proveniva da variabili d'ambiente;
- host, porta, database, utente, password, SSL e parametri pool;
- chiave master/`secrets.toml`.

Sul nuovo PC, dopo l'importazione e il riavvio, Marketplace Hub può quindi riconnettersi allo stesso database centrale.

## Sicurezza del file di trasferimento
Il contenuto completo viene cifrato con **Fernet** usando una chiave derivata dalla password tramite **PBKDF2-HMAC-SHA256** con salt casuale.

Il pacchetto contiene inoltre SHA-256 per ogni file interno. In fase di verifica/import vengono controllati:
- password e autenticità cifratura;
- formato del pacchetto;
- versione del formato;
- release sorgente;
- elenco file dichiarato nel manifest;
- checksum SHA-256 di tutti i file;
- percorsi consentiti, impedendo path traversal;
- limiti anomali di numero file/dimensione;
- integrità SQLite, quando presente.

Un backup creato da una release **più nuova** non può essere importato in una release più vecchia: il PC di destinazione deve essere aggiornato prima.

## Importazione protetta
L'importazione non sovrascrive immediatamente l'installazione.

Prima vengono eseguiti:
1. decifratura;
2. verifica completa;
3. estrazione in una cartella di staging;
4. verifica del database SQLite, se presente.

Solo dopo questi controlli la cartella `data/` viene sostituita.

Prima della sostituzione, lo stato presente sul PC di destinazione viene automaticamente conservato in:

`migration_backups/pre_import_YYYYMMDD_HHMMSS/`

La copia di sicurezza comprende anche il precedente `secrets.toml` quando viene sostituito.

## Riavvio obbligatorio
Dopo un'importazione riuscita la pagina richiede di:

**chiudere completamente Marketplace Hub → riavviare con `AVVIA_WINDOWS.bat`**.

Questo garantisce che database, configurazione PostgreSQL/SQLite e chiave master importati vengano caricati da zero.

## Cosa non viene copiato
Il file `.mhubbackup` contiene i dati dell'utente, non il programma stesso. Non include:
- `.venv`;
- runtime Python;
- codice applicativo;
- file temporanei di esecuzione.

Sul PC nuovo va prima installata una versione di Marketplace Hub uguale o più recente.

## Compatibilità preservata
Restano invariati:
- Contabilità v259 con ricalcolo immediato margine e quote BEBOL/Seller;
- selezione listini Contabilità v257 e Innpro LIGHT v256;
- Catalog Intelligence AI v258-v259;
- Packlink v255;
- avvio `estrai → AVVIA_WINDOWS.bat`;
- auto-riparazione `_release_payload`;
- protezione anti-downgrade;
- nessuna cancellazione automatica dei dati durante un normale aggiornamento.
