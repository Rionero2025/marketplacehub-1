# Marketplace Hub v264 — Dashboard cliccabile con dettaglio

## Card operative
I riquadri principali della Dashboard non sono più soltanto riepiloghi statici. Sono ora card cliccabili che aprono il dettaglio del valore mostrato mantenendo lo stesso periodo selezionato e tutti i Seller inclusi nel riepilogo.

Sono cliccabili:
- Guadagno complessivo BEBOL;
- Ordini nell'intervallo;
- Vendite nell'intervallo;
- Margine utile nell'intervallo;
- Quota complessiva dei Seller;
- Righe da verificare;
- Periodo selezionato.

## Coerenza tra card e dettaglio
Il dettaglio viene costruito dalle stesse righe `accounting_order_lines`, dagli stessi override manuali e dalle stesse formule della Contabilità usate dalla Dashboard. Non esiste quindi un secondo calcolo indipendente che possa divergere dal totale della card.

Per **Ordini nell'intervallo** le righe prodotto vengono ricondotte a un solo record per numero ordine marketplace/account, così il numero di righe del dettaglio coincide con il conteggio ordini della card anche quando un ordine contiene più prodotti.

Per **Righe da verificare** vengono mostrate solo le righe effettivamente conteggiate come non determinabili e viene aggiunto il motivo, ad esempio costo acquisto mancante o importo da ricevere mancante.

## Navigazione
Il dettaglio si apre direttamente sotto le card senza cambiare pagina. È presente il comando **Chiudi dettaglio**. Cambiando periodo mentre un dettaglio è aperto, la tabella si aggiorna sul nuovo intervallo.

## Compatibilità preservata
Restano invariati storico e export INNPRO v263, Contabilità v259, backup/trasferimento, Packlink v255, Cecotec, Catalog Intelligence, Seller, credenziali e flusso `estrai → AVVIA_WINDOWS.bat`.
