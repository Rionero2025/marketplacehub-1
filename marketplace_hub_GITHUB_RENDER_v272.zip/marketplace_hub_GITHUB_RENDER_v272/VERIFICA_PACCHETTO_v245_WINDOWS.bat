@echo off
setlocal
cd /d "%~dp0"
python tools\verify_package_v245.py
if errorlevel 1 (
  echo.
  echo Verifica Marketplace Hub v245 FALLITA.
  pause
  exit /b 1
)
echo.
echo Verifica Marketplace Hub v245 completata.
pause
