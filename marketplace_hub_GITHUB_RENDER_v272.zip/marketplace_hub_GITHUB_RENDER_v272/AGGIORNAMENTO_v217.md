# Marketplace Hub v217 — correzione caricamento servizio ordini Packlink

## Problema corretto
La pagina Packlink v216 poteva essere aggiornata mentre il processo Streamlit manteneva in memoria una versione precedente di `services/cecotec_orders.py`. In quel caso Python generava:

`ImportError: cannot import name 'fetch_kaufland_orders_by_ids' from services.cecotec_orders`

anche quando il file corretto era già stato copiato sul disco.

## Correzione
- `pages/4_Packlink_PRO.py` non importa più immediatamente le nuove funzioni con un `from ... import` fragile.
- La pagina carica il modulo `services.cecotec_orders`, verifica i simboli richiesti e, se necessario, esegue `importlib.reload()` per sostituire in memoria il vecchio modulo.
- Lo stesso meccanismo di autoriparazione è applicato a `services.packlink`.
- `services/cecotec_orders.py` espone `ORDER_SERVICE_VERSION = 217` per la verifica dell'installazione.
- L'hotfix v217 copia insieme pagina Packlink e servizi compatibili, cancella i `__pycache__` e avvia una verifica con un nuovo processo Python.

## Regola Packlink confermata
Il flusso Packlink non esclude mai un ordine in base a margine, perdita o costo. Se il numero ordine viene trovato nel marketplace, l'ordine resta selezionabile e spedibile.
