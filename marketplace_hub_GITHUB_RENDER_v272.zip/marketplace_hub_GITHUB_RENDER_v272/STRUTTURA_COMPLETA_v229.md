# Marketplace Hub v229 — struttura completa del pacchetto

Pacchetto completo autonomo Windows.

- File totali prima del manifesto v229: **325**
- Pagine Streamlit Python: **23**
- Servizi Python: **44**
- Test Python: **66**
- Tool Python: **8**

## Correzione Packlink v229

- `services/packlink.py`: `PACKLINK_SERVICE_VERSION = 229`
- `pages/4_Packlink_PRO.py`: `PACKLINK_REQUIRED_SERVICE_VERSION = 229`
- Mittente collegato a `GET /v1/clients/warehouses`
- `additional_data.selectedWarehouseId` valorizzato con ID Packlink reale
- `country` inviato come ISO-2 nel normale Address DTO
- vecchia risoluzione v228 di `postal_zone_id_*` / `zip_code_id_*` rimossa dal flusso di creazione
- memoria tariffa/pacco/servizio e rigenerazione massiva preservate

## Script principali

- `INSTALLA_TUTTO_WINDOWS.bat`
- `AGGIORNA_INSTALLAZIONE_ESISTENTE_v229_WINDOWS.bat`
- `VERIFICA_PACCHETTO_v229_WINDOWS.bat`
- `AVVIA_WINDOWS.bat`
