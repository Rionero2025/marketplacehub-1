# Marketplace Hub v250 — normalizzazione cataloghi progressiva e veloce

La v250 parte dalla pietra miliare v243 e conserva integralmente le funzioni Catalog Intelligence v244-v249.

## Correzione blocco al 58%

La fase di normalizzazione e la fase di persistenza sono ora separate visivamente e tecnicamente. Dopo aver letto e normalizzato tutti i prodotti, Marketplace Hub avvia immediatamente il salvataggio a blocchi da 250 prodotti e aggiorna in tempo reale il contatore `Memorizzati` fino al 100%.

Ogni blocco completato viene committato nel database. Questo elimina il lungo flush finale del WAL e consente di riprendere una normalizzazione interrotta senza perdere i blocchi già salvati.

## Ottimizzazioni

- cache dei token normalizzati usati nelle colonne e nei parametri tecnici;
- indicizzazione dei parametri annidati una sola volta per prodotto;
- eliminazione della terza copia completa di `source_attributes` da `canonical_product_values`;
- `raw_json` e `normalized_json` continuano a conservare integralmente il feed sorgente;
- hash prodotto senza serializzare due volte lo stesso `source_attributes`;
- salvataggio tramite `executemany` e commit progressivi;
- riuso tramite content hash dei prodotti già identici.

## Innpro / IOF full

Il campo `producer` continua a essere interpretato come marchio commerciale quando `brand`/`marca` non sono valorizzati. Descrizioni, immagini, documenti e parametri tecnici del feed full rimangono disponibili al motore di creazione prodotti.

## Compatibilità

- SQLite: sì;
- PostgreSQL: sì;
- dati v243-v249: preservati;
- database, `data`, Seller, credenziali, storico e configurazioni: preservati;
- avvio: esclusivamente `AVVIA_WINDOWS.bat`.
