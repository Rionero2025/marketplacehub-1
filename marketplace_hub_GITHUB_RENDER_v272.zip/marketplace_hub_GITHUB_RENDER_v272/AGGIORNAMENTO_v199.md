# Marketplace Hub — aggiornamento v199

## Correzione Buy Box Worten

La gestione collettiva delle offerte selezionate può ora inviare direttamente il
**prezzo consigliato Buy Box**, senza richiedere prima la copia manuale del prezzo
nella tabella.

### Nuovo flusso

1. Selezionare una o più offerte nella tabella Buy Box Worten.
2. Lasciare attiva la modalità predefinita **Prezzo consigliato Buy Box · automatico**.
3. Il programma prepara automaticamente il prezzo prodotto necessario a superare
   di 0,01 € il totale del vincitore visibile, tenendo conto della propria spedizione.
4. Verificare guadagno, margine, eventuali perdite e righe non calcolabili.
5. Confermare le righe gialle o in perdita, quando richiesto.
6. Spuntare la conferma finale e premere **Invia prezzi consigliati Buy Box a Worten**.

Le offerte con Buy Box già vinta non vengono abbassate automaticamente. Le righe
senza prezzo vincente, prezzo attuale o dati economici validi restano escluse e
sono mostrate separatamente.

È ancora disponibile la modalità **Prezzo preparato o modificato nella tabella**
per inviare prezzi personalizzati.

> Nota: il prezzo consigliato si basa sui concorrenti visibili tramite Mirakl P11.
> La Buy Box finale può dipendere anche dalla qualità del Seller e dalle regole
> interne di Worten.
