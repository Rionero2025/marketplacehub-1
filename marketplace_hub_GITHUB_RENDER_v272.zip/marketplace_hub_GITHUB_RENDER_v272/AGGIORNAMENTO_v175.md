# Marketplace Hub v175

## Credenziali IA configurate una sola volta

Nella sezione Ticket e messaggi è stato rimosso il secondo campo ripetuto
"OpenAI API Key" e il relativo selettore legacy.

Le credenziali vengono ora gestite esclusivamente tramite i profili provider
nel riquadro "Collega un provider IA", dove si configurano API key, modello,
endpoint e verifica connessione.

Le impostazioni per-account mantengono soltanto:

- attivazione delle risposte automatiche;
- profilo IA principale;
- profili di fallback;
- soglia di confidenza;
- SLA;
- limite risposte automatiche;
- categorie autorizzate;
- istruzioni specifiche del Seller.

I vecchi dati legacy presenti nel database non vengono cancellati, ma non sono
più mostrati né utilizzati dalle nuove chiamate IA.
