@echo off
setlocal
cd /d "%~dp0"
title Marketplace Hub - Test completi
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente .venv assente. Esegui prima INSTALLA_TUTTO_WINDOWS.bat
  pause
  exit /b 1
)
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m pytest -q
set RC=%errorlevel%
echo.
if "%RC%"=="0" echo Tutti i test sono stati superati.
if not "%RC%"=="0" echo Sono presenti test falliti. Non ignorare il risultato.
pause
exit /b %RC%
