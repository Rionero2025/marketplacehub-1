# Marketplace Hub v214 — Fix storico bozze Packlink

Correzione della pagina Packlink PRO quando nessun ordine è selezionato.

## Problema corretto
La variabile `created_drafts` veniva inizializzata soltanto nel ramo in cui esistevano ordini selezionati. Aprendo la sezione **4. Bozze e spedizioni Packlink** con selezione vuota, Streamlit generava `NameError: name 'created_drafts' is not defined`.

## Correzione
Lo storico bozze viene ora caricato prima del controllo sulla selezione degli ordini, quindi la sezione 4 funziona sia con zero ordini selezionati sia durante il normale flusso di quotazione/spedizione.

Database, ordini, credenziali, mittenti, pacchi e bozze già registrate non vengono modificati.
