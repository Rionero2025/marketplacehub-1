@echo off
setlocal
cd /d "%~dp0"
echo ATTENZIONE: questa procedura svuota il database PostgreSQL configurato
echo e lo ricostruisce dal database SQLite locale.
echo NON cancella il file SQLite.
echo.
set /p CONFIRM=Scrivi RESET POSTGRESQL per continuare: 
if /I not "%CONFIRM%"=="RESET POSTGRESQL" exit /b 1
python "%~dp0tools\migrate_sqlite_to_postgresql.py" --reset-target --activate
pause
