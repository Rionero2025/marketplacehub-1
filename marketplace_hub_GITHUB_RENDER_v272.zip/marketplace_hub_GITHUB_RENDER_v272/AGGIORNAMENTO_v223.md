# Marketplace Hub v223 — Memoria completa tariffe in rigenerazione Packlink

## Comportamento
- **Seleziona tutti da rigenerare** ripristina per ogni ordine la configurazione della precedente spedizione Packlink.
- Vengono ripristinati: pacco, peso, dimensioni, tariffa/servizio, corriere, service_id, costo storico e valore dichiarato.
- La tariffa precedente viene preselezionata automaticamente: non è necessario riaprire ogni ordine e selezionare di nuovo il radio button.
- Gli ordini con configurazione precedente diventano candidati alla creazione massiva.
- Se l'utente preme **Calcola / aggiorna tariffe per questo ordine**, solo quel singolo ordine passa in modalità manuale e può scegliere una tariffa nuova.
- Se il pacco viene modificato, la tariffa precedente non viene riutilizzata su dimensioni diverse.
- Se Packlink rifiuta un vecchio service_id non più disponibile, l'errore resta circoscritto al singolo ordine e si può ricalcolare soltanto quella riga.

## Compatibilità
La modifica mantiene database, Seller, credenziali, storico, Kaufland, Worten, Cecotec, contabilità e tracciabilità.
