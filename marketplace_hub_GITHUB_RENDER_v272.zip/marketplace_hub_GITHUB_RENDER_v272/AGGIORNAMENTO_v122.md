# Aggiornamento v122 — Costi contabili da tutti i listini tramite EAN

- La pagina **Contabilità** cerca il costo di acquisto tramite **EAN esatto** in
  tutti i listini attivi accessibili al Seller.
- Sono inclusi listini di proprietà, globali, condivisi tramite autorizzazione e
  viste salvate già presenti nel programma.
- Il fornitore ricavato dallo SKU composito viene usato come priorità, ma non
  limita più la ricerca: se l'EAN è presente in un altro listino accessibile, il
  costo viene comunque trovato.
- Eliminato il fallback contabile tramite SKU/codice alfanumerico: il costo viene
  assegnato soltanto quando esiste un EAN valido e identico.
- Aggiunto il pulsante **Ricalcola costi da tutti i listini**, che aggiorna gli
  ordini già memorizzati senza riscaricarli dalle API.
- Aggiunta in tabella la colonna **Fonte costo**, con fornitore, nome del listino,
  tipo di fonte ed EAN abbinato.
- Riparazione automatica dei percorsi dei listini dopo il passaggio a una nuova
  versione del programma, quando il database conserva il percorso della vecchia
  cartella ma il contenuto è stato copiato nella nuova cartella `data`.
- Corretto il totale **Acquisti**: eventuali costi mancanti/NaN non rendono più
  NaN l'intero riepilogo.
- 196 test automatici e 6 subtest superati.
