@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo Marketplace Hub - Migrazione SQLite ^> PostgreSQL
echo ============================================================
echo.
echo 1. Chiudi tutte le altre finestre di Marketplace Hub.
echo 2. Lo script crea un backup SQLite prima di copiare i dati.
echo 3. PostgreSQL verra attivato solo dopo verifica completa.
echo.
pause

python -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :error

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONFIGURA_POSTGRESQL_WINDOWS.ps1"
if errorlevel 1 goto :error

python "%~dp0tools\migrate_sqlite_to_postgresql.py" --activate
if errorlevel 1 goto :error

echo.
echo ============================================================
echo MIGRAZIONE COMPLETATA. Riavvia Marketplace Hub.
echo ============================================================
pause
exit /b 0

:error
echo.
echo ============================================================
echo MIGRAZIONE NON COMPLETATA.
echo SQLite rimane attivo e il suo database non e stato cancellato.
echo ============================================================
pause
exit /b 1
