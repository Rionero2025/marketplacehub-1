@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
%PY% tools\verify_package_v231.py
if errorlevel 1 (
  echo.
  echo VERIFICA v231 FALLITA.
  pause
  exit /b 1
)
echo.
echo PACCHETTO v231 VERIFICATO.
pause
