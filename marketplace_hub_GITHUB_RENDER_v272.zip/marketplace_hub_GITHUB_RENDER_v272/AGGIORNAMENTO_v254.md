# Marketplace Hub v254 — avvio: pulizia automatica dei file Python obsoleti

## Problema corretto
Quando `marketplace_hub.zip` veniva estratto sopra una cartella Marketplace Hub già esistente, Windows sovrascriveva i file presenti nel nuovo ZIP ma non cancellava i vecchi file Python rimossi dalle release successive.

Il gate di coerenza vedeva quindi file applicativi orfani, per esempio:
- `services/accounting_costs.py`
- `services/marketplace_deletion.py`

Poiché questi file non appartengono più al pacchetto corrente e non hanno un gemello in `_release_payload`, l'avvio veniva correttamente bloccato come **RELEASE NON DISTRIBUIBILE**.

## Correzione v254
`AVVIA_MARKETPLACE_HUB.ps1` ora tratta `_release_payload` come fonte autorevole del codice Python distribuibile.

Prima del gate di coerenza:
1. individua i file Python applicativi live in `app.py`, `launcher.py`, `pages`, `services` e `tools`;
2. rimuove automaticamente solo i `.py` che non esistono più nel `_release_payload` della release corrente;
3. riallinea dal payload tutti i file Python distribuiti;
4. elimina cache `__pycache__`, `.pyc` e `.pyo`;
5. avvia il normale release consistency gate.

In questo modo l'utente può continuare a fare semplicemente **estrai -> `AVVIA_WINDOWS.bat`**, anche estraendo il nuovo ZIP sopra una cartella precedente.

## Dati preservati
La pulizia è limitata al codice Python applicativo e non interviene su:
- `data` e database;
- Seller, account, ordini e storico;
- configurazioni e tariffe;
- `.streamlit/secrets.toml`;
- `.venv` e runtime;
- credenziali.

Rimangono attivi backup preventivo, auto-riparazione e protezione anti-downgrade.

## Compatibilità Packlink
Tutte le correzioni v253 restano invariate, inclusi:
- invio massivo dopo selezione manuale delle tariffe;
- fallback telefono destinatario -> telefono mittente;
- CSV Packlink generabile indipendentemente dall'esito della bozza API.
