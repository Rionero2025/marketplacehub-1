# Marketplace Hub v163

## Motore IA multi-provider

È stata introdotta la nuova pagina **Provider IA**, utilizzabile da tutti i Seller.

Provider disponibili:

- OpenAI
- Anthropic Claude
- Google Gemini
- Mistral AI
- xAI Grok
- DeepSeek
- Groq
- OpenRouter
- Azure OpenAI / Microsoft Foundry
- Amazon Bedrock
- Ollama e modelli locali
- endpoint personalizzati compatibili OpenAI

Ogni profilo supporta nome, modello, endpoint, parametri di generazione, timeout,
tentativi, limiti giornalieri e mensili, credenziali cifrate e verifica della
connessione.

La sezione Ticket può selezionare un profilo principale e più profili di
fallback. Se il provider principale fallisce, il programma prova quelli di
riserva nell'ordine configurato. Con IA automatica disattivata, il testo viene
soltanto preparato nell'editor. Con IA automatica attivata restano validi tutti
i controlli di categoria, confidenza, duplicazione e revisione umana.

Le chiavi sono cifrate nel database con MARKETPLACE_HUB_MASTER_KEY e non vengono
esposte nei log o nelle esportazioni. È disponibile anche uno storico di utilizzo
con provider, modello, token, latenza ed esito.
