# Aggiornamento v111 — costo SKU con EAN ordine differente

## Correzione

La v110 verificava che l’EAN restituito nell’ordine coincidesse con l’EAN
incorporato nello SKU. Questo controllo impediva erroneamente di leggere un
costo comunque presente e valido.

Esempio corretto:

- SKU: `AB-Online_8690842106835_44.80_58.24`
- EAN ordine: `111100000606`
- Netto Kaufland: `54,16 €`
- Costo letto dallo SKU: `44,80 €`
- Guadagno: `9,36 €`
- Guadagno sul costo: `20,89%`

## Nuovo comportamento

- Il costo viene sempre letto dal terzo valore di uno SKU composto valido.
- L’EAN dell’ordine non blocca il calcolo.
- Se i due EAN sono diversi, la tabella mostra un controllo informativo
  separato.
- Il numero delle unità con EAN differente compare nei totali.
- La segnalazione viene inclusa anche nei CSV.
- Soltanto uno SKU privo dei quattro componenti economici validi resta
  realmente non calcolabile.

## Verifica

Compilazione completata e 148 test automatici superati.
