# Marketplace Hub v234 — struttura completa

- File totali prima del manifesto: 363
- Pagine Python: 23
- Servizi Python: 44
- File test: 70
- Versione: 234
- Avvio: `AVVIA_WINDOWS.bat`
- Modalità Packlink: API key diretta, nessuna registrazione negozio obbligatoria.
