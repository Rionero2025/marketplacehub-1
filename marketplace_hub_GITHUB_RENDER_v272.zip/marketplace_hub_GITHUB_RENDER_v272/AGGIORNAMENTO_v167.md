# Marketplace Hub v167

## Correzione Deseleziona tutti - Tracciabilità ordini

Il pulsante **Deseleziona tutti** ora azzera sia la selezione persistente del programma sia lo stato interno di AgGrid.

La griglia riceve una nuova revisione dopo ogni comando massivo di selezione o deselezione. In questo modo il browser non può ripristinare i checkbox della precedente istanza dopo il rerun di Streamlit.

Sono coperti anche:

- Seleziona tutti i filtrati;
- Seleziona solo inviabili filtrati;
- Deseleziona tutti;
- tabella alternativa `st.data_editor` quando AgGrid non è disponibile.
