# Marketplace Hub v268 — struttura e garanzie

Release: **268**

## File modificati

- `pages/4_Contabilita.py` — selezione Seller/Marketplace/Account della coda di verifica applicata una sola volta per gruppo;
- `pages/0_Dashboard.py` — mantenimento del contratto del pulsante Top 10 in fondo alla Home;
- `services/catalog_intelligence/__init__.py` — versione release allineata a 268;
- `tests/test_accounting_review_seller_selector_v268.py` — regressione sul cambio manuale Seller;
- `VERSION.txt` — release 268;
- `_release_payload/VERSION.txt` — payload auto-riparante allineato a 268;
- `AVVIA_MARKETPLACE_HUB.ps1` — controllo preventivo root/payload prima della sincronizzazione;
- `tools/verify_release_consistency.py` — gate esteso alla versione del payload.

## Garanzie

- il cambio manuale Seller in Contabilità non viene più annullato dal rerun Streamlit;
- la navigazione Account precedente/successivo della verifica continua a riallineare il gruppo corretto;
- nessuna migrazione DB;
- nessuna cancellazione di configurazioni, ordini, cache o credenziali.
- il payload auto-riparante non può più retrocedere VERSION.txt a una release precedente;
- una release root/payload incoerente viene rifiutata prima di copiare file.
