param(
    [switch]$Repair,
    [switch]$SkipOCR,
    [switch]$NoLaunch,
    [switch]$FullTests
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$RuntimeDir = Join-Path $Root ".runtime"
$LogsDir = Join-Path $Root "logs"
New-Item -ItemType Directory -Force -Path $RuntimeDir, $LogsDir | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = Join-Path $LogsDir "installazione_v234_$Stamp.log"

try { Start-Transcript -Path $LogFile -Append | Out-Null } catch {}

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
}
function Write-Ok([string]$Message) { Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-Warn([string]$Message) { Write-Host "[AVVISO] $Message" -ForegroundColor Yellow }
function Fail([string]$Message) { throw $Message }

function Test-Command([string]$Name) {
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Invoke-External {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(ValueFromRemainingArguments=$true)][string[]]$Arguments
    )
    Write-Host "> $FilePath $($Arguments -join ' ')" -ForegroundColor DarkGray
    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Comando non riuscito (exit $LASTEXITCODE): $FilePath $($Arguments -join ' ')"
    }
}

function Find-Python313 {
    $probes = @()
    if (Test-Command "py") { $probes += ,@("py", "-3.13") }
    if (Test-Command "python") { $probes += ,@("python") }
    $probes += ,@(Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe")
    $probes += ,@(Join-Path $env:ProgramFiles "Python313\python.exe")
    foreach ($probe in $probes) {
        $exe = $probe[0]
        if ($exe -match "[\\/]" -and -not (Test-Path $exe)) { continue }
        try {
            $prefix = @()
            if ($probe.Count -gt 1) { $prefix = $probe[1..($probe.Count - 1)] }
            $version = & $exe @prefix -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')" 2>$null
            if ($LASTEXITCODE -eq 0 -and $version -match '^3\.13\.') {
                return @{ Exe=$exe; Prefix=$prefix; Version=$version.Trim() }
            }
        } catch {}
    }
    return $null
}

function Install-Python313 {
    Write-Step "Python 3.13 non presente: installazione automatica"
    if (Test-Command "winget") {
        try {
            Invoke-External "winget" "install" "--exact" "--id" "Python.Python.3.13" "--source" "winget" "--scope" "user" "--silent" "--accept-package-agreements" "--accept-source-agreements" "--disable-interactivity"
            Start-Sleep -Seconds 3
            $found = Find-Python313
            if ($found) { return $found }
        } catch {
            Write-Warn "WinGet non ha completato Python: $($_.Exception.Message)"
        }
    }

    if (-not [Environment]::Is64BitOperatingSystem) {
        Fail "Windows 32 bit non è supportato dal pacchetto automatico v234."
    }
    $isArm = $env:PROCESSOR_ARCHITECTURE -eq "ARM64"
    if ($isArm) {
        $url = "https://www.python.org/ftp/python/3.13.15/python-3.13.15-arm64.exe"
        $expected = "c252c676087c49e6b94e95a273536b78921c28a5fc9f86d15d25392328247249"
    } else {
        $url = "https://www.python.org/ftp/python/3.13.15/python-3.13.15-amd64.exe"
        $expected = "edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403"
    }
    $installer = Join-Path $env:TEMP "marketplace_hub_python_3.13.15.exe"
    Write-Host "Download ufficiale Python 3.13.15 da python.org..."
    Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing
    $actual = (Get-FileHash -Path $installer -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected) {
        Remove-Item $installer -Force -ErrorAction SilentlyContinue
        Fail "Checksum SHA-256 del programma di installazione Python non valido."
    }
    Write-Ok "Checksum installer Python verificato"
    $arguments = "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1 InstallLauncherAllUsers=0 Include_test=0 SimpleInstall=1"
    $proc = Start-Process -FilePath $installer -ArgumentList $arguments -Wait -PassThru
    Remove-Item $installer -Force -ErrorAction SilentlyContinue
    if ($proc.ExitCode -ne 0) { Fail "Installazione Python terminata con codice $($proc.ExitCode)." }
    Start-Sleep -Seconds 3
    $found = Find-Python313
    if (-not $found) { Fail "Python 3.13 è stato installato ma non è stato rilevato. Riavvia Windows e ripeti l'installer." }
    return $found
}

function Install-VCRuntime {
    if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") {
        Write-Warn "Windows ARM64: salto installazione automatica del VC++ x64; Python ARM64 gestirà i propri prerequisiti."
        return
    }
    if (-not (Test-Command "winget")) {
        Write-Warn "WinGet non disponibile: salto controllo Visual C++ Runtime."
        return
    }
    try {
        Write-Step "Verifica Microsoft Visual C++ Runtime"
        & winget list --exact --id "Microsoft.VCRedist.2015+.x64" --accept-source-agreements *> $null
        if ($LASTEXITCODE -ne 0) {
            Invoke-External "winget" "install" "--exact" "--id" "Microsoft.VCRedist.2015+.x64" "--source" "winget" "--silent" "--accept-package-agreements" "--accept-source-agreements" "--disable-interactivity"
        }
        Write-Ok "Microsoft Visual C++ Runtime disponibile"
    } catch {
        Write-Warn "Visual C++ Runtime non installato automaticamente: $($_.Exception.Message)"
    }
}

function Find-Tesseract {
    $cmd = Get-Command "tesseract" -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach ($path in @(
        "C:\Program Files\Tesseract-OCR\tesseract.exe",
        "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
    )) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

function Ensure-Tesseract {
    if ($SkipOCR) {
        Write-Warn "Installazione OCR saltata su richiesta."
        return
    }
    Write-Step "Tesseract OCR per screenshot e PDF scansiti"
    $tesseract = Find-Tesseract
    if (-not $tesseract -and (Test-Command "winget")) {
        $ids = @("tesseract-ocr.tesseract", "UB-Mannheim.TesseractOCR")
        foreach ($id in $ids) {
            try {
                & winget install --exact --id $id --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity
                if ($LASTEXITCODE -eq 0) {
                    Start-Sleep -Seconds 2
                    $tesseract = Find-Tesseract
                    if ($tesseract) { break }
                }
            } catch {}
        }
    }
    if (-not $tesseract) {
        Fail "Tesseract OCR non trovato e installazione automatica non riuscita. Serve per screenshot/PDF scansiti. Installa Tesseract e ripeti, oppure avvia con -SkipOCR."
    }
    Write-Ok "Tesseract: $tesseract"

    $tessDir = Split-Path -Parent $tesseract
    $tessData = Join-Path $tessDir "tessdata"
    if (-not (Test-Path $tessData)) { New-Item -ItemType Directory -Force -Path $tessData | Out-Null }
    foreach ($lang in @("eng", "ita", "por")) {
        $dest = Join-Path $tessData "$lang.traineddata"
        if (Test-Path $dest) { Write-Ok "OCR lingua $($lang.ToUpper()) presente"; continue }
        try {
            $langUrl = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$lang.traineddata"
            Invoke-WebRequest -Uri $langUrl -OutFile $dest -UseBasicParsing
            Write-Ok "OCR lingua $($lang.ToUpper()) installata"
        } catch {
            if ($lang -eq "eng") { Fail "Impossibile installare il language pack OCR ENG: $($_.Exception.Message)" }
            Write-Warn "Language pack $($lang.ToUpper()) non installato; OCR userà ENG come fallback."
        }
    }
    $env:PATH = "$tessDir;$env:PATH"
}

try {
    Write-Step "Marketplace Hub v234 - installazione completa Windows"
    Write-Host "Cartella: $Root"
    Write-Host "Log: $LogFile"
    if ($env:OS -ne "Windows_NT") { Fail "Questo installer è destinato a Windows." }
    if (-not [Environment]::Is64BitOperatingSystem) { Fail "È richiesto Windows a 64 bit." }

    Write-Step "Controllo cartelle e permessi"
    New-Item -ItemType Directory -Force -Path (Join-Path $Root "data") | Out-Null
    try { attrib -R "$Root\data\*" /S /D 2>$null | Out-Null } catch {}
    $probe = Join-Path $Root "data\.installer_write_probe"
    "ok" | Set-Content -Path $probe -Encoding ASCII
    Remove-Item $probe -Force
    Write-Ok "Cartella data scrivibile"

    Write-Step "Backup preventivo configurazione e database locale"
    $backupDir = Join-Path $Root "data\backups\installer_v234_$Stamp"
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $backedUp = 0
    foreach ($candidate in @(
        (Join-Path $Root "data\marketplace_hub.db"),
        (Join-Path $Root "data\marketplace_hub.db-wal"),
        (Join-Path $Root "data\marketplace_hub.db-shm"),
        (Join-Path $Root "data\marketplace_hub.db-journal"),
        (Join-Path $Root "data\database.toml"),
        (Join-Path $Root ".streamlit\secrets.toml")
    )) {
        if (Test-Path $candidate) {
            Copy-Item $candidate -Destination $backupDir -Force
            $backedUp += 1
        }
    }
    if ($backedUp -gt 0) { Write-Ok "Backup preventivo creato: $backupDir ($backedUp file)" }
    else { Write-Host "Prima installazione: nessun dato precedente da copiare." -ForegroundColor DarkGray }

    $python = Find-Python313
    if (-not $python) { $python = Install-Python313 }
    Write-Ok "Python $($python.Version) trovato: $($python.Exe) $($python.Prefix -join ' ')"

    Install-VCRuntime

    Write-Step "Creazione/controllo ambiente Python isolato (.venv)"
    $venvDir = Join-Path $Root ".venv"
    $venvPython = Join-Path $venvDir "Scripts\python.exe"
    if (Test-Path $venvPython) {
        $vv = & $venvPython -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ($vv -ne "3.13") {
            $old = Join-Path $Root ".venv_incompatibile_$Stamp"
            Move-Item $venvDir $old
            Write-Warn "Vecchio ambiente spostato in $old"
        }
    }
    if (-not (Test-Path $venvPython)) {
        $venvArgs = @($python.Prefix) + @("-m", "venv", "--upgrade-deps", $venvDir)
        & $python.Exe @venvArgs
        if ($LASTEXITCODE -ne 0) { Fail "Creazione .venv non riuscita." }
    }
    Write-Ok "Ambiente .venv pronto"

    Write-Step "Aggiornamento pip / setuptools / wheel"
    $env:PIP_DISABLE_PIP_VERSION_CHECK = "1"
    $env:PIP_DEFAULT_TIMEOUT = "180"
    Invoke-External $venvPython "-m" "pip" "install" "--upgrade" "pip" "setuptools" "wheel"

    Write-Step "Installazione di TUTTE le librerie Python Marketplace Hub"
    $requirements = Join-Path $Root "requirements-installer.txt"
    if (-not (Test-Path $requirements)) { $requirements = Join-Path $Root "requirements.txt" }
    try {
        Invoke-External $venvPython "-m" "pip" "install" "--upgrade" "--prefer-binary" "--retries" "5" "--timeout" "180" "-r" $requirements
    } catch {
        Write-Warn "Primo tentativo pip fallito. Secondo tentativo senza upgrade..."
        Invoke-External $venvPython "-m" "pip" "install" "--prefer-binary" "--retries" "5" "--timeout" "180" "-r" $requirements
    }
    Invoke-External $venvPython "-m" "pip" "check"
    Write-Ok "Dipendenze Python installate e coerenti"

    Ensure-Tesseract

    Write-Step "Creazione segreto locale e configurazione Streamlit"
    $streamlitDir = Join-Path $Root ".streamlit"
    New-Item -ItemType Directory -Force -Path $streamlitDir | Out-Null
    $secretFile = Join-Path $streamlitDir "secrets.toml"
    if (-not (Test-Path $secretFile)) {
        $key = & $venvPython -c "import secrets; print(secrets.token_urlsafe(48))"
        "MARKETPLACE_HUB_MASTER_KEY = `"$key`"" | Set-Content -Path $secretFile -Encoding UTF8
        Write-Ok "Master key locale generata"
    } else {
        Write-Ok "secrets.toml esistente preservato"
    }

    Write-Step "Verifica completa runtime"
    Invoke-External $venvPython (Join-Path $Root "tools\verify_runtime.py")

    if ($FullTests) {
        Write-Step "Test automatici completi"
        $env:PYTHONPATH = $Root
        Invoke-External $venvPython "-m" "pytest" "-q"
    } else {
        Write-Host "Test completi non eseguiti in installazione standard. Usa ESEGUI_TEST_COMPLETI_WINDOWS.bat quando vuoi." -ForegroundColor DarkGray
    }

    Write-Step "Creazione collegamento sul Desktop"
    try {
        $desktop = [Environment]::GetFolderPath("Desktop")
        $shortcutPath = Join-Path $desktop "Marketplace Hub.lnk"
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = Join-Path $Root "AVVIA_WINDOWS.bat"
        $shortcut.WorkingDirectory = $Root
        $shortcut.Description = "Marketplace Hub"
        $shortcut.Save()
        Write-Ok "Collegamento creato: $shortcutPath"
    } catch {
        Write-Warn "Collegamento Desktop non creato: $($_.Exception.Message)"
    }

    @"
version=234
installed_at=$(Get-Date -Format o)
python=$($python.Version)
venv=$venvPython
ocr_skipped=$SkipOCR
"@ | Set-Content -Path (Join-Path $RuntimeDir "installazione_v234.txt") -Encoding UTF8

    Write-Host ""
    Write-Host "INSTALLAZIONE COMPLETATA CON SUCCESSO" -ForegroundColor Green
    Write-Host "Tutte le librerie Python sono installate nell'ambiente .venv dedicato." -ForegroundColor Green
    Write-Host "Log completo: $LogFile"

    if (-not $NoLaunch) {
        Write-Step "Avvio Marketplace Hub"
        Start-Process -FilePath (Join-Path $Root "AVVIA_WINDOWS.bat") -WorkingDirectory $Root
    }
    try { Stop-Transcript | Out-Null } catch {}
    exit 0
} catch {
    Write-Host ""
    Write-Host "INSTALLAZIONE NON COMPLETATA" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Consulta il log: $LogFile" -ForegroundColor Yellow
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
