# Marketplace Hub v247 — struttura del pacchetto completo

La v247 parte dalla pietra miliare v243, preserva Catalog Intelligence v244/v245 e la pubblicazione controllata v246, e corregge il caricamento degli attributi ufficiali delle categorie Kaufland.

## Struttura Python

- `pages/`: 24 file Python
- `services/`: 65 file Python
- `services/catalog_intelligence/`: 19 file Python
- `tests/`: 83 file Python
- `tools/`: 17 file Python
- `_release_payload/`: 108 file Python auto-riparanti
- codice applicativo controllato dal gate: 108 file Python

## Correzione v247

File applicativi interessati:

- `services/kaufland.py`
- `tools/verify_release_consistency.py`

Test aggiunto:

- `tests/test_kaufland_category_schema_v247.py`

Documentazione e verifica:

- `AGGIORNAMENTO_v247.md`
- `VALIDAZIONE_v247.txt`
- `STRUTTURA_COMPLETA_v247.md`
- `tools/verify_package_v247.py`
- `MANIFESTO_SHA256_v247.txt`

## Contratto API Kaufland corretto

Per leggere lo schema di una categoria viene effettuata una richiesta equivalente a:

```text
GET /v2/categories/{id_category}/
    ?storefront=de
    &embedded=optional_attributes
    &embedded=required_attributes
    &embedded=conditional_attributes
```

Ogni valore `embedded` viene serializzato separatamente mediante `urlencode(..., doseq=True)`.

Non viene più inviato:

```text
embedded=required_attributes,optional_attributes,conditional_attributes,parent,children
```

Il dettaglio categoria non riceve il parametro `locale`; lo storefront determina lo schema richiesto. In caso di HTTP 400 legato alla disponibilità degli attributi condizionali, viene eseguito un solo retry compatibile con `optional_attributes` e `required_attributes`.

## Persistenza

Dopo il primo caricamento riuscito, lo schema categoria continua a essere salvato nelle tabelle Catalog Intelligence già presenti e viene riutilizzato dal database. Gli enrichment precedentemente falliti non vengono considerati completati e sono quindi riprovati automaticamente.

## Funzioni preservate

Restano incluse integralmente:

- gestione Seller e account;
- fornitori e listini;
- Kaufland e Worten/Mirakl;
- Creazione Prodotti;
- tassonomie persistenti;
- classificazione e feed completi;
- pubblicazione prodotto/offerta;
- Buy Box persistente;
- cancellazione senza doppio download;
- Packlink PRO e CSV;
- ordini, tracking, contabilità e storico;
- SQLite e PostgreSQL;
- avvio unico tramite `AVVIA_WINDOWS.bat`;
- sincronizzazione e auto-riparazione del codice;
- gate obbligatorio pagina-servizio e manifesto SHA-256.
