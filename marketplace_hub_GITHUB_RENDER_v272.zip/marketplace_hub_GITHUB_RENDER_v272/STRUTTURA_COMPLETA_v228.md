# Marketplace Hub v228 — struttura completa del pacchetto

Pacchetto autonomo Windows completo. La v228 aggiunge la risoluzione Packlink dei selettori Paese e Città/codice postale prima della creazione della bozza.

## Conteggi principali

- `pages/`: **23 file**
- `services/`: **45 file**
- `tests/`: **65 file**
- `tools/`: **7 file**
- `templates/`: **1 file**
- `.streamlit/`: **2 file**
- File totali coperti dal manifesto v228: **312**

## Pagine Streamlit incluse

- `pages/0_Dashboard.py`
- `pages/1_Gestione_Seller.py`
- `pages/2_Fornitori_e_Listini.py`
- `pages/2_Provider_IA.py`
- `pages/3_Assistenza_Kaufland.py`
- `pages/3_Assistenza_Marketplace.py`
- `pages/3_Cancellazione_Kaufland.py`
- `pages/3_Cancellazione_Marketplace.py`
- `pages/3_Cancellazione_Worten.py`
- `pages/3_Controllo_BuyBox.py`
- `pages/3_Controllo_BuyBox_Worten.py`
- `pages/3_Lavora_sui_Listini.py`
- `pages/3_Ordini_Kaufland.py`
- `pages/3_Ordini_Marketplace.py`
- `pages/3_Pubblicazione_Kaufland.py`
- `pages/3_Pubblicazione_Marketplace.py`
- `pages/3_Pubblicazione_Worten.py`
- `pages/4_Contabilita.py`
- `pages/4_Ordini_Cecotec.py`
- `pages/4_Packlink_PRO.py`
- `pages/4_Storico.py`
- `pages/4_Tracciabilita_Ordini.py`
- `pages/5_Database.py`

## Services inclusi

- `services/abonline.py`
- `services/accounting.py`
- `services/accounting_pdf.py`
- `services/activeshop.py`
- `services/ai_providers.py`
- `services/batch_memory.py`
- `services/cecotec_orders.py`
- `services/dashboard.py`
- `services/database_config.py`
- `services/db.py`
- `services/deletion_scope.py`
- `services/fx.py`
- `services/kaufland.py`
- `services/kaufland_bulk_deletion.py`
- `services/kaufland_buybox.py`
- `services/kaufland_buybox_account.py`
- `services/kaufland_history.py`
- `services/kaufland_inventory_deletion.py`
- `services/kaufland_live_inventory.py`
- `services/kaufland_offer.py`
- `services/kaufland_order_costs.py`
- `services/kaufland_orders.py`
- `services/kaufland_profit.py`
- `services/kaufland_support.py`
- `services/lists.py`
- `services/marketplace_order_states.py`
- `services/order_selection.py`
- `services/order_tracking.py`
- `services/packlink.py`
- `services/packlink_order_import.py`
- `services/postgresql_backend.py`
- `services/profit_sharing.py`
- `services/security.py`
- `services/session.py`
- `services/shipping_deadlines.py`
- `services/supplier_documents.py`
- `services/support_connectors.py`
- `services/support_hub.py`
- `services/tracking_shipping_rules.py`
- `services/worten.py`
- `services/worten_buybox_actions.py`
- `services/worten_support.py`
- `services/worten_tracking_api.py`
- `services/wysiwyg.py`

## Test inclusi

- `tests/test_abonline.py`
- `tests/test_accounting.py`
- `tests/test_accounting_incremental_sync.py`
- `tests/test_accounting_pdf.py`
- `tests/test_ai_providers.py`
- `tests/test_batch_memory.py`
- `tests/test_cecotec_countries.py`
- `tests/test_cecotec_orders.py`
- `tests/test_dashboard.py`
- `tests/test_db_lock_retry.py`
- `tests/test_db_storage_permissions.py`
- `tests/test_deletion_scope.py`
- `tests/test_forcetop.py`
- `tests/test_hurtel.py`
- `tests/test_innpro_accounting.py`
- `tests/test_kaufland_bulk_deletion.py`
- `tests/test_kaufland_buybox.py`
- `tests/test_kaufland_buybox_account_v203.py`
- `tests/test_kaufland_deletion_page_v187.py`
- `tests/test_kaufland_history.py`
- `tests/test_kaufland_inventory_client.py`
- `tests/test_kaufland_inventory_deletion.py`
- `tests/test_kaufland_live_inventory.py`
- `tests/test_kaufland_offer.py`
- `tests/test_kaufland_order_costs.py`
- `tests/test_kaufland_orders.py`
- `tests/test_kaufland_price_update.py`
- `tests/test_kaufland_profit.py`
- `tests/test_kaufland_support.py`
- `tests/test_kaufland_views.py`
- `tests/test_marketplace_order_states.py`
- `tests/test_marketplace_order_states_v177.py`
- `tests/test_marketplace_order_states_v180.py`
- `tests/test_order_selection.py`
- `tests/test_order_tracking.py`
- `tests/test_packlink.py`
- `tests/test_packlink_install_sync_v213.py`
- `tests/test_packlink_order_import_v212.py`
- `tests/test_packlink_order_recovery_v216.py`
- `tests/test_packlink_package_memory_v212.py`
- `tests/test_packlink_page_v208.py`
- `tests/test_packlink_page_v214.py`
- `tests/test_packlink_sender_addresses_v209.py`
- `tests/test_packlink_v217_order_service_compat.py`
- `tests/test_packlink_v218.py`
- `tests/test_packlink_v220.py`
- `tests/test_packlink_v221.py`
- `tests/test_packlink_v223.py`
- `tests/test_packlink_v224_alignment.py`
- `tests/test_packlink_v225_no_extra_confirmation.py`
- `tests/test_packlink_v226_address_hydration.py`
- `tests/test_packlink_v227_regeneration_tariffs.py`
- `tests/test_packlink_v228_complete_draft_locations.py`
- `tests/test_postgresql_backend.py`
- `tests/test_profit_sharing.py`
- `tests/test_shipping_deadlines.py`
- `tests/test_supplier_documents.py`
- `tests/test_support_connectors_v160.py`
- `tests/test_support_hub.py`
- `tests/test_tracking_file_archive.py`
- `tests/test_tracking_shipping.py`
- `tests/test_worten.py`
- `tests/test_worten_tracking_api.py`
- `tests/test_worten_views.py`
- `tests/test_wysiwyg.py`

## Script Windows v228

- `INSTALLA_TUTTO_WINDOWS.bat`
- `AGGIORNA_INSTALLAZIONE_ESISTENTE_v228_WINDOWS.bat`
- `VERIFICA_PACCHETTO_v228_WINDOWS.bat`

L’aggiornamento esistente preserva `data`, database, `.streamlit/secrets.toml`, Seller, configurazioni e `.venv`.
