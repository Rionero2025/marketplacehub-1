# Aggiornamento v126 — documenti multipli dei fornitori in Contabilità

La pagina **Contabilità** include una nuova sezione **Importa documenti degli ordini fornitore**.

## Origini e formati

È possibile aggiungere contemporaneamente:

- uno o più file caricati dal computer;
- uno o più URL, inseriti uno per riga;
- collegamenti diretti, Google Drive e Google Sheets pubblici/condivisi.

Formati supportati:

- Excel `.xlsx` e `.xls`;
- PDF testuali o scansionati;
- immagini `.jpg`, `.jpeg`, `.png`, `.webp` tramite OCR;
- pagine o file `.html` / `.htm`.

## Abbinamento

Il programma cerca il numero ordine marketplace nel documento e lo confronta con gli ordini già scaricati in Contabilità. La priorità è:

1. numero ordine marketplace esatto;
2. numero ordine + EAN esatto, quando un ordine contiene più righe;
3. numero ordine + codice articolo, se disponibile.

Il campo compilato è **N Ordine Fornitore**. I valori già presenti non vengono sovrascritti automaticamente: sono mostrati nella scheda **Conflitti**.

## Formato Cecotec

Il file `dropshippingorderline` Cecotec viene riconosciuto automaticamente:

- colonna A: numero ordine Cecotec, ad esempio `D261143542`;
- colonna B: riga, ad esempio `0001`;
- commento: ordine marketplace, ad esempio `WORTEN 83273319-A`.

Il risultato salvato è `D261143542-1`. Gli zeri della riga vengono rimossi, quindi `0015` diventa `-15`.

Sul file reale allegato sono stati trovati **22 riferimenti esatti su 22**: 19 campi vuoti compilabili e 3 conflitti correttamente segnalati senza sovrascrittura.

## Controlli

Prima dell’applicazione sono disponibili:

- coda unica dei documenti;
- riepilogo dei formati letti;
- abbinamenti proposti;
- conflitti;
- riferimenti non abbinati o ambigui;
- errori di lettura;
- report Excel scaricabile;
- conferma obbligatoria prima del salvataggio;
- storico permanente delle importazioni.

Per OCR di immagini e PDF scansionati viene utilizzato Tesseract OCR. Il programma riconosce automaticamente il percorso Windows standard; se Tesseract non è installato mostra un messaggio chiaro senza interrompere le altre importazioni.

Verifica: **209 test automatici e 6 subtest superati**.
