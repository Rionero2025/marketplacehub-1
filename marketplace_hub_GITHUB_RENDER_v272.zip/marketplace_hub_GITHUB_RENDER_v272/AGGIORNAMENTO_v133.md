# Marketplace Hub v133

## Ripartizione del margine utile per Seller

Nella pagina **Gestione Seller** sono disponibili due percentuali per ogni Seller:

- percentuale del nostro guadagno sul margine utile;
- percentuale spettante al partner Seller.

Il totale deve essere sempre pari al 100%. I vecchi database vengono aggiornati
automaticamente con i nuovi campi senza perdere Seller, account, listini o storico.

## Dashboard

Per ogni Seller e per ciascun periodo — oggi, settimana, mese e complessivo — vengono
mostrati:

- numero ordini;
- vendite;
- margine utile prima della ripartizione;
- nostra quota, con la percentuale del Seller;
- quota del partner, con nome e percentuale del Seller.

Nel riepilogo generale la nostra quota viene calcolata separatamente per ogni Seller e
solo dopo sommata. In questo modo percentuali differenti, ad esempio 35/65 e 40/60,
non vengono confuse in un'unica aliquota media.

## Contabilità

I riepiloghi, la tabella degli ordini, la selezione da esportare e lo storico dei file
mostrano la ripartizione del margine utile. Il file Excel aggiunge:

- `Nostra quota %`;
- `Nostro guadagno`;
- `Quota <nome Seller> %`;
- `Guadagno <nome Seller>`.

Gli importi sono formule collegate al `Ricavo Netto`, così una modifica manuale dei
costi nel file aggiorna anche la ripartizione. Le righe annullate, cancellate, no stock
o rimborsate restano a zero anche nelle quote.
