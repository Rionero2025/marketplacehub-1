# Marketplace Hub v223 — pacchetto completo

Release completa autonoma Windows con tutte le pagine, servizi, test, strumenti
di installazione e migrazione database presenti nella base v222, più la memoria
completa delle tariffe Packlink per la rigenerazione massiva.

La funzione **Seleziona tutti da rigenerare** ripristina per ogni ordine la
tariffa precedentemente scelta senza richiedere una nuova selezione manuale.
La modifica del singolo ordine resta indipendente.

Suite: **443 test + 6 subtest superati**.
