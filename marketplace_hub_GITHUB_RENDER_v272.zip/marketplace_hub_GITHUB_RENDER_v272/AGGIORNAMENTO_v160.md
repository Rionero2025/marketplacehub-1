# Marketplace Hub v160

## Console Ticket e messaggi: API verificate e controllo IA rafforzato

La pagina **Ticket e messaggi** mantiene la console unificata Kaufland/Worten e introduce un flusso grafico più chiaro, protezioni aggiuntive e una gestione API più rigorosa.

### Viste rapide

Sono disponibili pulsanti dedicati per visualizzare immediatamente:

- tutti i ticket;
- da rispondere;
- prioritari con meno di 24 ore;
- scaduti;
- in attesa del cliente;
- informativi;
- chiusi;
- da leggere.

I filtri dettagliati per stato, priorità, lettura, data, ricerca e IA restano sempre disponibili.

### Worten / Mirakl

- M11 per sincronizzare thread nuovi o modificati con `updated_since` e seek pagination;
- sovrapposizione prudenziale di 5 minuti sul timestamp incrementale;
- M10 per rileggere la conversazione completa;
- M12 per inviare testo e allegati in `multipart/form-data`;
- M13 per scaricare gli allegati;
- supporto sia alla forma `entity` sia a `entities` per collegare gli ordini;
- destinatari scelti tra i partecipanti effettivi del thread, usando gli autorizzati soltanto come fallback;
- mantenimento di `shop_id` durante tutte le pagine della paginazione.

Gli endpoint Mirakl deprecati dei vecchi messaggi ordine non vengono utilizzati.

### Kaufland

- elenco e sincronizzazione ticket;
- conversazione completa;
- risposta definitiva o provvisoria tramite `interim_notice`;
- allegati Base64 nei formati consentiti;
- chiusura esplicita del ticket tramite pulsante protetto da conferma.

### IA controllata

Per ogni account è ora configurabile anche il numero massimo di risposte automatiche per singola esecuzione, da 1 a 100.

L'invio automatico rimane subordinato a:

- attivazione generale sull'account;
- attivazione sul singolo ticket selezionato;
- categoria autorizzata;
- confidenza minima;
- assenza di richiesta economica o decisione irreversibile;
- controllo API immediatamente prima dell'invio;
- assenza di un messaggio nuovo;
- controllo dei duplicati.

Con IA automatica disattivata, la risposta viene soltanto preparata nell'editor e resta completamente modificabile.

### Database

La migrazione aggiunge `auto_batch_limit` alle impostazioni IA senza cancellare o modificare ticket, messaggi, bozze o storico già presenti.
