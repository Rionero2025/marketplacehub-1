# Aggiornamento v192 — Integrazione Force Top / BTP

## Correzione certificato HTTPS

Il download dei feed tenta sempre una connessione HTTPS verificata. In caso di errore della catena certificati nel bundle Python, Marketplace Hub riprova tramite l'archivio certificati del sistema operativo usando `truststore`; su Windows è disponibile anche il client nativo `curl.exe` con Schannel.

La verifica SSL non viene disattivata e i token presenti negli URL non vengono riportati nei messaggi di errore.

## Due feed Force Top

Per il fornitore Force Top la pagina distingue automaticamente:

- `ProductCatalogue`: catalogo completo con anagrafica prodotto;
- `InventoryReport`: file leggero con prezzo di acquisto e disponibilità.

I due file possono essere Excel o CSV e vengono uniti per SKU; quando lo SKU non coincide viene tentato il collegamento tramite EAN/GTIN.

## Aggiornamento listino

Sono disponibili:

- aggiornamento completo del catalogo e del file prezzi/stock;
- aggiornamento rapido di soli prezzi e disponibilità senza riscaricare il catalogo completo.

Il risultato memorizza il costo corrente, la quantità disponibile, la sorgente dei valori e l'esito dell'abbinamento con il file di inventario.

## Compatibilità file BTP

Sono riconosciuti anche endpoint senza estensione nel percorso quando il contenuto ricevuto è un file XLSX o XLS. Sono gestite intestazioni italiane, inglesi e polacche comuni per SKU, EAN, prezzo e stock.
