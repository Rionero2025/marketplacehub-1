# Marketplace Hub v256 — struttura e garanzie

Release: **256**

## Correzione principale
La Contabilità usa per Innpro esclusivamente il prezzo all'ingrosso del listino LIGHT. Il FULL non può più determinare il costo di acquisto.

## File applicativi modificati
- `services/accounting.py`
- `pages/4_Contabilita.py`
- `services/catalog_intelligence/__init__.py` (allineamento versione release)

## Test specifici
- `tests/test_innpro_accounting_light_v256.py`
- aggiornamento dei test contabili Innpro preesistenti al nuovo contratto LIGHT

## Contratti preservati
- distribuzione: `marketplace_hub.zip`
- avvio: estrai → `AVVIA_WINDOWS.bat`
- auto-riparazione dal `_release_payload`
- protezione anti-downgrade
- preservazione `data`, database, Seller, ordini, storico e configurazioni
- preservazione credenziali e `.streamlit/secrets.toml`
- riuso `.venv`/Python esistenti quando disponibili

## Verifica
- compilazione Python: OK
- release consistency gate: OK
- suite completa: **606 test + 6 subtest**
