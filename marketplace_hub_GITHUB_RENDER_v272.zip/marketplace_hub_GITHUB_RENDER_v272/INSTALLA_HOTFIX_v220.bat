@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "TARGET=%USERPROFILE%\Documents\marketplace_hub"
if not exist "%TARGET%" (
  echo [ERRORE] Cartella Marketplace Hub non trovata: %TARGET%
  pause
  exit /b 1
)
echo Chiusura cache Python...
for /d /r "%TARGET%" %%D in (__pycache__) do @if exist "%%D" rd /s /q "%%D" >nul 2>&1
if not exist "%TARGET%\pages" mkdir "%TARGET%\pages"
if not exist "%TARGET%\services" mkdir "%TARGET%\services"
if not exist "%TARGET%\tests" mkdir "%TARGET%\tests"
copy /y "pages\4_Packlink_PRO.py" "%TARGET%\pages\4_Packlink_PRO.py" >nul || goto :error
copy /y "services\packlink.py" "%TARGET%\services\packlink.py" >nul || goto :error
copy /y "tests\test_packlink_v220.py" "%TARGET%\tests\test_packlink_v220.py" >nul || goto :error
copy /y "AGGIORNAMENTO_v220.md" "%TARGET%\AGGIORNAMENTO_v220.md" >nul

echo Verifica import servizio Packlink v220...
python -c "import sys; sys.path.insert(0, r'%TARGET%'); import services.packlink as p; assert p.PACKLINK_SERVICE_VERSION == 220; assert hasattr(p,'last_order_draft_configuration'); print('Packlink service v220 OK')" || goto :error

echo.
echo ================================================
echo HOTFIX v220 INSTALLATO CORRETTAMENTE
echo ================================================
echo Chiudi eventuali processi Streamlit/Python ancora aperti e riavvia Marketplace Hub.
pause
exit /b 0
:error
echo.
echo [ERRORE] Installazione v220 non completata.
echo Verifica che Marketplace Hub sia completamente chiuso e riprova.
pause
exit /b 1
